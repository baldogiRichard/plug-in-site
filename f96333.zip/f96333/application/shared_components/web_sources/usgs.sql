prompt --application/shared_components/web_sources/usgs
begin
--   Manifest
--     WEB SOURCE: USGS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(9306855977053280846)
,p_name=>'USGS'
,p_static_id=>'USGS'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(9306865110274280858)
,p_remote_server_id=>wwv_flow_imp.id(9955596590742510807)
,p_url_path_prefix=>'v1.0/summary/all_hour.geojson'
,p_pass_ecid=>true
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(9306855778667280839)
,p_web_src_module_id=>wwv_flow_imp.id(9306855977053280846)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
