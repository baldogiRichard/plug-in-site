prompt --application/shared_components/user_interface/templates/region/dropdown_menu
begin
--   Manifest
--     REGION TEMPLATE: DROPDOWN_MENU
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_plug_template(
 p_id=>wwv_flow_imp.id(4878037266358980501)
,p_layout=>'TABLE'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="apex-tooltip t-Region #REGION_CSS_CLASSES#" id="#REGION_STATIC_ID#">',
'    #BODY#',
'    #SUB_REGIONS#',
'</div>      '))
,p_page_plug_template_name=>'Dropdown Menu'
,p_internal_name=>'DROPDOWN_MENU'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#script/floatingui/core.js',
'#APP_FILES#script/floatingui/dom.js',
'#APP_FILES#script/floatingui/script.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var button = document.querySelector("[dropdown-menu=#REGION_STATIC_ID#]");',
'var buttonName = button.id;',
'',
'window.DROPDOWNMENU.initialize(buttonName, ''#REGION_STATIC_ID#'');'))
,p_css_file_urls=>'#APP_FILES#style/floatingui/style.css'
,p_theme_id=>42
,p_theme_class_id=>21
,p_preset_template_options=>'apex-tooltip-bottom:t-Region-scrollBody'
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_translate_this_template=>'N'
);
wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(4878036857728980500)
,p_plug_template_id=>wwv_flow_imp.id(4878037266358980501)
,p_name=>'Region Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_has_region_support=>true
,p_has_item_support=>true
,p_has_button_support=>true
,p_glv_new_row=>true
);
wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(4878036344045980500)
,p_plug_template_id=>wwv_flow_imp.id(4878037266358980501)
,p_name=>'Sub Regions'
,p_placeholder=>'SUB_REGIONS'
,p_has_grid_support=>true
,p_has_region_support=>true
,p_has_item_support=>false
,p_has_button_support=>false
,p_glv_new_row=>true
);
wwv_flow_imp.component_end;
end;
/
