prompt --application/shared_components/user_interface/theme_files
begin
--   Manifest
--     THEME FILES: 96333
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
null;
wwv_flow_imp.component_end;
end;
/
