prompt --application/shared_components/plugins/item_type/com_scrollprogressbar_plugin
begin
--   Manifest
--     PLUGIN: COM.SCROLLPROGRESSBAR.PLUGIN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(26713536122623937096)
,p_plugin_type=>'ITEM TYPE'
,p_name=>'COM.SCROLLPROGRESSBAR.PLUGIN'
,p_display_name=>'Scroll Progress Bar'
,p_category=>'EXECUTE'
,p_supported_component_types=>'APEX_APPLICATION_PAGE_ITEMS'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('ITEM TYPE','COM.SCROLLPROGRESSBAR.PLUGIN'),'')
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#PLUGIN_FILES#js/nprogress.js',
'#PLUGIN_FILES#js/scrollProgress.js',
'#PLUGIN_FILES#js/script.js'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#PLUGIN_FILES#css/nprogress.css',
'#PLUGIN_FILES#css/style.css'))
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- =============================================================================',
'--',
'--  Created by Richard Baldogi',
'--',
'--  This plug-in creates a Scroll Progress Bar to a designated area of the APEX Page.',
'--',
'--  License: MIT',
'--',
'--  GitHub: https://github.com/baldogiRichard/apex-scroll-progress-bar',
'--',
'-- =============================================================================',
'',
'--render function',
'procedure render',
'  ( p_item   in            apex_plugin.t_item',
'  , p_plugin in            apex_plugin.t_plugin',
'  , p_param  in            apex_plugin.t_item_render_param',
'  , p_result in out nocopy apex_plugin.t_item_render_result ',
'  )',
'as',
'    l_ajax_id         varchar2(4000) := apex_plugin.get_ajax_identifier;',
'',
'    --attributes',
'    l_progressbar_direction        p_item.attribute_01%type := p_item.attribute_01;',
'    l_scroll_direction             p_item.attribute_02%type := p_item.attribute_02;',
'    l_progressbar_color            p_item.attribute_03%type := p_item.attribute_03;',
'    l_calc_scrolling_from          p_item.attribute_04%type := p_item.attribute_04;',
'    l_position                     p_item.attribute_05%type := p_item.attribute_05;',
'    l_bar_height                   p_item.attribute_06%type := p_item.attribute_06;',
'',
'    --Initialization Javascript Code',
'    l_init_js                           varchar2(32767)            := nvl(apex_plugin_util.replace_substitutions(p_item.init_javascript_code), ''undefined'');',
'',
'    --standard attributes',
'    l_width                        p_item.element_width%type       := p_item.element_width;',
'    l_height                       p_item.element_height%type      := p_item.element_height;',
'',
'    l_classes                      p_item.element_css_classes%type := p_item.element_css_classes;',
'    l_classes_2                    p_item.element_css_classes%type := case when l_progressbar_direction = ''LR''',
'                                                                            then ''''',
'                                                                           when l_progressbar_direction = ''RL''',
'                                                                            then ''apex-scroll-progress-bar-mirroring''',
'                                                                           when l_progressbar_direction = ''TB''',
'                                                                            then ''apex-scroll-progress-bar-vertical''   ',
'                                                                           when l_progressbar_direction = ''BT''',
'                                                                            then ''apex-scroll-progress-bar-vertical-mirroring''',
'                                                                      end                                                                        ',
'                                                                      || '' '' ||',
'                                                                      case when l_position = ''L''',
'                                                                             then ''apex-scroll-progress-bar-left''',
'                                                                           when l_position = ''R''',
'                                                                             then ''apex-scroll-progress-bar-right''  ',
'                                                                      end;',
'    ',
'    l_name                         p_item.name%type                := apex_escape.html(p_item.name);',
'    l_value                        p_param.value%type              := apex_escape.html(p_param.value);',
'',
'begin',
'    ',
'    --debug',
'    if apex_application.g_debug ',
'    then',
'        apex_plugin_util.debug_item_render',
'          ( p_plugin => p_plugin',
'          , p_item   => p_item',
'          , p_param  => p_param',
'          );',
'    end if;',
'',
'    --Create HTML element',
'    sys.htp.p(''<div class="apex-scroll-progress-bar '' || l_classes || '' '' || l_classes_2 || ''" id="'' ',
'              || l_name || ''" value="'' || l_value || ''" style="'' || case when l_width  is not null then ''width:''  || l_width  || ''px;'' end ',
'                                                                 || case when l_height is not null then ''height:'' || l_height || ''px;'' end ',
'              || ''"></div>''',
'             );',
'',
'    --Pass attribute values to JSON',
'    apex_json.initialize_clob_output;',
'',
'        apex_json.open_object;',
'        ',
'            apex_json.write(''progressBarDirection''  , l_progressbar_direction       );',
'            apex_json.write(''scrollDirection''       , l_scroll_direction            );',
'            apex_json.write(''barColor''              , l_progressbar_color           );',
'            apex_json.write(''calcScrollingFrom''     , l_calc_scrolling_from         );',
'            apex_json.write(''parent''                , ''#'' || l_name                 );',
'            apex_json.write(''itemName''              , l_name                        );',
'            apex_json.write(''itemPosition''          , l_position                    );',
'            apex_json.write(''barHeight''             , l_bar_height                  );',
'',
'        apex_json.close_object;',
'',
'        apex_javascript.add_onload_code(''SCROLLPROGRESSBAR.main('' || apex_json.get_clob_output|| '','' || l_init_js || '');'');',
'',
'    apex_json.free_output;',
'    ',
'end render;'))
,p_api_version=>2
,p_render_function=>'render'
,p_standard_attributes=>'ELEMENT:WIDTH:HEIGHT:INIT_JAVASCRIPT_CODE:REGION'
,p_substitute_attributes=>true
,p_version_scn=>1
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_about_url=>'https://github.com/baldogiRichard/apex-scroll-progress-bar'
,p_files_version=>321
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(26713536420236937097)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_static_id=>'attribute_01'
,p_prompt=>'Progress Bar Direction'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_default_value=>'LR'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The coloring direction of the scroll bar.',
'',
'Left to Right ( -> )',
'',
'Right to Left ( <- )',
'',
'Top to Bottom ( |',
'                V )',
'',
'',
'Bottom to Top ( / \',
'                 | ',
'              )'))
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713536884304937098)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713536420236937097)
,p_display_sequence=>10
,p_display_value=>'Left to Right'
,p_return_value=>'LR'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713537403703937098)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713536420236937097)
,p_display_sequence=>20
,p_display_value=>'Right to Left'
,p_return_value=>'RL'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713537822498937098)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713536420236937097)
,p_display_sequence=>30
,p_display_value=>'Top to Bottom'
,p_return_value=>'TB'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713538356173937098)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713536420236937097)
,p_display_sequence=>40
,p_display_value=>'Bottom to Top'
,p_return_value=>'BT'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(26713538824660937098)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_static_id=>'attribute_02'
,p_prompt=>'Scroll Direction'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_default_value=>'TB'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'How the scrolling progress is going to be calculated.',
'',
'If the option "Left to Right" is chosen then calculation will start from the LEFT side of the scrollingbar.',
'If the option "Right to Left" is chosen then calculation will start from the RIGHT side of the scrollingbar.',
'If the option "Top to Bottom" is chosen then calculation will start from the TOP of the scrollingbar.',
'If the option "Bottom to Top" is chosen then calculation will start from the BOTTOM of the scrollingbar.'))
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713539291303937099)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713538824660937098)
,p_display_sequence=>10
,p_display_value=>'Left to Right'
,p_return_value=>'LR'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713539761235937099)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713538824660937098)
,p_display_sequence=>20
,p_display_value=>'Right to Left'
,p_return_value=>'RL'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713540265758937099)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713538824660937098)
,p_display_sequence=>30
,p_display_value=>'Top to Bottom'
,p_return_value=>'TB'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713540756630937099)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713538824660937098)
,p_display_sequence=>40
,p_display_value=>'Bottom to Top'
,p_return_value=>'BT'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(26713541218792937099)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_static_id=>'attribute_03'
,p_prompt=>'Progress Bar Color'
,p_attribute_type=>'COLOR'
,p_is_required=>false
,p_is_translatable=>false
,p_help_text=>'Color of the Progressbar. Default value in the configuration setting is #c74634.'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(26713541633491937100)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_static_id=>'attribute_04'
,p_prompt=>'Calculate scrolling from'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>false
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'A jQuery selector.',
'',
'For example: ".your-class" or "#your-id"',
'',
'Please note that the selected element must be unique in the page, otherwise it will calculate the scrolling from another element.'))
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(26713542044502937100)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>50
,p_static_id=>'attribute_05'
,p_prompt=>'Position'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_default_value=>'L'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_help_text=>'If you are working with a vertical Progressbar then it should be decided if you want to put it to the right side in the given region or to the left.'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713542497376937100)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713542044502937100)
,p_display_sequence=>30
,p_display_value=>'Left'
,p_return_value=>'L'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(26713542989121937100)
,p_plugin_attribute_id=>wwv_flow_imp.id(26713542044502937100)
,p_display_sequence=>40
,p_display_value=>'Right'
,p_return_value=>'R'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(26713543499724937100)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>60
,p_static_id=>'attribute_06'
,p_prompt=>'Bar height (in pixels)'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_default_value=>'5'
,p_is_translatable=>false
,p_help_text=>'Height of the bar in pixels (px).'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_std_attribute(
 p_id=>wwv_flow_imp.id(26713544013402937104)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_name=>'INIT_JAVASCRIPT_CODE'
,p_is_required=>false
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(26713544362488937104)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_name=>'apex-scroll-progress-bar-on-completed'
,p_display_name=>'APEX Scroll Progress Bar On Completed'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(26713544779950937105)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_name=>'apex-scroll-progress-bar-on-progress'
,p_display_name=>'APEX Scroll Progress Bar On Progress'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_plugin_event(
 p_id=>wwv_flow_imp.id(26713545129412937105)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_name=>'apex-scroll-progress-bar-on-start'
,p_display_name=>'APEX Scroll Progress Bar On Start'
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2A204D616B6520636C69636B7320706173732D7468726F756768202A2F0D0A2E6E70726F6772657373207B0D0A2020706F696E7465722D6576656E74733A206E6F6E653B0D0A7D0D0A0D0A2E6E70726F6772657373202E626172207B0D0A2020626163';
wwv_flow_imp.g_varchar2_table(2) := '6B67726F756E643A20233239643B0D0A0D0A2020706F736974696F6E3A2066697865643B0D0A20207A2D696E6465783A20313033313B0D0A2020746F703A20303B0D0A20206C6566743A20303B0D0A0D0A202077696474683A20313030253B0D0A202068';
wwv_flow_imp.g_varchar2_table(3) := '65696768743A203270783B0D0A7D0D0A0D0A2F2A2046616E637920626C757220656666656374202A2F0D0A2E6E70726F6772657373202E706567207B0D0A2020646973706C61793A20626C6F636B3B0D0A2020706F736974696F6E3A206162736F6C7574';
wwv_flow_imp.g_varchar2_table(4) := '653B0D0A202072696768743A203070783B0D0A202077696474683A2031303070783B0D0A20206865696768743A20313030253B0D0A2020626F782D736861646F773A20302030203130707820233239642C203020302035707820233239643B0D0A20206F';
wwv_flow_imp.g_varchar2_table(5) := '7061636974793A20312E303B0D0A0D0A20202D7765626B69742D7472616E73666F726D3A20726F74617465283364656729207472616E736C617465283070782C202D347078293B0D0A2020202020202D6D732D7472616E73666F726D3A20726F74617465';
wwv_flow_imp.g_varchar2_table(6) := '283364656729207472616E736C617465283070782C202D347078293B0D0A202020202020202020207472616E73666F726D3A20726F74617465283364656729207472616E736C617465283070782C202D347078293B0D0A7D0D0A0D0A2E6E70726F677265';
wwv_flow_imp.g_varchar2_table(7) := '73732D637573746F6D2D706172656E74207B0D0A20206F766572666C6F773A2068696464656E3B0D0A2020706F736974696F6E3A2072656C61746976653B0D0A7D0D0A0D0A2E6E70726F67726573732D637573746F6D2D706172656E74202E6E70726F67';
wwv_flow_imp.g_varchar2_table(8) := '72657373202E7370696E6E65722C0D0A2E6E70726F67726573732D637573746F6D2D706172656E74202E6E70726F6772657373202E626172207B0D0A2020706F736974696F6E3A206162736F6C7574653B0D0A7D0D0A0D0A402D7765626B69742D6B6579';
wwv_flow_imp.g_varchar2_table(9) := '6672616D6573206E70726F67726573732D7370696E6E6572207B0D0A202030252020207B202D7765626B69742D7472616E73666F726D3A20726F746174652830646567293B207D0D0A202031303025207B202D7765626B69742D7472616E73666F726D3A';
wwv_flow_imp.g_varchar2_table(10) := '20726F7461746528333630646567293B207D0D0A7D0D0A406B65796672616D6573206E70726F67726573732D7370696E6E6572207B0D0A202030252020207B207472616E73666F726D3A20726F746174652830646567293B207D0D0A202031303025207B';
wwv_flow_imp.g_varchar2_table(11) := '207472616E73666F726D3A20726F7461746528333630646567293B207D0D0A7D0D0A';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713545556219937105)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'css/nprogress.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '402D7765626B69742D6B65796672616D6573206E70726F67726573732D7370696E6E65727B30257B2D7765626B69742D7472616E73666F726D3A726F746174652830646567297D746F7B2D7765626B69742D7472616E73666F726D3A726F746174652833';
wwv_flow_imp.g_varchar2_table(2) := '3630646567297D7D406B65796672616D6573206E70726F67726573732D7370696E6E65727B30257B7472616E73666F726D3A726F746174652830646567297D746F7B7472616E73666F726D3A726F7461746528333630646567297D7D2E6E70726F677265';
wwv_flow_imp.g_varchar2_table(3) := '73737B706F696E7465722D6576656E74733A6E6F6E657D2E6E70726F6772657373202E6261727B6261636B67726F756E643A233239643B706F736974696F6E3A66697865643B7A2D696E6465783A313033313B746F703A303B6C6566743A303B77696474';
wwv_flow_imp.g_varchar2_table(4) := '683A313030253B6865696768743A3270787D2E6E70726F6772657373202E7065677B646973706C61793A626C6F636B3B72696768743A303B77696474683A31303070783B6865696768743A313030253B626F782D736861646F773A302030203130707820';
wwv_flow_imp.g_varchar2_table(5) := '233239642C3020302035707820233239643B6F7061636974793A313B2D7765626B69742D7472616E73666F726D3A726F74617465283364656729207472616E736C61746528302C2D347078293B2D6D732D7472616E73666F726D3A726F74617465283364';
wwv_flow_imp.g_varchar2_table(6) := '656729207472616E736C61746528302C2D347078293B7472616E73666F726D3A726F74617465283364656729207472616E736C61746528302C2D347078297D2E6E70726F67726573732D637573746F6D2D706172656E747B6F766572666C6F773A686964';
wwv_flow_imp.g_varchar2_table(7) := '64656E3B706F736974696F6E3A72656C61746976657D2E6E70726F6772657373202E7065672C2E6E70726F67726573732D637573746F6D2D706172656E74202E6E70726F6772657373202E6261722C2E6E70726F67726573732D637573746F6D2D706172';
wwv_flow_imp.g_varchar2_table(8) := '656E74202E6E70726F6772657373202E7370696E6E65727B706F736974696F6E3A6162736F6C7574657D';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713546001337937106)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'css/nprogress.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E617065782D7363726F6C6C2D70726F67726573732D626172207B0D0A20206261636B67726F756E642D636F6C6F723A207472616E73706172656E743B0D0A20206865696768743A203570783B0D0A202077696474683A202D7765626B69742D66696C6C';
wwv_flow_imp.g_varchar2_table(2) := '2D617661696C61626C653B0D0A20207A2D696E6465783A203130303B0D0A7D0D0A0D0A2E617065782D7363726F6C6C2D70726F67726573732D6261722D6C656674207B0D0A202020207472616E73666F726D2D6F726967696E3A206C6566743B0D0A2020';
wwv_flow_imp.g_varchar2_table(3) := '20206C6566743A20303B0D0A20202020706F736974696F6E3A206162736F6C7574653B0D0A7D0D0A0D0A2E617065782D7363726F6C6C2D70726F67726573732D6261722D7269676874207B0D0A202020207472616E73666F726D2D6F726967696E3A2072';
wwv_flow_imp.g_varchar2_table(4) := '696768743B0D0A2020202072696768743A20303B0D0A20202020706F736974696F6E3A206162736F6C7574653B0D0A7D0D0A0D0A2E617065782D7363726F6C6C2D70726F67726573732D6261722D766572746963616C207B0D0A202020207472616E7366';
wwv_flow_imp.g_varchar2_table(5) := '6F726D3A20726F74617465283930646567293B0D0A7D0D0A0D0A2E617065782D7363726F6C6C2D70726F67726573732D6261722D6D6972726F72696E67207B0D0A202020207472616E73666F726D3A207363616C65282D31293B0D0A7D0D0A0D0A2E6170';
wwv_flow_imp.g_varchar2_table(6) := '65782D7363726F6C6C2D70726F67726573732D6261722D766572746963616C2D6D6972726F72696E67207B0D0A202020207472616E73666F726D3A20726F7461746528393064656729207363616C65282D31293B0D0A7D';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713546341457937106)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'css/style.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E617065782D7363726F6C6C2D70726F67726573732D6261727B6261636B67726F756E642D636F6C6F723A7472616E73706172656E743B6865696768743A3570783B77696474683A2D7765626B69742D66696C6C2D617661696C61626C653B7A2D696E64';
wwv_flow_imp.g_varchar2_table(2) := '65783A3130307D2E617065782D7363726F6C6C2D70726F67726573732D6261722D6C6566747B7472616E73666F726D2D6F726967696E3A6C6566743B6C6566743A303B706F736974696F6E3A6162736F6C7574657D2E617065782D7363726F6C6C2D7072';
wwv_flow_imp.g_varchar2_table(3) := '6F67726573732D6261722D72696768747B7472616E73666F726D2D6F726967696E3A72696768743B72696768743A303B706F736974696F6E3A6162736F6C7574657D2E617065782D7363726F6C6C2D70726F67726573732D6261722D766572746963616C';
wwv_flow_imp.g_varchar2_table(4) := '7B7472616E73666F726D3A726F74617465283930646567297D2E617065782D7363726F6C6C2D70726F67726573732D6261722D6D6972726F72696E677B7472616E73666F726D3A7363616C65282D31297D2E617065782D7363726F6C6C2D70726F677265';
wwv_flow_imp.g_varchar2_table(5) := '73732D6261722D766572746963616C2D6D6972726F72696E677B7472616E73666F726D3A726F7461746528393064656729207363616C65282D31297D';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713546739580937106)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'css/style.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2A204E50726F67726573732C2028632920323031332C2032303134205269636F205374612E204372757A202D20687474703A2F2F7269636F7374616372757A2E636F6D2F6E70726F67726573730D0A202A20406C6963656E7365204D4954202A2F0D0A';
wwv_flow_imp.g_varchar2_table(2) := '0D0A3B2866756E6374696F6E28726F6F742C20666163746F727929207B0D0A0D0A202069662028747970656F6620646566696E65203D3D3D202766756E6374696F6E2720262620646566696E652E616D6429207B0D0A20202020646566696E652866756E';
wwv_flow_imp.g_varchar2_table(3) := '6374696F6E2829207B72657475726E20666163746F72797D293B0D0A20207D20656C73652069662028747970656F66206578706F727473203D3D3D20276F626A6563742729207B0D0A202020206D6F64756C652E6578706F727473203D20666163746F72';
wwv_flow_imp.g_varchar2_table(4) := '793B0D0A20207D20656C7365207B0D0A20202020726F6F742E4E50726F6772657373203D20666163746F72793B0D0A20207D0D0A0D0A7D2928746869732C2066756E6374696F6E2829207B0D0A2020766172204E50726F6772657373203D207B7D3B0D0A';
wwv_flow_imp.g_varchar2_table(5) := '0D0A20204E50726F67726573732E76657273696F6E203D2027302E332E30273B0D0A0D0A20207661722053657474696E6773203D204E50726F67726573732E73657474696E6773203D207B0D0A202020206D696E696D756D3A20302C0D0A202020206561';
wwv_flow_imp.g_varchar2_table(6) := '73696E673A20276C696E656172272C0D0A20202020706F736974696F6E5573696E673A2027272C0D0A2020202073706565643A203230302C0D0A20202020747269636B6C653A20747275652C0D0A20202020747269636B6C6553706565643A203230302C';
wwv_flow_imp.g_varchar2_table(7) := '0D0A2020202073686F775370696E6E65723A20747275652C0D0A2020202062617253656C6563746F723A20275B726F6C653D22626172225D272C0D0A202020207370696E6E657253656C6563746F723A20275B726F6C653D227370696E6E6572225D272C';
wwv_flow_imp.g_varchar2_table(8) := '0D0A20202020706172656E743A2027626F6479272C0D0A2020202074656D706C6174653A20273C64697620636C6173733D226261722220726F6C653D22626172223E3C2F6469763E272C0D0A2020202072656D6F76654F6E46696E6973683A2066616C73';
wwv_flow_imp.g_varchar2_table(9) := '652C0D0A20202020626172436F6C6F723A202223433734363334222C0D0A202020206261724865696768743A2022357078220D0A20207D3B0D0A0D0A20202F2A2A0D0A2020202A205570646174657320636F6E66696775726174696F6E2E0D0A2020202A';
wwv_flow_imp.g_varchar2_table(10) := '0D0A2020202A20202020204E50726F67726573732E636F6E666967757265287B0D0A2020202A202020202020206D696E696D756D3A20302E310D0A2020202A20202020207D293B0D0A2020202A2F0D0A20204E50726F67726573732E636F6E6669677572';
wwv_flow_imp.g_varchar2_table(11) := '65203D2066756E6374696F6E286F7074696F6E7329207B0D0A20202020766172206B65792C2076616C75653B0D0A20202020666F7220286B657920696E206F7074696F6E7329207B0D0A20202020202076616C7565203D206F7074696F6E735B6B65795D';
wwv_flow_imp.g_varchar2_table(12) := '3B0D0A2020202020206966202876616C756520213D3D20756E646566696E6564202626206F7074696F6E732E6861734F776E50726F7065727479286B657929292053657474696E67735B6B65795D203D2076616C75653B0D0A202020207D0D0A0D0A2020';
wwv_flow_imp.g_varchar2_table(13) := '202072657475726E20746869733B0D0A20207D3B0D0A0D0A20202F2A2A0D0A2020202A204C617374206E756D6265722E0D0A2020202A2F0D0A0D0A20204E50726F67726573732E737461747573203D206E756C6C3B0D0A0D0A20202F2A2A0D0A2020202A';
wwv_flow_imp.g_varchar2_table(14) := '2053657473207468652070726F677265737320626172207374617475732C20776865726520606E602069732061206E756D6265722066726F6D2060302E306020746F2060312E30602E0D0A2020202A0D0A2020202A20202020204E50726F67726573732E';
wwv_flow_imp.g_varchar2_table(15) := '73657428302E34293B0D0A2020202A20202020204E50726F67726573732E73657428312E30293B0D0A2020202A2F0D0A0D0A20204E50726F67726573732E736574203D2066756E6374696F6E286E29207B0D0A202020207661722073746172746564203D';
wwv_flow_imp.g_varchar2_table(16) := '204E50726F67726573732E69735374617274656428293B0D0A0D0A202020206E203D20636C616D70286E2C2053657474696E67732E6D696E696D756D2C2031293B0D0A202020204E50726F67726573732E737461747573203D20286E203D3D3D2031203F';
wwv_flow_imp.g_varchar2_table(17) := '206E756C6C203A206E293B0D0A0D0A202020207661722070726F6772657373203D204E50726F67726573732E72656E646572282173746172746564292C0D0A20202020202020206261722020202020203D2070726F67726573732E717565727953656C65';
wwv_flow_imp.g_varchar2_table(18) := '63746F722853657474696E67732E62617253656C6563746F72292C0D0A20202020202020207370656564202020203D2053657474696E67732E73706565642C0D0A20202020202020206561736520202020203D2053657474696E67732E656173696E673B';
wwv_flow_imp.g_varchar2_table(19) := '0D0A0D0A2020202070726F67726573732E6F666673657457696474683B202F2A2052657061696E74202A2F0D0A0D0A2020202071756575652866756E6374696F6E286E65787429207B0D0A2020202020202F2F2053657420706F736974696F6E5573696E';
wwv_flow_imp.g_varchar2_table(20) := '67206966206974206861736E277420616C7265616479206265656E207365740D0A2020202020206966202853657474696E67732E706F736974696F6E5573696E67203D3D3D202727292053657474696E67732E706F736974696F6E5573696E67203D204E';
wwv_flow_imp.g_varchar2_table(21) := '50726F67726573732E676574506F736974696F6E696E6743535328293B0D0A0D0A2020202020202F2F20416464207472616E736974696F6E0D0A202020202020637373286261722C20626172506F736974696F6E435353286E2C2073706565642C206561';
wwv_flow_imp.g_varchar2_table(22) := '736529293B0D0A0D0A202020202020696620286E203D3D3D203129207B0D0A20202020202020202F2F2046616465206F75740D0A20202020202020206373732870726F67726573732C207B0D0A202020202020202020207472616E736974696F6E3A2027';
wwv_flow_imp.g_varchar2_table(23) := '6E6F6E65272C0D0A202020202020202020206F7061636974793A20310D0A20202020202020207D293B0D0A202020202020202070726F67726573732E6F666673657457696474683B202F2A2052657061696E74202A2F0D0A0D0A20202020202020207365';
wwv_flow_imp.g_varchar2_table(24) := '7454696D656F75742866756E6374696F6E2829207B0D0A202020202020202020206373732870726F67726573732C207B0D0A2020202020202020202020207472616E736974696F6E3A2027616C6C2027202B207370656564202B20276D73206C696E6561';
wwv_flow_imp.g_varchar2_table(25) := '72272C0D0A2020202020202020202020206F7061636974793A2053657474696E67732E72656D6F76654F6E46696E697368203F2030203A20310D0A202020202020202020207D293B0D0A2020202020202020202073657454696D656F75742866756E6374';
wwv_flow_imp.g_varchar2_table(26) := '696F6E2829207B0D0A20202020202020202020202069662853657474696E67732E72656D6F76654F6E46696E69736829207B20200D0A202020202020202020202020202020204E50726F67726573732E72656D6F766528293B0D0A202020202020202020';
wwv_flow_imp.g_varchar2_table(27) := '2020207D3B0D0A2020202020202020202020206E65787428293B0D0A202020202020202020207D2C207370656564293B0D0A20202020202020207D2C207370656564293B0D0A2020202020207D20656C7365207B0D0A202020202020202073657454696D';
wwv_flow_imp.g_varchar2_table(28) := '656F7574286E6578742C207370656564293B0D0A2020202020207D0D0A202020207D293B0D0A0D0A2020202072657475726E20746869733B0D0A20207D3B0D0A0D0A20204E50726F67726573732E697353746172746564203D2066756E6374696F6E2829';
wwv_flow_imp.g_varchar2_table(29) := '207B0D0A2020202072657475726E20747970656F66204E50726F67726573732E737461747573203D3D3D20276E756D626572273B0D0A20207D3B0D0A0D0A20202F2A2A0D0A2020202A2053686F7773207468652070726F6772657373206261722E0D0A20';
wwv_flow_imp.g_varchar2_table(30) := '20202A2054686973206973207468652073616D652061732073657474696E67207468652073746174757320746F2030252C20657863657074207468617420697420646F65736E277420676F206261636B77617264732E0D0A2020202A0D0A2020202A2020';
wwv_flow_imp.g_varchar2_table(31) := '2020204E50726F67726573732E737461727428293B0D0A2020202A0D0A2020202A2F0D0A20204E50726F67726573732E7374617274203D2066756E6374696F6E2829207B0D0A2020202069662028214E50726F67726573732E73746174757329204E5072';
wwv_flow_imp.g_varchar2_table(32) := '6F67726573732E7365742830293B0D0A0D0A2020202076617220776F726B203D2066756E6374696F6E2829207B0D0A20202020202073657454696D656F75742866756E6374696F6E2829207B0D0A202020202020202069662028214E50726F6772657373';
wwv_flow_imp.g_varchar2_table(33) := '2E737461747573292072657475726E3B0D0A20202020202020204E50726F67726573732E747269636B6C6528293B0D0A2020202020202020776F726B28293B0D0A2020202020207D2C2053657474696E67732E747269636B6C655370656564293B0D0A20';
wwv_flow_imp.g_varchar2_table(34) := '2020207D3B0D0A0D0A202020206966202853657474696E67732E747269636B6C652920776F726B28293B0D0A0D0A2020202072657475726E20746869733B0D0A20207D3B0D0A0D0A20202F2A2A0D0A2020202A204869646573207468652070726F677265';
wwv_flow_imp.g_varchar2_table(35) := '7373206261722E0D0A2020202A205468697320697320746865202A736F7274206F662A207468652073616D652061732073657474696E67207468652073746174757320746F20313030252C2077697468207468650D0A2020202A20646966666572656E63';
wwv_flow_imp.g_varchar2_table(36) := '65206265696E672060646F6E65282960206D616B657320736F6D6520706C616365626F20656666656374206F6620736F6D65207265616C6973746963206D6F74696F6E2E0D0A2020202A0D0A2020202A20202020204E50726F67726573732E646F6E6528';
wwv_flow_imp.g_varchar2_table(37) := '293B0D0A2020202A0D0A2020202A20496620607472756560206973207061737365642C2069742077696C6C2073686F77207468652070726F677265737320626172206576656E206966206974732068696464656E2E0D0A2020202A0D0A2020202A202020';
wwv_flow_imp.g_varchar2_table(38) := '20204E50726F67726573732E646F6E652874727565293B0D0A2020202A2F0D0A0D0A20204E50726F67726573732E646F6E65203D2066756E6374696F6E28666F72636529207B0D0A202020206966202821666F72636520262620214E50726F6772657373';
wwv_flow_imp.g_varchar2_table(39) := '2E737461747573292072657475726E20746869733B0D0A0D0A2020202072657475726E204E50726F67726573732E696E6328302E33202B20302E35202A204D6174682E72616E646F6D2829292E7365742831293B0D0A20207D3B0D0A0D0A20202F2A2A0D';
wwv_flow_imp.g_varchar2_table(40) := '0A2020202A20496E6372656D656E747320627920612072616E646F6D20616D6F756E742E0D0A2020202A2F0D0A0D0A20204E50726F67726573732E696E63203D2066756E6374696F6E28616D6F756E7429207B0D0A20202020766172206E203D204E5072';
wwv_flow_imp.g_varchar2_table(41) := '6F67726573732E7374617475733B0D0A0D0A2020202069662028216E29207B0D0A20202020202072657475726E204E50726F67726573732E737461727428293B0D0A202020207D20656C7365206966286E203E203129207B0D0A20202020202072657475';
wwv_flow_imp.g_varchar2_table(42) := '726E3B0D0A202020207D20656C7365207B0D0A20202020202069662028747970656F6620616D6F756E7420213D3D20276E756D6265722729207B0D0A2020202020202020696620286E203E3D2030202626206E203C20302E3229207B20616D6F756E7420';
wwv_flow_imp.g_varchar2_table(43) := '3D20302E313B207D0D0A2020202020202020656C736520696620286E203E3D20302E32202626206E203C20302E3529207B20616D6F756E74203D20302E30343B207D0D0A2020202020202020656C736520696620286E203E3D20302E35202626206E203C';
wwv_flow_imp.g_varchar2_table(44) := '20302E3829207B20616D6F756E74203D20302E30323B207D0D0A2020202020202020656C736520696620286E203E3D20302E38202626206E203C20302E393929207B20616D6F756E74203D20302E3030353B207D0D0A2020202020202020656C7365207B';
wwv_flow_imp.g_varchar2_table(45) := '20616D6F756E74203D20303B207D0D0A2020202020207D0D0A0D0A2020202020206E203D20636C616D70286E202B20616D6F756E742C20302C20302E393934293B0D0A20202020202072657475726E204E50726F67726573732E736574286E293B0D0A20';
wwv_flow_imp.g_varchar2_table(46) := '2020207D0D0A20207D3B0D0A0D0A20204E50726F67726573732E747269636B6C65203D2066756E6374696F6E2829207B0D0A2020202072657475726E204E50726F67726573732E696E6328293B0D0A20207D3B0D0A0D0A20202F2A2A0D0A2020202A2057';
wwv_flow_imp.g_varchar2_table(47) := '6169747320666F7220616C6C20737570706C696564206A51756572792070726F6D6973657320616E640D0A2020202A20696E63726561736573207468652070726F6772657373206173207468652070726F6D69736573207265736F6C76652E0D0A202020';
wwv_flow_imp.g_varchar2_table(48) := '2A0D0A2020202A2040706172616D202470726F6D697365206A51556572792050726F6D6973650D0A2020202A2F0D0A20202866756E6374696F6E2829207B0D0A2020202076617220696E697469616C203D20302C2063757272656E74203D20303B0D0A0D';
wwv_flow_imp.g_varchar2_table(49) := '0A202020204E50726F67726573732E70726F6D697365203D2066756E6374696F6E282470726F6D69736529207B0D0A20202020202069662028212470726F6D697365207C7C202470726F6D6973652E73746174652829203D3D3D20227265736F6C766564';
wwv_flow_imp.g_varchar2_table(50) := '2229207B0D0A202020202020202072657475726E20746869733B0D0A2020202020207D0D0A0D0A2020202020206966202863757272656E74203D3D3D203029207B0D0A20202020202020204E50726F67726573732E737461727428293B0D0A2020202020';
wwv_flow_imp.g_varchar2_table(51) := '207D0D0A0D0A202020202020696E697469616C2B2B3B0D0A20202020202063757272656E742B2B3B0D0A0D0A2020202020202470726F6D6973652E616C776179732866756E6374696F6E2829207B0D0A202020202020202063757272656E742D2D3B0D0A';
wwv_flow_imp.g_varchar2_table(52) := '20202020202020206966202863757272656E74203D3D3D203029207B0D0A202020202020202020202020696E697469616C203D20303B0D0A2020202020202020202020204E50726F67726573732E646F6E6528293B0D0A20202020202020207D20656C73';
wwv_flow_imp.g_varchar2_table(53) := '65207B0D0A2020202020202020202020204E50726F67726573732E7365742828696E697469616C202D2063757272656E7429202F20696E697469616C293B0D0A20202020202020207D0D0A2020202020207D293B0D0A0D0A20202020202072657475726E';
wwv_flow_imp.g_varchar2_table(54) := '20746869733B0D0A202020207D3B0D0A0D0A20207D2928293B0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C2920676574207468652072656E646572656420656C656D656E740D0A2020202A2F0D0A0D0A20204E50726F67726573732E67';
wwv_flow_imp.g_varchar2_table(55) := '6574456C656D656E74203D2066756E6374696F6E2829207B0D0A2020202072657475726E20646F63756D656E742E717565727953656C6563746F722853657474696E67732E706172656E74202B2027203E202E6E70726F677265737327293B0D0A20207D';
wwv_flow_imp.g_varchar2_table(56) := '0D0A0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C292072656E64657273207468652070726F677265737320626172206D61726B7570206261736564206F6E20746865206074656D706C617465600D0A2020202A2073657474696E672E0D';
wwv_flow_imp.g_varchar2_table(57) := '0A2020202A2F0D0A0D0A20204E50726F67726573732E72656E646572203D2066756E6374696F6E2866726F6D537461727429207B0D0A20202020696620284E50726F67726573732E697352656E64657265642829292072657475726E204E50726F677265';
wwv_flow_imp.g_varchar2_table(58) := '73732E676574456C656D656E7428293B0D0A0D0A20202020616464436C61737328646F63756D656E742E646F63756D656E74456C656D656E742C20276E70726F67726573732D6275737927293B0D0A0D0A202020207661722070726F6772657373203D20';
wwv_flow_imp.g_varchar2_table(59) := '646F63756D656E742E637265617465456C656D656E74282764697627293B0D0A2020202070726F67726573732E6964203D20276E70726F6772657373273B0D0A2020202070726F67726573732E636C6173734E616D65203D20276E70726F677265737327';
wwv_flow_imp.g_varchar2_table(60) := '3B0D0A2020202070726F67726573732E696E6E657248544D4C203D2053657474696E67732E74656D706C6174653B0D0A0D0A20202020766172206261722020202020203D2070726F67726573732E717565727953656C6563746F722853657474696E6773';
wwv_flow_imp.g_varchar2_table(61) := '2E62617253656C6563746F72292C0D0A20202020202020207065726320202020203D2066726F6D5374617274203F20272D31303027203A20746F42617250657263284E50726F67726573732E737461747573207C7C2030292C0D0A202020202020202070';
wwv_flow_imp.g_varchar2_table(62) := '6172656E742020203D20646F63756D656E742E717565727953656C6563746F722853657474696E67732E706172656E74292C0D0A20202020202020207370696E6E65723B0D0A0D0A202020206261722E7374796C652E6261636B67726F756E64203D2053';
wwv_flow_imp.g_varchar2_table(63) := '657474696E67732E626172436F6C6F723B0D0A202020206261722E7374796C652E68656967687420202020203D2053657474696E67732E626172486569676874202B20277078273B0D0A0D0A20202020637373286261722C207B0D0A2020202020207472';
wwv_flow_imp.g_varchar2_table(64) := '616E736974696F6E3A2027616C6C2030206C696E656172272C0D0A2020202020207472616E73666F726D3A20277472616E736C61746533642827202B2070657263202B2027252C302C3029270D0A202020207D293B0D0A0D0A2020202069662028215365';
wwv_flow_imp.g_varchar2_table(65) := '7474696E67732E73686F775370696E6E657229207B0D0A2020202020207370696E6E6572203D2070726F67726573732E717565727953656C6563746F722853657474696E67732E7370696E6E657253656C6563746F72293B0D0A2020202020207370696E';
wwv_flow_imp.g_varchar2_table(66) := '6E65722026262072656D6F7665456C656D656E74287370696E6E6572293B0D0A202020207D0D0A0D0A2020202069662028706172656E7420213D20646F63756D656E742E626F647929207B0D0A202020202020616464436C61737328706172656E742C20';
wwv_flow_imp.g_varchar2_table(67) := '276E70726F67726573732D637573746F6D2D706172656E7427293B0D0A202020207D0D0A0D0A20202020706172656E742E617070656E644368696C642870726F6772657373293B0D0A2020202072657475726E2070726F67726573733B0D0A20207D3B0D';
wwv_flow_imp.g_varchar2_table(68) := '0A0D0A20202F2A2A0D0A2020202A2052656D6F7665732074686520656C656D656E742E204F70706F73697465206F662072656E64657228292E0D0A2020202A2F0D0A0D0A20204E50726F67726573732E72656D6F7665203D2066756E6374696F6E282920';
wwv_flow_imp.g_varchar2_table(69) := '7B0D0A202020204E50726F67726573732E737461747573203D206E756C6C3B0D0A2020202072656D6F7665436C61737328646F63756D656E742E646F63756D656E74456C656D656E742C20276E70726F67726573732D6275737927293B0D0A2020202072';
wwv_flow_imp.g_varchar2_table(70) := '656D6F7665436C61737328646F63756D656E742E717565727953656C6563746F722853657474696E67732E706172656E74292C20276E70726F67726573732D637573746F6D2D706172656E7427293B0D0A202020207661722070726F6772657373203D20';
wwv_flow_imp.g_varchar2_table(71) := '4E50726F67726573732E676574456C656D656E7428293B0D0A2020202070726F67726573732026262072656D6F7665456C656D656E742870726F6772657373293B0D0A20207D3B0D0A0D0A20202F2A2A0D0A2020202A20436865636B7320696620746865';
wwv_flow_imp.g_varchar2_table(72) := '2070726F6772657373206261722069732072656E64657265642E0D0A2020202A2F0D0A0D0A20204E50726F67726573732E697352656E6465726564203D2066756E6374696F6E2829207B0D0A2020202072657475726E2021214E50726F67726573732E67';
wwv_flow_imp.g_varchar2_table(73) := '6574456C656D656E7428293B0D0A20207D3B0D0A0D0A20202F2A2A0D0A2020202A2044657465726D696E6520776869636820706F736974696F6E696E67204353532072756C6520746F207573652E0D0A2020202A2F0D0A0D0A20204E50726F6772657373';
wwv_flow_imp.g_varchar2_table(74) := '2E676574506F736974696F6E696E67435353203D2066756E6374696F6E2829207B0D0A202020202F2F20536E696666206F6E20646F63756D656E742E626F64792E7374796C650D0A2020202076617220626F64795374796C65203D20646F63756D656E74';
wwv_flow_imp.g_varchar2_table(75) := '2E626F64792E7374796C653B0D0A0D0A202020202F2F20536E6966662070726566697865730D0A202020207661722076656E646F72507265666978203D2028275765626B69745472616E73666F726D2720696E20626F64795374796C6529203F20275765';
wwv_flow_imp.g_varchar2_table(76) := '626B697427203A0D0A202020202020202020202020202020202020202020202028274D6F7A5472616E73666F726D2720696E20626F64795374796C6529203F20274D6F7A27203A0D0A202020202020202020202020202020202020202020202028276D73';
wwv_flow_imp.g_varchar2_table(77) := '5472616E73666F726D2720696E20626F64795374796C6529203F20276D7327203A0D0A202020202020202020202020202020202020202020202028274F5472616E73666F726D2720696E20626F64795374796C6529203F20274F27203A2027273B0D0A0D';
wwv_flow_imp.g_varchar2_table(78) := '0A202020206966202876656E646F72507265666978202B202750657273706563746976652720696E20626F64795374796C6529207B0D0A2020202020202F2F204D6F6465726E2062726F7773657273207769746820334420737570706F72742C20652E67';
wwv_flow_imp.g_varchar2_table(79) := '2E205765626B69742C20494531300D0A20202020202072657475726E20277472616E736C6174653364273B0D0A202020207D20656C7365206966202876656E646F72507265666978202B20275472616E73666F726D2720696E20626F64795374796C6529';
wwv_flow_imp.g_varchar2_table(80) := '207B0D0A2020202020202F2F2042726F777365727320776974686F757420334420737570706F72742C20652E672E204945390D0A20202020202072657475726E20277472616E736C617465273B0D0A202020207D20656C7365207B0D0A2020202020202F';
wwv_flow_imp.g_varchar2_table(81) := '2F2042726F777365727320776974686F7574207472616E736C617465282920737570706F72742C20652E672E204945372D380D0A20202020202072657475726E20276D617267696E273B0D0A202020207D0D0A20207D3B0D0A0D0A20202F2A2A0D0A2020';
wwv_flow_imp.g_varchar2_table(82) := '202A2048656C706572730D0A2020202A2F0D0A0D0A202066756E6374696F6E20636C616D70286E2C206D696E2C206D617829207B0D0A20202020696620286E203C206D696E292072657475726E206D696E3B0D0A20202020696620286E203E206D617829';
wwv_flow_imp.g_varchar2_table(83) := '2072657475726E206D61783B0D0A2020202072657475726E206E3B0D0A20207D0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C2920636F6E766572747320612070657263656E74616765202860302E2E31602920746F2061206261722074';
wwv_flow_imp.g_varchar2_table(84) := '72616E736C617465580D0A2020202A2070657263656E746167652028602D313030252E2E302560292E0D0A2020202A2F0D0A0D0A202066756E6374696F6E20746F42617250657263286E29207B0D0A2020202072657475726E20282D31202B206E29202A';
wwv_flow_imp.g_varchar2_table(85) := '203130303B0D0A20207D0D0A0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C292072657475726E732074686520636F72726563742043535320666F72206368616E67696E67207468652062617227730D0A2020202A20706F736974696F6E';
wwv_flow_imp.g_varchar2_table(86) := '20676976656E20616E206E2070657263656E746167652C20616E6420737065656420616E6420656173652066726F6D2053657474696E67730D0A2020202A2F0D0A0D0A202066756E6374696F6E20626172506F736974696F6E435353286E2C2073706565';
wwv_flow_imp.g_varchar2_table(87) := '642C206561736529207B0D0A20202020766172206261724353533B0D0A0D0A202020206966202853657474696E67732E706F736974696F6E5573696E67203D3D3D20277472616E736C61746533642729207B0D0A202020202020626172435353203D207B';
wwv_flow_imp.g_varchar2_table(88) := '207472616E73666F726D3A20277472616E736C617465336428272B746F42617250657263286E292B27252C302C302927207D3B0D0A202020207D20656C7365206966202853657474696E67732E706F736974696F6E5573696E67203D3D3D20277472616E';
wwv_flow_imp.g_varchar2_table(89) := '736C6174652729207B0D0A202020202020626172435353203D207B207472616E73666F726D3A20277472616E736C61746528272B746F42617250657263286E292B27252C302927207D3B0D0A202020207D20656C7365207B0D0A20202020202062617243';
wwv_flow_imp.g_varchar2_table(90) := '5353203D207B20276D617267696E2D6C656674273A20746F42617250657263286E292B272527207D3B0D0A202020207D0D0A0D0A202020206261724353532E7472616E736974696F6E203D2027616C6C20272B73706565642B276D7320272B656173653B';
wwv_flow_imp.g_varchar2_table(91) := '0D0A0D0A2020202072657475726E206261724353533B0D0A20207D0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C292051756575657320612066756E6374696F6E20746F2062652065786563757465642E0D0A2020202A2F0D0A0D0A2020';
wwv_flow_imp.g_varchar2_table(92) := '766172207175657565203D202866756E6374696F6E2829207B0D0A202020207661722070656E64696E67203D205B5D3B0D0A0D0A2020202066756E6374696F6E206E6578742829207B0D0A20202020202076617220666E203D2070656E64696E672E7368';
wwv_flow_imp.g_varchar2_table(93) := '69667428293B0D0A20202020202069662028666E29207B0D0A2020202020202020666E286E657874293B0D0A2020202020207D0D0A202020207D0D0A0D0A2020202072657475726E2066756E6374696F6E28666E29207B0D0A20202020202070656E6469';
wwv_flow_imp.g_varchar2_table(94) := '6E672E7075736828666E293B0D0A2020202020206966202870656E64696E672E6C656E677468203D3D203129206E65787428293B0D0A202020207D3B0D0A20207D2928293B0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C29204170706C';
wwv_flow_imp.g_varchar2_table(95) := '696573206373732070726F7065727469657320746F20616E20656C656D656E742C2073696D696C617220746F20746865206A51756572790D0A2020202A20637373206D6574686F642E0D0A2020202A0D0A2020202A205768696C6520746869732068656C';
wwv_flow_imp.g_varchar2_table(96) := '70657220646F65732061737369737420776974682076656E646F722070726566697865642070726F7065727479206E616D65732C2069740D0A2020202A20646F6573206E6F7420706572666F726D20616E79206D616E6970756C6174696F6E206F662076';
wwv_flow_imp.g_varchar2_table(97) := '616C756573207072696F7220746F2073657474696E67207374796C65732E0D0A2020202A2F0D0A0D0A202076617220637373203D202866756E6374696F6E2829207B0D0A20202020766172206373735072656669786573203D205B20275765626B697427';
wwv_flow_imp.g_varchar2_table(98) := '2C20274F272C20274D6F7A272C20276D7327205D2C0D0A202020202020202063737350726F7073202020203D207B7D3B0D0A0D0A2020202066756E6374696F6E2063616D656C4361736528737472696E6729207B0D0A20202020202072657475726E2073';
wwv_flow_imp.g_varchar2_table(99) := '7472696E672E7265706C616365282F5E2D6D732D2F2C20276D732D27292E7265706C616365282F2D285B5C64612D7A5D292F67692C2066756E6374696F6E286D617463682C206C657474657229207B0D0A202020202020202072657475726E206C657474';
wwv_flow_imp.g_varchar2_table(100) := '65722E746F55707065724361736528293B0D0A2020202020207D293B0D0A202020207D0D0A0D0A2020202066756E6374696F6E2067657456656E646F7250726F70286E616D6529207B0D0A202020202020766172207374796C65203D20646F63756D656E';
wwv_flow_imp.g_varchar2_table(101) := '742E626F64792E7374796C653B0D0A202020202020696620286E616D6520696E207374796C65292072657475726E206E616D653B0D0A0D0A2020202020207661722069203D2063737350726566697865732E6C656E6774682C0D0A202020202020202020';
wwv_flow_imp.g_varchar2_table(102) := '206361704E616D65203D206E616D652E6368617241742830292E746F5570706572436173652829202B206E616D652E736C6963652831292C0D0A2020202020202020202076656E646F724E616D653B0D0A2020202020207768696C652028692D2D29207B';
wwv_flow_imp.g_varchar2_table(103) := '0D0A202020202020202076656E646F724E616D65203D2063737350726566697865735B695D202B206361704E616D653B0D0A20202020202020206966202876656E646F724E616D6520696E207374796C65292072657475726E2076656E646F724E616D65';
wwv_flow_imp.g_varchar2_table(104) := '3B0D0A2020202020207D0D0A0D0A20202020202072657475726E206E616D653B0D0A202020207D0D0A0D0A2020202066756E6374696F6E206765745374796C6550726F70286E616D6529207B0D0A2020202020206E616D65203D2063616D656C43617365';
wwv_flow_imp.g_varchar2_table(105) := '286E616D65293B0D0A20202020202072657475726E2063737350726F70735B6E616D655D207C7C202863737350726F70735B6E616D655D203D2067657456656E646F7250726F70286E616D6529293B0D0A202020207D0D0A0D0A2020202066756E637469';
wwv_flow_imp.g_varchar2_table(106) := '6F6E206170706C7943737328656C656D656E742C2070726F702C2076616C756529207B0D0A20202020202070726F70203D206765745374796C6550726F702870726F70293B0D0A202020202020656C656D656E742E7374796C655B70726F705D203D2076';
wwv_flow_imp.g_varchar2_table(107) := '616C75653B0D0A202020207D0D0A0D0A2020202072657475726E2066756E6374696F6E28656C656D656E742C2070726F7065727469657329207B0D0A2020202020207661722061726773203D20617267756D656E74732C0D0A2020202020202020202070';
wwv_flow_imp.g_varchar2_table(108) := '726F702C0D0A2020202020202020202076616C75653B0D0A0D0A20202020202069662028617267732E6C656E677468203D3D203229207B0D0A2020202020202020666F72202870726F7020696E2070726F7065727469657329207B0D0A20202020202020';
wwv_flow_imp.g_varchar2_table(109) := '20202076616C7565203D2070726F706572746965735B70726F705D3B0D0A202020202020202020206966202876616C756520213D3D20756E646566696E65642026262070726F706572746965732E6861734F776E50726F70657274792870726F70292920';
wwv_flow_imp.g_varchar2_table(110) := '6170706C7943737328656C656D656E742C2070726F702C2076616C7565293B0D0A20202020202020207D0D0A2020202020207D20656C7365207B0D0A20202020202020206170706C7943737328656C656D656E742C20617267735B315D2C20617267735B';
wwv_flow_imp.g_varchar2_table(111) := '325D293B0D0A2020202020207D0D0A202020207D0D0A20207D2928293B0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C292044657465726D696E657320696620616E20656C656D656E74206F722073706163652073657061726174656420';
wwv_flow_imp.g_varchar2_table(112) := '6C697374206F6620636C617373206E616D657320636F6E7461696E73206120636C617373206E616D652E0D0A2020202A2F0D0A0D0A202066756E6374696F6E20686173436C61737328656C656D656E742C206E616D6529207B0D0A20202020766172206C';
wwv_flow_imp.g_varchar2_table(113) := '697374203D20747970656F6620656C656D656E74203D3D2027737472696E6727203F20656C656D656E74203A20636C6173734C69737428656C656D656E74293B0D0A2020202072657475726E206C6973742E696E6465784F6628272027202B206E616D65';
wwv_flow_imp.g_varchar2_table(114) := '202B2027202729203E3D20303B0D0A20207D0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C292041646473206120636C61737320746F20616E20656C656D656E742E0D0A2020202A2F0D0A0D0A202066756E6374696F6E20616464436C61';
wwv_flow_imp.g_varchar2_table(115) := '737328656C656D656E742C206E616D6529207B0D0A20202020766172206F6C644C697374203D20636C6173734C69737428656C656D656E74292C0D0A20202020202020206E65774C697374203D206F6C644C697374202B206E616D653B0D0A0D0A202020';
wwv_flow_imp.g_varchar2_table(116) := '2069662028686173436C617373286F6C644C6973742C206E616D6529292072657475726E3B0D0A0D0A202020202F2F205472696D20746865206F70656E696E672073706163652E0D0A20202020656C656D656E742E636C6173734E616D65203D206E6577';
wwv_flow_imp.g_varchar2_table(117) := '4C6973742E737562737472696E672831293B0D0A20207D0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C292052656D6F766573206120636C6173732066726F6D20616E20656C656D656E742E0D0A2020202A2F0D0A0D0A202066756E6374';
wwv_flow_imp.g_varchar2_table(118) := '696F6E2072656D6F7665436C61737328656C656D656E742C206E616D6529207B0D0A20202020766172206F6C644C697374203D20636C6173734C69737428656C656D656E74292C0D0A20202020202020206E65774C6973743B0D0A0D0A20202020696620';
wwv_flow_imp.g_varchar2_table(119) := '2821686173436C61737328656C656D656E742C206E616D6529292072657475726E3B0D0A0D0A202020202F2F205265706C6163652074686520636C617373206E616D652E0D0A202020206E65774C697374203D206F6C644C6973742E7265706C61636528';
wwv_flow_imp.g_varchar2_table(120) := '272027202B206E616D65202B202720272C20272027293B0D0A0D0A202020202F2F205472696D20746865206F70656E696E6720616E6420636C6F73696E67207370616365732E0D0A20202020656C656D656E742E636C6173734E616D65203D206E65774C';
wwv_flow_imp.g_varchar2_table(121) := '6973742E737562737472696E6728312C206E65774C6973742E6C656E677468202D2031293B0D0A20207D0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C292047657473206120737061636520736570617261746564206C697374206F6620';
wwv_flow_imp.g_varchar2_table(122) := '74686520636C617373206E616D6573206F6E2074686520656C656D656E742E0D0A2020202A20546865206C6973742069732077726170706564207769746820612073696E676C65207370616365206F6E206561636820656E6420746F20666163696C6974';
wwv_flow_imp.g_varchar2_table(123) := '6174652066696E64696E670D0A2020202A206D6174636865732077697468696E20746865206C6973742E0D0A2020202A2F0D0A0D0A202066756E6374696F6E20636C6173734C69737428656C656D656E7429207B0D0A2020202072657475726E20282720';
wwv_flow_imp.g_varchar2_table(124) := '27202B2028656C656D656E7420262620656C656D656E742E636C6173734E616D65207C7C20272729202B20272027292E7265706C616365282F5C732B2F67692C20272027293B0D0A20207D0D0A0D0A20202F2A2A0D0A2020202A2028496E7465726E616C';
wwv_flow_imp.g_varchar2_table(125) := '292052656D6F76657320616E20656C656D656E742066726F6D2074686520444F4D2E0D0A2020202A2F0D0A0D0A202066756E6374696F6E2072656D6F7665456C656D656E7428656C656D656E7429207B0D0A20202020656C656D656E7420262620656C65';
wwv_flow_imp.g_varchar2_table(126) := '6D656E742E706172656E744E6F646520262620656C656D656E742E706172656E744E6F64652E72656D6F76654368696C6428656C656D656E74293B0D0A20207D0D0A0D0A202072657475726E204E50726F67726573733B0D0A7D293B';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713547181236937107)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'js/nprogress.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2A204E50726F67726573732C2028632920323031332C2032303134205269636F205374612E204372757A202D20687474703A2F2F7269636F7374616372757A2E636F6D2F6E70726F67726573730A202A20406C6963656E7365204D4954202A2F0A2166';
wwv_flow_imp.g_varchar2_table(2) := '756E6374696F6E28652C6E297B2266756E6374696F6E223D3D747970656F6620646566696E652626646566696E652E616D643F646566696E65282866756E6374696F6E28297B72657475726E206E7D29293A226F626A656374223D3D747970656F662065';
wwv_flow_imp.g_varchar2_table(3) := '78706F7274733F6D6F64756C652E6578706F7274733D6E3A652E4E50726F67726573733D6E7D28746869732C2866756E6374696F6E28297B76617220652C6E2C743D7B76657273696F6E3A22302E332E30227D2C723D742E73657474696E67733D7B6D69';
wwv_flow_imp.g_varchar2_table(4) := '6E696D756D3A302C656173696E673A226C696E656172222C706F736974696F6E5573696E673A22222C73706565643A3230302C747269636B6C653A21302C747269636B6C6553706565643A3230302C73686F775370696E6E65723A21302C62617253656C';
wwv_flow_imp.g_varchar2_table(5) := '6563746F723A275B726F6C653D22626172225D272C7370696E6E657253656C6563746F723A275B726F6C653D227370696E6E6572225D272C706172656E743A22626F6479222C74656D706C6174653A273C64697620636C6173733D226261722220726F6C';
wwv_flow_imp.g_varchar2_table(6) := '653D22626172223E3C2F6469763E272C72656D6F76654F6E46696E6973683A21312C626172436F6C6F723A2223433734363334222C6261724865696768743A22357078227D3B66756E6374696F6E206928652C6E2C74297B72657475726E20653C6E3F6E';
wwv_flow_imp.g_varchar2_table(7) := '3A653E743F743A657D66756E6374696F6E206F2865297B72657475726E203130302A282D312B65297D742E636F6E6669677572653D66756E6374696F6E2865297B766172206E2C743B666F72286E20696E206529766F69642030213D3D28743D655B6E5D';
wwv_flow_imp.g_varchar2_table(8) := '292626652E6861734F776E50726F7065727479286E29262628725B6E5D3D74293B72657475726E20746869737D2C742E7374617475733D6E756C6C2C742E7365743D66756E6374696F6E2865297B766172206E3D742E69735374617274656428293B653D';
wwv_flow_imp.g_varchar2_table(9) := '6928652C722E6D696E696D756D2C31292C742E7374617475733D313D3D3D653F6E756C6C3A653B76617220753D742E72656E64657228216E292C633D752E717565727953656C6563746F7228722E62617253656C6563746F72292C6C3D722E7370656564';
wwv_flow_imp.g_varchar2_table(10) := '2C663D722E656173696E673B72657475726E20752E6F666673657457696474682C73282866756E6374696F6E286E297B22223D3D3D722E706F736974696F6E5573696E67262628722E706F736974696F6E5573696E673D742E676574506F736974696F6E';
wwv_flow_imp.g_varchar2_table(11) := '696E674353532829292C6128632C66756E6374696F6E28652C6E2C74297B76617220693B693D227472616E736C6174653364223D3D3D722E706F736974696F6E5573696E673F7B7472616E73666F726D3A227472616E736C617465336428222B6F286529';
wwv_flow_imp.g_varchar2_table(12) := '2B22252C302C3029227D3A227472616E736C617465223D3D3D722E706F736974696F6E5573696E673F7B7472616E73666F726D3A227472616E736C61746528222B6F2865292B22252C3029227D3A7B226D617267696E2D6C656674223A6F2865292B2225';
wwv_flow_imp.g_varchar2_table(13) := '227D3B72657475726E20692E7472616E736974696F6E3D22616C6C20222B6E2B226D7320222B742C697D28652C6C2C6629292C313D3D3D653F286128752C7B7472616E736974696F6E3A226E6F6E65222C6F7061636974793A317D292C752E6F66667365';
wwv_flow_imp.g_varchar2_table(14) := '7457696474682C73657454696D656F7574282866756E6374696F6E28297B6128752C7B7472616E736974696F6E3A22616C6C20222B6C2B226D73206C696E656172222C6F7061636974793A722E72656D6F76654F6E46696E6973683F303A317D292C7365';
wwv_flow_imp.g_varchar2_table(15) := '7454696D656F7574282866756E6374696F6E28297B722E72656D6F76654F6E46696E6973682626742E72656D6F766528292C6E28297D292C6C297D292C6C29293A73657454696D656F7574286E2C6C297D29292C746869737D2C742E6973537461727465';
wwv_flow_imp.g_varchar2_table(16) := '643D66756E6374696F6E28297B72657475726E226E756D626572223D3D747970656F6620742E7374617475737D2C742E73746172743D66756E6374696F6E28297B742E7374617475737C7C742E7365742830293B76617220653D66756E6374696F6E2829';
wwv_flow_imp.g_varchar2_table(17) := '7B73657454696D656F7574282866756E6374696F6E28297B742E737461747573262628742E747269636B6C6528292C652829297D292C722E747269636B6C655370656564297D3B72657475726E20722E747269636B6C6526266528292C746869737D2C74';
wwv_flow_imp.g_varchar2_table(18) := '2E646F6E653D66756E6374696F6E2865297B72657475726E20657C7C742E7374617475733F742E696E63282E332B2E352A4D6174682E72616E646F6D2829292E7365742831293A746869737D2C742E696E633D66756E6374696F6E2865297B766172206E';
wwv_flow_imp.g_varchar2_table(19) := '3D742E7374617475733B72657475726E206E3F6E3E313F766F696420303A28226E756D62657222213D747970656F662065262628653D6E3E3D3026266E3C2E323F2E313A6E3E3D2E3226266E3C2E353F2E30343A6E3E3D2E3526266E3C2E383F2E30323A';
wwv_flow_imp.g_varchar2_table(20) := '6E3E3D2E3826266E3C2E39393F2E3030353A30292C6E3D69286E2B652C302C2E393934292C742E736574286E29293A742E737461727428297D2C742E747269636B6C653D66756E6374696F6E28297B72657475726E20742E696E6328297D2C653D302C6E';
wwv_flow_imp.g_varchar2_table(21) := '3D302C742E70726F6D6973653D66756E6374696F6E2872297B72657475726E20722626227265736F6C76656422213D3D722E737461746528293F28303D3D3D6E2626742E737461727428292C652B2B2C6E2B2B2C722E616C77617973282866756E637469';
wwv_flow_imp.g_varchar2_table(22) := '6F6E28297B303D3D2D2D6E3F28653D302C742E646F6E652829293A742E7365742828652D6E292F65297D29292C74686973293A746869737D2C742E676574456C656D656E743D66756E6374696F6E28297B72657475726E20646F63756D656E742E717565';
wwv_flow_imp.g_varchar2_table(23) := '727953656C6563746F7228722E706172656E742B22203E202E6E70726F677265737322297D2C742E72656E6465723D66756E6374696F6E2865297B696628742E697352656E646572656428292972657475726E20742E676574456C656D656E7428293B63';
wwv_flow_imp.g_varchar2_table(24) := '28646F63756D656E742E646F63756D656E74456C656D656E742C226E70726F67726573732D6275737922293B766172206E3D646F63756D656E742E637265617465456C656D656E74282264697622293B6E2E69643D226E70726F6772657373222C6E2E63';
wwv_flow_imp.g_varchar2_table(25) := '6C6173734E616D653D226E70726F6772657373222C6E2E696E6E657248544D4C3D722E74656D706C6174653B76617220692C733D6E2E717565727953656C6563746F7228722E62617253656C6563746F72292C753D653F222D313030223A6F28742E7374';
wwv_flow_imp.g_varchar2_table(26) := '617475737C7C30292C6C3D646F63756D656E742E717565727953656C6563746F7228722E706172656E74293B72657475726E20732E7374796C652E6261636B67726F756E643D722E626172436F6C6F722C732E7374796C652E6865696768743D722E6261';
wwv_flow_imp.g_varchar2_table(27) := '724865696768742B227078222C6128732C7B7472616E736974696F6E3A22616C6C2030206C696E656172222C7472616E73666F726D3A227472616E736C617465336428222B752B22252C302C3029227D292C722E73686F775370696E6E65727C7C28693D';
wwv_flow_imp.g_varchar2_table(28) := '6E2E717565727953656C6563746F7228722E7370696E6E657253656C6563746F72292926266D2869292C6C213D646F63756D656E742E626F6479262663286C2C226E70726F67726573732D637573746F6D2D706172656E7422292C6C2E617070656E6443';
wwv_flow_imp.g_varchar2_table(29) := '68696C64286E292C6E7D2C742E72656D6F76653D66756E6374696F6E28297B742E7374617475733D6E756C6C2C6C28646F63756D656E742E646F63756D656E74456C656D656E742C226E70726F67726573732D6275737922292C6C28646F63756D656E74';
wwv_flow_imp.g_varchar2_table(30) := '2E717565727953656C6563746F7228722E706172656E74292C226E70726F67726573732D637573746F6D2D706172656E7422293B76617220653D742E676574456C656D656E7428293B6526266D2865297D2C742E697352656E64657265643D66756E6374';
wwv_flow_imp.g_varchar2_table(31) := '696F6E28297B72657475726E2121742E676574456C656D656E7428297D2C742E676574506F736974696F6E696E674353533D66756E6374696F6E28297B76617220653D646F63756D656E742E626F64792E7374796C652C6E3D225765626B69745472616E';
wwv_flow_imp.g_varchar2_table(32) := '73666F726D22696E20653F225765626B6974223A224D6F7A5472616E73666F726D22696E20653F224D6F7A223A226D735472616E73666F726D22696E20653F226D73223A224F5472616E73666F726D22696E20653F224F223A22223B72657475726E206E';
wwv_flow_imp.g_varchar2_table(33) := '2B22506572737065637469766522696E20653F227472616E736C6174653364223A6E2B225472616E73666F726D22696E20653F227472616E736C617465223A226D617267696E227D3B76617220733D66756E6374696F6E28297B76617220653D5B5D3B66';
wwv_flow_imp.g_varchar2_table(34) := '756E6374696F6E206E28297B76617220743D652E736869667428293B74262674286E297D72657475726E2066756E6374696F6E2874297B652E707573682874292C313D3D652E6C656E67746826266E28297D7D28292C613D66756E6374696F6E28297B76';
wwv_flow_imp.g_varchar2_table(35) := '617220653D5B225765626B6974222C224F222C224D6F7A222C226D73225D2C6E3D7B7D3B66756E6374696F6E20742874297B72657475726E20743D742E7265706C616365282F5E2D6D732D2F2C226D732D22292E7265706C616365282F2D285B5C64612D';
wwv_flow_imp.g_varchar2_table(36) := '7A5D292F67692C2866756E6374696F6E28652C6E297B72657475726E206E2E746F55707065724361736528297D29292C6E5B745D7C7C286E5B745D3D66756E6374696F6E286E297B76617220743D646F63756D656E742E626F64792E7374796C653B6966';
wwv_flow_imp.g_varchar2_table(37) := '286E20696E20742972657475726E206E3B666F722876617220722C693D652E6C656E6774682C6F3D6E2E6368617241742830292E746F55707065724361736528292B6E2E736C6963652831293B692D2D3B2969662828723D655B695D2B6F29696E207429';
wwv_flow_imp.g_varchar2_table(38) := '72657475726E20723B72657475726E206E7D287429297D66756E6374696F6E207228652C6E2C72297B6E3D74286E292C652E7374796C655B6E5D3D727D72657475726E2066756E6374696F6E28652C6E297B76617220742C692C6F3D617267756D656E74';
wwv_flow_imp.g_varchar2_table(39) := '733B696628323D3D6F2E6C656E67746829666F72287420696E206E29766F69642030213D3D28693D6E5B745D2926266E2E6861734F776E50726F706572747928742926267228652C742C69293B656C7365207228652C6F5B315D2C6F5B325D297D7D2829';
wwv_flow_imp.g_varchar2_table(40) := '3B66756E6374696F6E207528652C6E297B72657475726E2822737472696E67223D3D747970656F6620653F653A66286529292E696E6465784F66282220222B6E2B222022293E3D307D66756E6374696F6E206328652C6E297B76617220743D662865292C';
wwv_flow_imp.g_varchar2_table(41) := '723D742B6E3B7528742C6E297C7C28652E636C6173734E616D653D722E737562737472696E67283129297D66756E6374696F6E206C28652C6E297B76617220742C723D662865293B7528652C6E29262628743D722E7265706C616365282220222B6E2B22';
wwv_flow_imp.g_varchar2_table(42) := '20222C222022292C652E636C6173734E616D653D742E737562737472696E6728312C742E6C656E6774682D3129297D66756E6374696F6E20662865297B72657475726E282220222B28652626652E636C6173734E616D657C7C2222292B222022292E7265';
wwv_flow_imp.g_varchar2_table(43) := '706C616365282F5C732B2F67692C222022297D66756E6374696F6E206D2865297B652626652E706172656E744E6F64652626652E706172656E744E6F64652E72656D6F76654368696C642865297D72657475726E20747D29293B';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713547520610937107)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'js/nprogress.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2A20676C6F62616C7320617065782C24202A2F0D0A77696E646F772E5343524F4C4C50524F4752455353424152203D2077696E646F772E5343524F4C4C50524F4752455353424152207C7C207B7D3B0D0A0D0A2F2F4578656375746520736372697074';
wwv_flow_imp.g_varchar2_table(2) := '0D0A5343524F4C4C50524F47524553534241522E6D61696E203D2066756E6374696F6E2870446174612C696E697429207B0D0A0D0A202020202F2F44656661756C742076616C7565730D0A20202020766172206974656D24203D20242870446174612E70';
wwv_flow_imp.g_varchar2_table(3) := '6172656E74293B0D0A0D0A202020202F2F496E69742070446174610D0A2020202069662028696E697420262620747970656F6620696E6974203D3D202766756E6374696F6E272920696E69742E63616C6C28746869732C207044617461293B0D0A0D0A20';
wwv_flow_imp.g_varchar2_table(4) := '2020202F2F496E697469616C697A652050726F6772657373204261720D0A20202020766172206E70203D206E6577204E50726F677265737328293B0D0A0D0A202020206E702E636F6E666967757265287044617461293B0D0A0D0A202020202F2F437265';
wwv_flow_imp.g_varchar2_table(5) := '617465204974656D0D0A20202020617065782E6974656D2E6372656174652870446174612E6974656D4E616D652C207B200D0A202020202020202067657456616C75653A2066756E6374696F6E202829207B0D0A20202020202020202020202072657475';
wwv_flow_imp.g_varchar2_table(6) := '726E206E702E7374617475733B0D0A20202020202020207D2C0D0A202020202020202073657456616C75653A2066756E6374696F6E202876616C756529207B0D0A2020202020202020202020206E702E7365742876616C7565293B0D0A20202020202020';
wwv_flow_imp.g_varchar2_table(7) := '207D2C0D0A2020202020202020686964653A2066756E6374696F6E202829207B0D0A2020202020202020202020206974656D242E6373732822646973706C6179222C226E6F6E6522293B0D0A20202020202020207D2C0D0A202020202020202073686F77';
wwv_flow_imp.g_varchar2_table(8) := '3A2066756E6374696F6E202829207B0D0A2020202020202020202020206974656D242E6373732822646973706C6179222C22696E6C696E652D626C6F636B22293B0D0A20202020202020207D2C0D0A2020202020202020737563636573734D6573736167';
wwv_flow_imp.g_varchar2_table(9) := '654F6E436F6D706C657465643A2066756E6374696F6E2028704D65737361676529207B0D0A202020202020202020202020617065782E6D6573736167652E73686F77506167655375636365737328704D657373616765293B0D0A20202020202020207D0D';
wwv_flow_imp.g_varchar2_table(10) := '0A202020207D293B0D0A0D0A202020202F2F496E697469616C697A65205363726F6C6C204261720D0A20202020636F6E73742070726F67726573734F62736572766572203D206E6577205363726F6C6C50726F67726573732828782C207929203D3E207B';
wwv_flow_imp.g_varchar2_table(11) := '0D0A0D0A20202020202020202F2F7661726961626C65730D0A20202020202020207661722076616C58203D204D6174682E6162732878293B0D0A20202020202020207661722076616C59203D204D6174682E6162732879293B0D0A20202020202020200D';
wwv_flow_imp.g_varchar2_table(12) := '0A20202020202020202F2F73657474696E672076616C756573206163636F7264696E676C7920746F2074686520636F6E66696775726174696F6E0D0A20202020202020206966202870446174612E7363726F6C6C446972656374696F6E203D3D3D202754';
wwv_flow_imp.g_varchar2_table(13) := '422729207B0D0A2020202020202020202020206E702E7365742876616C59293B0D0A2020202020202020202020205343524F4C4C50524F47524553534241522E68616E646C654576656E742876616C592C70446174612E706172656E74293B0D0A202020';
wwv_flow_imp.g_varchar2_table(14) := '20202020207D0D0A2020202020202020656C7365206966202870446174612E7363726F6C6C446972656374696F6E203D3D3D20274C522729207B0D0A2020202020202020202020206E702E7365742876616C58293B0D0A20202020202020202020202053';
wwv_flow_imp.g_varchar2_table(15) := '43524F4C4C50524F47524553534241522E68616E646C654576656E742876616C582C70446174612E706172656E74293B0D0A20202020202020207D0D0A2020202020202020656C7365206966202870446174612E7363726F6C6C446972656374696F6E20';
wwv_flow_imp.g_varchar2_table(16) := '3D3D3D2027524C2729207B0D0A20202020202020202020202076617220726C56616C203D204D6174682E6162732876616C58202D2031293B0D0A2020202020202020202020206E702E73657428726C56616C293B0D0A2020202020202020202020205343';
wwv_flow_imp.g_varchar2_table(17) := '524F4C4C50524F47524553534241522E68616E646C654576656E7428726C56616C2C70446174612E706172656E74293B0D0A20202020202020207D0D0A2020202020202020656C7365207B0D0A20202020202020202020202076617220627456616C203D';
wwv_flow_imp.g_varchar2_table(18) := '204D6174682E6162732876616C59202D2031293B0D0A2020202020202020202020206E702E73657428627456616C293B0D0A2020202020202020202020205343524F4C4C50524F47524553534241522E68616E646C654576656E7428627456616C2C7044';
wwv_flow_imp.g_varchar2_table(19) := '6174612E706172656E74293B0D0A20202020202020207D0D0A0D0A202020207D2C2070446174612E63616C635363726F6C6C696E6746726F6D293B0D0A0D0A202020202F2F526563616C6320776964746820696620746865205363726F6C6C6261722069';
wwv_flow_imp.g_varchar2_table(20) := '7320766572746963616C0D0A20202020696620285B275442272C274254275D2E696E636C756465732870446174612E70726F6772657373426172446972656374696F6E2929207B0D0A202020202020202076617220626172486569676874203D20697465';
wwv_flow_imp.g_varchar2_table(21) := '6D242E706172656E747328272E636F6E7461696E657227292E68656967687428293B0D0A20202020202020206974656D242E776964746828626172486569676874293B0D0A202020207D0D0A7D0D0A0D0A5343524F4C4C50524F47524553534241522E68';
wwv_flow_imp.g_varchar2_table(22) := '616E646C654576656E74203D2066756E6374696F6E287056616C75652C704974656D29207B0D0A202020206966287056616C7565203D3D3D203029207B0D0A2020202020202020617065782E6576656E742E7472696767657228704974656D2C20276170';
wwv_flow_imp.g_varchar2_table(23) := '65782D7363726F6C6C2D70726F67726573732D6261722D6F6E2D737461727427293B0D0A202020207D0D0A20202020656C736520696620287056616C7565203E2030202626207056616C7565203C203129207B0D0A2020202020202020617065782E6576';
wwv_flow_imp.g_varchar2_table(24) := '656E742E7472696767657228704974656D2C2027617065782D7363726F6C6C2D70726F67726573732D6261722D6F6E2D70726F677265737327293B0D0A202020207D0D0A20202020656C7365207B0D0A2020202020202020617065782E6576656E742E74';
wwv_flow_imp.g_varchar2_table(25) := '72696767657228704974656D2C2027617065782D7363726F6C6C2D70726F67726573732D6261722D6F6E2D636F6D706C6574656427293B0D0A202020207D0D0A7D';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713547939692937107)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'js/script.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '77696E646F772E5343524F4C4C50524F47524553534241523D77696E646F772E5343524F4C4C50524F47524553534241527C7C7B7D2C5343524F4C4C50524F47524553534241522E6D61696E3D66756E6374696F6E28652C6E297B76617220733D242865';
wwv_flow_imp.g_varchar2_table(2) := '2E706172656E74293B6E26262266756E6374696F6E223D3D747970656F66206E26266E2E63616C6C28746869732C65293B76617220723D6E6577204E50726F67726573733B722E636F6E6669677572652865292C617065782E6974656D2E637265617465';
wwv_flow_imp.g_varchar2_table(3) := '28652E6974656D4E616D652C7B67657456616C75653A66756E6374696F6E28297B72657475726E20722E7374617475737D2C73657456616C75653A66756E6374696F6E2865297B722E7365742865297D2C686964653A66756E6374696F6E28297B732E63';
wwv_flow_imp.g_varchar2_table(4) := '73732822646973706C6179222C226E6F6E6522297D2C73686F773A66756E6374696F6E28297B732E6373732822646973706C6179222C22696E6C696E652D626C6F636B22297D2C737563636573734D6573736167654F6E436F6D706C657465643A66756E';
wwv_flow_imp.g_varchar2_table(5) := '6374696F6E2865297B617065782E6D6573736167652E73686F7750616765537563636573732865297D7D293B6E6577205363726F6C6C50726F67726573732828286E2C73293D3E7B76617220743D4D6174682E616273286E292C613D4D6174682E616273';
wwv_flow_imp.g_varchar2_table(6) := '2873293B696628225442223D3D3D652E7363726F6C6C446972656374696F6E29722E7365742861292C5343524F4C4C50524F47524553534241522E68616E646C654576656E7428612C652E706172656E74293B656C736520696628224C52223D3D3D652E';
wwv_flow_imp.g_varchar2_table(7) := '7363726F6C6C446972656374696F6E29722E7365742874292C5343524F4C4C50524F47524553534241522E68616E646C654576656E7428742C652E706172656E74293B656C73652069662822524C223D3D3D652E7363726F6C6C446972656374696F6E29';
wwv_flow_imp.g_varchar2_table(8) := '7B766172206F3D4D6174682E61627328742D31293B722E736574286F292C5343524F4C4C50524F47524553534241522E68616E646C654576656E74286F2C652E706172656E74297D656C73657B76617220693D4D6174682E61627328612D31293B722E73';
wwv_flow_imp.g_varchar2_table(9) := '65742869292C5343524F4C4C50524F47524553534241522E68616E646C654576656E7428692C652E706172656E74297D7D292C652E63616C635363726F6C6C696E6746726F6D293B6966285B225442222C224254225D2E696E636C7564657328652E7072';
wwv_flow_imp.g_varchar2_table(10) := '6F6772657373426172446972656374696F6E29297B76617220743D732E706172656E747328222E636F6E7461696E657222292E68656967687428293B732E77696474682874297D7D2C5343524F4C4C50524F47524553534241522E68616E646C65457665';
wwv_flow_imp.g_varchar2_table(11) := '6E743D66756E6374696F6E28652C6E297B303D3D3D653F617065782E6576656E742E74726967676572286E2C22617065782D7363726F6C6C2D70726F67726573732D6261722D6F6E2D737461727422293A653E302626653C313F617065782E6576656E74';
wwv_flow_imp.g_varchar2_table(12) := '2E74726967676572286E2C22617065782D7363726F6C6C2D70726F67726573732D6261722D6F6E2D70726F677265737322293A617065782E6576656E742E74726967676572286E2C22617065782D7363726F6C6C2D70726F67726573732D6261722D6F6E';
wwv_flow_imp.g_varchar2_table(13) := '2D636F6D706C6574656422297D3B';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713548347658937107)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'js/script.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2A2A0D0A202A2046616C6C6261636B206E6F6F702066756E6374696F6E0D0A202A20406D6574686F64206E6F6F700D0A202A204072657475726E73207B756E646566696E65647D0D0A202A2F0D0A66756E6374696F6E206E6F6F702829207B7D0D0A0D';
wwv_flow_imp.g_varchar2_table(2) := '0A2F2A2A0D0A202A205363726F6C6C50726F677265737320636C61737320636F6E7374727563746F720D0A202A2040636F6E7374727563746F72205363726F6C6C50726F67726573730D0A202A2040706172616D207B46756E6374696F6E7D2068616E64';
wwv_flow_imp.g_varchar2_table(3) := '6C65557064617465206D6574686F6420746F2063616C6C206F6E207363726F6C6C207570646174650D0A202A204072657475726E73207B756E646566696E65647D0D0A202A2F0D0A766172205363726F6C6C50726F6772657373203D2066756E6374696F';
wwv_flow_imp.g_varchar2_table(4) := '6E2868616E646C655570646174652C7053656C6563746F7229207B0D0A20202F2F676574204F626A6563740D0A2020746869732E7363726F6C6C4F626A656374203D20617065782E6A5175657279287053656C6563746F72295B305D3B0D0A0D0A20202F';
wwv_flow_imp.g_varchar2_table(5) := '2F2061737369676E2066756E6374696F6E20746F2063616C6C206F6E207570646174650D0A2020746869732E5F68616E646C65557064617465203D20747970656F662068616E646C65557064617465203D3D3D202766756E6374696F6E270D0A20202020';
wwv_flow_imp.g_varchar2_table(6) := '3F2068616E646C655570646174650D0A202020203A206E6F6F703B0D0A0D0A20202F2F2073657420696E697469616C2076616C7565730D0A2020746869732E5F76696577706F7274486569676874203D20746869732E5F67657456696577706F72744865';
wwv_flow_imp.g_varchar2_table(7) := '6967687428293B0D0A2020746869732E5F76696577706F72745769647468203D20746869732E5F67657456696577706F7274576964746828293B0D0A0D0A2020746869732E5F70726F6772657373203D20746869732E5F67657450726F67726573732829';
wwv_flow_imp.g_varchar2_table(8) := '3B0D0A0D0A20202F2F207472696767657220696E697469616C207570646174652066756E6374696F6E0D0A2020746869732E5F68616E646C6555706461746528746869732E5F70726F67726573732E782C20746869732E5F70726F67726573732E79293B';
wwv_flow_imp.g_varchar2_table(9) := '0D0A0D0A20202F2F2062696E64206576656E742066756E6374696F6E730D0A2020746869732E5F6F6E5363726F6C6C203D20746869732E5F6F6E5363726F6C6C2E62696E642874686973293B0D0A2020746869732E5F6F6E526573697A65203D20746869';
wwv_flow_imp.g_varchar2_table(10) := '732E5F6F6E526573697A652E62696E642874686973293B0D0A0D0A20202F2F20616464206576656E74206C697374656E6572730D0A2020746869732E7363726F6C6C4F626A6563742E6164644576656E744C697374656E657228277363726F6C6C272C20';
wwv_flow_imp.g_varchar2_table(11) := '746869732E5F6F6E5363726F6C6C293B0D0A2020746869732E7363726F6C6C4F626A6563742E6164644576656E744C697374656E65722827726573697A65272C20746869732E5F6F6E526573697A65293B0D0A7D3B0D0A0D0A2F2A2A0D0A202A20546865';
wwv_flow_imp.g_varchar2_table(12) := '206F626A65637420776865726520746865207363726F6C6C20706F736974696F6E2061726520676F696E6720746F2062652063616C63756C617465642066726F6D2E0D0A202A2F0D0A5363726F6C6C50726F67726573732E70726F746F747970652E7363';
wwv_flow_imp.g_varchar2_table(13) := '726F6C6C4F626A656374203D206E756C6C3B0D0A0D0A2F2A2A0D0A202A2047657420766572746963616C207472616A6563746F7279206F66207468652076696577706F72740D0A202A20406D6574686F64205F67657456696577706F7274486569676874';
wwv_flow_imp.g_varchar2_table(14) := '0D0A202A204072657475726E73207B4E756D6265727D0D0A202A2F0D0A5363726F6C6C50726F67726573732E70726F746F747970652E5F67657456696577706F7274486569676874203D2066756E6374696F6E2829207B0D0A202072657475726E207468';
wwv_flow_imp.g_varchar2_table(15) := '69732E7363726F6C6C4F626A6563742E7363726F6C6C4865696768743B0D0A7D3B0D0A0D0A2F2A2A0D0A202A2047657420686F72697A6F6E74616C207472616A6563746F7279206F66207468652076696577706F72740D0A202A20406D6574686F64205F';
wwv_flow_imp.g_varchar2_table(16) := '67657456696577706F727457696474680D0A202A204072657475726E73207B4E756D6265727D0D0A202A2F0D0A5363726F6C6C50726F67726573732E70726F746F747970652E5F67657456696577706F72745769647468203D2066756E6374696F6E2829';
wwv_flow_imp.g_varchar2_table(17) := '207B0D0A202072657475726E20746869732E7363726F6C6C4F626A6563742E7363726F6C6C57696474683B0D0A7D3B0D0A0D0A2F2A2A0D0A202A20476574207363726F6C6C2070726F6772657373206F6E20626F746820617869730D0A202A20406D6574';
wwv_flow_imp.g_varchar2_table(18) := '686F64205F67657450726F67726573730D0A202A204072657475726E73207B4F626A6563747D0D0A202A2F0D0A5363726F6C6C50726F67726573732E70726F746F747970652E5F67657450726F6772657373203D2066756E6374696F6E2829207B0D0A20';
wwv_flow_imp.g_varchar2_table(19) := '207661722078203D20746869732E7363726F6C6C4F626A6563742E7363726F6C6C4C656674203D3D3D2030203F2030203A0D0A2020202020202020746869732E7363726F6C6C4F626A6563742E7363726F6C6C4C656674202B200D0A2020202020202020';
wwv_flow_imp.g_varchar2_table(20) := '746869732E7363726F6C6C4F626A6563742E6F666673657457696474683B0D0A20207661722079203D20746869732E7363726F6C6C4F626A6563742E7363726F6C6C546F70203D3D3D2030203F2030203A0D0A2020202020202020746869732E7363726F';
wwv_flow_imp.g_varchar2_table(21) := '6C6C4F626A6563742E7363726F6C6C546F70202B200D0A2020202020202020746869732E7363726F6C6C4F626A6563742E6F66667365744865696768743B0D0A0D0A202072657475726E207B0D0A20202020783A20746869732E5F76696577706F727457';
wwv_flow_imp.g_varchar2_table(22) := '69647468203D3D3D20300D0A2020202020203F20300D0A2020202020203A2078202F20746869732E5F76696577706F727457696474682C0D0A20202020793A20746869732E5F76696577706F7274486569676874203D3D3D20300D0A2020202020203F20';
wwv_flow_imp.g_varchar2_table(23) := '300D0A2020202020203A2079202F20746869732E5F76696577706F72744865696768740D0A20207D3B0D0A7D3B0D0A0D0A2F2A2A0D0A202A20476574207363726F6C6C2070726F6772657373206F6E20626F746820617869730D0A202A20406D6574686F';
wwv_flow_imp.g_varchar2_table(24) := '64205F67657450726F67726573730D0A202A204072657475726E73207B756E646566696E65647D0D0A202A2F0D0A5363726F6C6C50726F67726573732E70726F746F747970652E5F6F6E5363726F6C6C203D2066756E6374696F6E2829207B0D0A202074';
wwv_flow_imp.g_varchar2_table(25) := '6869732E5F70726F6772657373203D20746869732E5F67657450726F677265737328293B0D0A2020746869732E5F68616E646C6555706461746528746869732E5F70726F67726573732E782C20746869732E5F70726F67726573732E79293B0D0A7D3B0D';
wwv_flow_imp.g_varchar2_table(26) := '0A0D0A2F2A2A0D0A202A205570646174652076696577706F7274206D6574726963732C20726563616C63756C6174652070726F677265737320616E642063616C6C207570646174652063616C6C6261636B0D0A202A20406D6574686F64205F6F6E526573';
wwv_flow_imp.g_varchar2_table(27) := '697A650D0A202A204072657475726E73207B756E646566696E65647D0D0A202A2F0D0A5363726F6C6C50726F67726573732E70726F746F747970652E5F6F6E526573697A65203D2066756E6374696F6E2829207B0D0A2020746869732E5F76696577706F';
wwv_flow_imp.g_varchar2_table(28) := '7274486569676874203D20746869732E5F67657456696577706F727448656967687428293B0D0A2020746869732E5F76696577706F72745769647468203D20746869732E5F67657456696577706F7274576964746828293B0D0A0D0A2020746869732E5F';
wwv_flow_imp.g_varchar2_table(29) := '70726F6772657373203D20746869732E5F67657450726F677265737328293B0D0A0D0A20202F2F2074726967676572207570646174652066756E6374696F6E0D0A2020746869732E5F68616E646C6555706461746528746869732E5F70726F6772657373';
wwv_flow_imp.g_varchar2_table(30) := '2E782C20746869732E5F70726F67726573732E79293B0D0A7D3B0D0A0D0A2F2A2A0D0A202A2054726967676572207570646174652063616C6C6261636B0D0A202A20406D6574686F6420747269676765720D0A202A204072657475726E73207B756E6465';
wwv_flow_imp.g_varchar2_table(31) := '66696E65647D0D0A202A2F0D0A5363726F6C6C50726F67726573732E70726F746F747970652E74726967676572203D2066756E6374696F6E2829207B0D0A2020746869732E5F68616E646C6555706461746528746869732E5F70726F67726573732E782C';
wwv_flow_imp.g_varchar2_table(32) := '20746869732E5F70726F67726573732E79293B0D0A7D3B0D0A0D0A2F2A2A0D0A202A2044657374726F79207363726F6C6C206F627365727665722C2072656D6F7665206C697374656E65727320616E64207570646174652063616C6C6261636B0D0A202A';
wwv_flow_imp.g_varchar2_table(33) := '20406D6574686F642064657374726F790D0A202A204072657475726E73207B756E646566696E65647D0D0A202A2F0D0A5363726F6C6C50726F67726573732E70726F746F747970652E64657374726F79203D2066756E6374696F6E2829207B0D0A202074';
wwv_flow_imp.g_varchar2_table(34) := '6869732E7363726F6C6C4F626A6563742E72656D6F76654576656E744C697374656E657228277363726F6C6C272C20746869732E5F6F6E5363726F6C6C293B0D0A2020746869732E7363726F6C6C4F626A6563742E72656D6F76654576656E744C697374';
wwv_flow_imp.g_varchar2_table(35) := '656E65722827726573697A65272C20746869732E5F6F6E526573697A65293B0D0A2020746869732E5F68616E646C65557064617465203D206E756C6C3B0D0A7D3B';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713548725692937108)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'js/scrollProgress.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '66756E6374696F6E206E6F6F7028297B7D766172205363726F6C6C50726F67726573733D66756E6374696F6E28742C73297B746869732E7363726F6C6C4F626A6563743D617065782E6A51756572792873295B305D2C746869732E5F68616E646C655570';
wwv_flow_imp.g_varchar2_table(2) := '646174653D2266756E6374696F6E223D3D747970656F6620743F743A6E6F6F702C746869732E5F76696577706F72744865696768743D746869732E5F67657456696577706F727448656967687428292C746869732E5F76696577706F727457696474683D';
wwv_flow_imp.g_varchar2_table(3) := '746869732E5F67657456696577706F7274576964746828292C746869732E5F70726F67726573733D746869732E5F67657450726F677265737328292C746869732E5F68616E646C6555706461746528746869732E5F70726F67726573732E782C74686973';
wwv_flow_imp.g_varchar2_table(4) := '2E5F70726F67726573732E79292C746869732E5F6F6E5363726F6C6C3D746869732E5F6F6E5363726F6C6C2E62696E642874686973292C746869732E5F6F6E526573697A653D746869732E5F6F6E526573697A652E62696E642874686973292C74686973';
wwv_flow_imp.g_varchar2_table(5) := '2E7363726F6C6C4F626A6563742E6164644576656E744C697374656E657228227363726F6C6C222C746869732E5F6F6E5363726F6C6C292C746869732E7363726F6C6C4F626A6563742E6164644576656E744C697374656E65722822726573697A65222C';
wwv_flow_imp.g_varchar2_table(6) := '746869732E5F6F6E526573697A65297D3B5363726F6C6C50726F67726573732E70726F746F747970652E7363726F6C6C4F626A6563743D6E756C6C2C5363726F6C6C50726F67726573732E70726F746F747970652E5F67657456696577706F7274486569';
wwv_flow_imp.g_varchar2_table(7) := '6768743D66756E6374696F6E28297B72657475726E20746869732E7363726F6C6C4F626A6563742E7363726F6C6C4865696768747D2C5363726F6C6C50726F67726573732E70726F746F747970652E5F67657456696577706F727457696474683D66756E';
wwv_flow_imp.g_varchar2_table(8) := '6374696F6E28297B72657475726E20746869732E7363726F6C6C4F626A6563742E7363726F6C6C57696474687D2C5363726F6C6C50726F67726573732E70726F746F747970652E5F67657450726F67726573733D66756E6374696F6E28297B7661722074';
wwv_flow_imp.g_varchar2_table(9) := '3D303D3D3D746869732E7363726F6C6C4F626A6563742E7363726F6C6C4C6566743F303A746869732E7363726F6C6C4F626A6563742E7363726F6C6C4C6566742B746869732E7363726F6C6C4F626A6563742E6F666673657457696474682C733D303D3D';
wwv_flow_imp.g_varchar2_table(10) := '3D746869732E7363726F6C6C4F626A6563742E7363726F6C6C546F703F303A746869732E7363726F6C6C4F626A6563742E7363726F6C6C546F702B746869732E7363726F6C6C4F626A6563742E6F66667365744865696768743B72657475726E7B783A30';
wwv_flow_imp.g_varchar2_table(11) := '3D3D3D746869732E5F76696577706F727457696474683F303A742F746869732E5F76696577706F727457696474682C793A303D3D3D746869732E5F76696577706F72744865696768743F303A732F746869732E5F76696577706F72744865696768747D7D';
wwv_flow_imp.g_varchar2_table(12) := '2C5363726F6C6C50726F67726573732E70726F746F747970652E5F6F6E5363726F6C6C3D66756E6374696F6E28297B746869732E5F70726F67726573733D746869732E5F67657450726F677265737328292C746869732E5F68616E646C65557064617465';
wwv_flow_imp.g_varchar2_table(13) := '28746869732E5F70726F67726573732E782C746869732E5F70726F67726573732E79297D2C5363726F6C6C50726F67726573732E70726F746F747970652E5F6F6E526573697A653D66756E6374696F6E28297B746869732E5F76696577706F7274486569';
wwv_flow_imp.g_varchar2_table(14) := '6768743D746869732E5F67657456696577706F727448656967687428292C746869732E5F76696577706F727457696474683D746869732E5F67657456696577706F7274576964746828292C746869732E5F70726F67726573733D746869732E5F67657450';
wwv_flow_imp.g_varchar2_table(15) := '726F677265737328292C746869732E5F68616E646C6555706461746528746869732E5F70726F67726573732E782C746869732E5F70726F67726573732E79297D2C5363726F6C6C50726F67726573732E70726F746F747970652E747269676765723D6675';
wwv_flow_imp.g_varchar2_table(16) := '6E6374696F6E28297B746869732E5F68616E646C6555706461746528746869732E5F70726F67726573732E782C746869732E5F70726F67726573732E79297D2C5363726F6C6C50726F67726573732E70726F746F747970652E64657374726F793D66756E';
wwv_flow_imp.g_varchar2_table(17) := '6374696F6E28297B746869732E7363726F6C6C4F626A6563742E72656D6F76654576656E744C697374656E657228227363726F6C6C222C746869732E5F6F6E5363726F6C6C292C746869732E7363726F6C6C4F626A6563742E72656D6F76654576656E74';
wwv_flow_imp.g_varchar2_table(18) := '4C697374656E65722822726573697A65222C746869732E5F6F6E526573697A65292C746869732E5F68616E646C655570646174653D6E756C6C7D3B';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(26713549194691937108)
,p_plugin_id=>wwv_flow_imp.id(26713536122623937096)
,p_file_name=>'js/scrollProgress.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20240303134543Z')
,p_updated_on=>wwv_flow_imp.dz('20240303134543Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
