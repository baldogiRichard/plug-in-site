prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(44129704019326020537)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>15598820859521
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(44130400160965020628)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_text_01=>'Navigation menu for the application.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Plug-ins'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plug'
,p_list_text_01=>'Plug-ins made by Richard Baldogi.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9478679334743837914)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Comments'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comments'
,p_parent_list_item_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_text_01=>'This plug-in provides a region where you can write comments.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Interactive Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-combo-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_text_01=>'This plug-in provides 16 types of interactive charts with many customizable capabilities.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6482574995693654936)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Line Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6482296849182898834)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Area Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6478254177501839729)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Bar Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6027973991945913745)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Mixed Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-combo-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'9'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6014454134387680333)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Range Area Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-range-chart-area'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5071315176726629847)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Timeline Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-clock'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'11'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4198345126923992322)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Candlestick Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-stock-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3841055614513572588)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Boxplot Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-box-plot-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3737254397786310856)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Pie / Donut Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pie-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3560534073353047376)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Radar Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-radar-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'15'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3552683854004783375)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Polar Area Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-polar-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3542283799402617689)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Radialbars / Circle Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-circle-5-8'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'17'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3522755028503923809)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Bubble Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bubble-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'18'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2570197904351648122)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Scatter Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-scatter-chart'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1870503493037520899)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Heatmap Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-heat-map'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(539882764798152401)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Treemap Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tree-org'
,p_parent_list_item_id=>wwv_flow_imp.id(9453494400200335086)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'21'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9482132959007201932)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'JSON Crack - Viewer'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-sitemap'
,p_parent_list_item_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'22'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19643227587534429473)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Copy Excel to IG'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-file'
,p_parent_list_item_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'23'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(423848039650363176)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'News Feed'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-feed'
,p_parent_list_item_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'24'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26714602821900440656)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Scroll ProgressBar'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-long-arrow-down'
,p_parent_list_item_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'25'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(42048912675859345814)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Enhance IG with Treegrid'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tree-org'
,p_parent_list_item_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'26'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(62097288401107212369)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Hierarchy Chart'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dataset'
,p_parent_list_item_id=>wwv_flow_imp.id(6838949381914010829)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9438803908139733209)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Github'
,p_list_item_link_target=>'https://github.com/baldogiRichard'
,p_list_item_icon=>'fa-github'
,p_list_text_01=>'The Github page where you can find all of my works.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9478148948736808022)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'About me'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'A small description about me.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9321616521691857525)
,p_list_item_display_sequence=>65
,p_list_item_link_text=>'Game 2048'
,p_list_item_link_target=>'f?p=&APP_ID.:2048:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gamepad'
,p_list_text_01=>'This is a small fun game built for every Oracle APEX fan and enjoyer. It''s not just a game. It''s the easiest template component ever created and your reward when you''ve upgraded to Oracle APEX 23.1!'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2048'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7510213442846152796)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Download the Application'
,p_list_item_link_target=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:APPLICATION_PROCESS=DOWNLOAD_APP:&DEBUG.::::'
,p_list_item_icon=>'fa-download'
,p_list_text_01=>'You can download the application with the plug-ins included in here.'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp.component_end;
end;
/
