prompt --application/shared_components/navigation/lists/comments_menu
begin
--   Manifest
--     LIST: Comments Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4878003474893976349)
,p_name=>'Comments Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20230723113844Z')
,p_updated_on=>wwv_flow_imp.dz('20230723113844Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4878003214109976347)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Comments'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comments'
,p_list_text_01=>'This plug-in helps to build a comment region to application express developers.'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20230723113844Z')
,p_updated_on=>wwv_flow_imp.dz('20230723113844Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
