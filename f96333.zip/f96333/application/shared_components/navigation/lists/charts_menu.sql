prompt --application/shared_components/navigation/lists/charts_menu
begin
--   Manifest
--     LIST: Charts Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6481187822013882042)
,p_name=>'Charts Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6481187620209882041)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Line Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-line-chart'
,p_list_text_01=>'A line chart (aka line plot, line graph) uses points connected by line segments from left to right to demonstrate changes in value. The horizontal axis depicts a continuous progression, often that of time, while the vertical axis reports values for a'
||' metric of interest across that progression.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6481187219566882041)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Area Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>unistr('An area chart is a graph that combines a line chart and a bar chart to show changes in quantities over time. It\2019s similar to a line graph in that data points are plotted and connected by line segments. However, the area below the line is colored in o')
||'r shaded. Then, other values are plotted below the lines and shaded in a different color, resulting in a chart with layers.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6472284393019345957)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Bar Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bar-chart'
,p_list_text_01=>'A bar chart is a way of summarizing a set of categorical data (continuous data can be made categorical by auto-binning). The bar chart displays data using a number of bars, each representing a particular category. The height of each bar is proportion'
||'al to a specific aggregation (for example the sum of the values in the category it represents). The categories could be something like an age group or a geographical location. It is also possible to color or split each bar into another categorical co'
||'lumn in the data, which enables you to see the contribution from different categories to each bar or group of bars in the bar chart.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6026900209842880686)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Mixed Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-combo-chart'
,p_list_text_01=>'The mixed chart is a visualization that combines the features of the bar chart and the line chart. The mixed chart displays the data using a number of bars and/or lines, each of which represent a particular category. A combination of bars and lines i'
||'n the same visualization can be useful when comparing values in different categories, since the combination gives a clear view of which category is higher or lower. An example of this can be seen when using the mixed chart to compare the projected sa'
||'les with the actual sales for different time periods.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6013707808072653562)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Range Area Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-range-chart-area'
,p_list_text_01=>'Range Area Chart is a type of area chart where rather than starting on the axis, the area is represented by the space between two values. These charts are useful for displaying ranges of values, such as between minimum and maximum prices over a times'
||'pan, or projected values for the future when the projection is represented by a range instead of a specific value.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5059052123540822436)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Timeline Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-clock'
,p_list_text_01=>'Timeline charts are highly versatile visual charts that are used to illustrate a set of events chronologically. They''re an excellent tool for conceptualizing event sequences or processes to gain insights into the nuances of a project. That could incl'
||'ude summarizing historical events, or any other time frame where you need to measure minutes, hours, dates, or years.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4196552712471954664)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Candlestick Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-stock-chart'
,p_list_text_01=>'A candlestick chart is a financial chart that typically shows price movements of currency, securities, or derivatives. It looks like a candlestick with a vertical rectangle and a wick at the top and bottom. The top and bottom of the candlestick show '
||'open and closed prices. The top of the wick shows the high price, and the bottom of the wick shows the low price.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3829537113883273733)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Boxplot charts'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-box-plot-chart'
,p_list_text_01=>unistr('A Box and Whisker Plot (or Box Plot) is a convenient way of visually displaying the data distribution through their quartiles. The lines extending parallel from the boxes are known as the \201Cwhiskers\201D, which are used to indicate variability outside the')
||' upper and lower quartiles. Outliers are sometimes plotted as individual dots that are in-line with whiskers. Box Plots can be drawn either vertically or horizontally. Although Box Plots may seem primitive in comparison to a Histogram or Density Plot'
||', they have the advantage of taking up less space, which is useful when comparing distributions between many groups or datasets.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3733719853570270273)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Pie / Donut Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pie-chart'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('A pie chart is a graphical representation technique that displays data in a circular-shaped graph. It is a composite static chart that works best with few variables. Pie charts are often used to represent sample data\2014with data points belonging to a c')
||unistr('ombination of different categories. Each of these categories is represented as a \201Cslice of the pie.\201D The size of each slice is directly proportional to the number of data points that belong to a particular category.'),
'',
'',
'A donut chart, in its simplest form, is a pie chart with its center cut out to look like a donut. At first glance, this may not seem to serve a much greater purpose than to create aesthetic variety. However, a donut chart helps avoid confusion around'
||' the area parameter that often trips people up in a pie chart.'))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3557107196714880092)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Radar Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-radar-chart'
,p_list_text_01=>unistr('A radar chart shows multivariate data of three or more quantitative variables mapped onto an axis. It looks like a spider\2019s web, with a central axis that has at least three spokes, called radii, coming from it. On these spokes, the values for the dat')
||'a are mapped. It is designed to show similarities, differences, and outliers for that product, service, or any other item of interest at a glance.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3549805909333875259)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Polar Area Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-polar-chart'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Polar area chart (also known as Polar area diagram, Coxcomb chart, Rose chart) is often used to plot cyclical data like average monthly temperature, hourly traffic to a website, etc.',
unistr('One of the most famous early uses of polar area chart is \201CDiagram of the causes of mortality in the army in the East\201D by Florence Nightingale.')))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3536460285695487289)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Radialbars Charts Basic'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-circle-5-8'
,p_list_text_01=>'Radial Bar Charts are valuable in showing comparisons between categories by using circularly shaped bars. Also known as the circular bar chart, it is simply a typical bar chart plot represented on a polar coordinate system.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3520712964123119135)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Bubble Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bubble-chart'
,p_list_text_01=>'A bubble chart is a data visualization that displays multiple circles (bubbles) in a two-dimensional plot. It is a generalization of the scatter plot, replacing the dots with bubbles. Most commonly, a bubble chart displays the values of three numeric'
||' variables, where each observation''s data is shown by a circle ("bubble"), while the horizontal and vertical positions of the bubble show the values of two other variables.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2567506043219890832)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Scatter charts'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-scatter-chart'
,p_list_text_01=>'A scatter chart, also called a scatter plot, is a chart that shows the relationship between two variables. They are an incredibly powerful chart type, allowing viewers to immediately understand a relationship or trend, which would be impossible to se'
||'e in almost any other form.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1868544997952496395)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Heatmap Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-heat-map'
,p_list_text_01=>'A heat map (or heatmap) is a data visualization technique that shows magnitude of a phenomenon as color in two dimensions. The variation in color may be by hue or intensity, giving obvious visual cues to the reader about how the phenomenon is cluster'
||'ed or varies over space. There are two fundamentally different categories of heat maps: the cluster heat map and the spatial heat map. In a cluster heat map, magnitudes are laid out into a matrix of fixed cell size whose rows and columns are discrete'
||' phenomena and categories, and the sorting of rows and columns is intentional and somewhat arbitrary, with the goal of suggesting clusters or portraying them as discovered via statistical analysis. The size of the cell is arbitrary but large enough t'
||'o be clearly visible. By contrast, the position of a magnitude in a spatial heat map is forced by the location of the magnitude in that space, and there is no notion of cells; the phenomenon is considered to vary continuously.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(538644354133111356)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Treemap Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tree-org'
,p_list_text_01=>'Treemapping is a data visualization technique that displays hierarchical data using rectangles of decreasing sizes, often called nesting, to create treemap charts. As the name suggests, treemap charts depict data in a tree-like format, with branches '
||'and sub-branches that are able to be read at a glance. Treemaps are great at taking a large amount of raw data and depicting it in a visually appealing, compact, and easy-to-read manner, enabling the user to discern patterns and make comparisons rapi'
||'dly.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
