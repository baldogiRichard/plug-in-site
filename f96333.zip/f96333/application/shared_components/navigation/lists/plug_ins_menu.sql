prompt --application/shared_components/navigation/lists/plug_ins_menu
begin
--   Manifest
--     LIST: Plug-ins Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6836180686686254784)
,p_name=>'Plug-ins Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>15598820722956
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6836180504972254784)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Comments'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comments'
,p_list_text_01=>'This plug-in provides a region where you can write comments.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6836180092664254783)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Interactive Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-combo-chart'
,p_list_text_01=>'This plug-in provides 16 types of interactive charts with many customizable capabilities.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9480636866420813353)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'JSON Viewer'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sitemap'
,p_list_text_01=>'This plug-in helps to visualize JSON data in a canvas.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(19644394428955970016)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Copy Excel to Interactive Grid'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-file'
,p_list_text_01=>'This Dynamic Action (DA) plug-in supports Copy - Paste, Import and Appending actions from an Excel file to an editable Interactive Grid (IG) report.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(438014835746585985)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'News Feed'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-feed'
,p_list_text_01=>'This template component is a demonstration of how this new apex feature can be utilized. A REST Data Source is being used to fetch data in the region and a Smart Filter is applied for the Category (or Tag) column in order to search between the rows.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26717149822394993082)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Scroll ProgressBar'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-long-arrow-down'
,p_list_text_01=>'The Scroll ProgressBar allows users to track their progress while scrolling through some content in a given page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(42041700150709979975)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Enhance Interactive Grid with Treegrid'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tree-org'
,p_list_text_01=>'This Dynamic Action (DA) plug-in renders a treegrid component to an Interactive Grid (IG) report.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(62097735715890263161)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Hierarchy Chart'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dataset'
,p_list_text_01=>'This plug-in helps to visualize data in a hierarchical view with flexible capabilities of displaying custom node content and rendering large and complex hierarchies with partial load behaviour.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
