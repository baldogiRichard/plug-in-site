prompt --application/shared_components/navigation/lists/social
begin
--   Manifest
--     LIST: Social
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4877173243050972503)
,p_name=>'Social'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20230723113922Z')
,p_updated_on=>wwv_flow_imp.dz('20230723113922Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4877171856545972502)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Github'
,p_list_item_link_target=>'https://github.com/baldogiRichard'
,p_list_item_icon=>'fa-github'
,p_list_text_01=>'My Github page where I store my plugins.'
,p_list_item_current_type=>'NEVER'
,p_created_on=>wwv_flow_imp.dz('20230723113922Z')
,p_updated_on=>wwv_flow_imp.dz('20230723113922Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4877173069264972503)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Twitter'
,p_list_item_link_target=>'https://twitter.com/O_APEX_Hungary'
,p_list_item_icon=>'fa-twitter'
,p_list_text_01=>'My Twitter Page.'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20230723113922Z')
,p_updated_on=>wwv_flow_imp.dz('20230723113922Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4877172586491972503)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Linkedin'
,p_list_item_link_target=>'https://www.linkedin.com/in/rb-627543146/'
,p_list_item_icon=>'fa-linkedin'
,p_list_text_01=>'My Linkedin profile where you can find detailed description about my experience.'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20230723113922Z')
,p_updated_on=>wwv_flow_imp.dz('20230723113922Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4877172190806972502)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Facebook'
,p_list_item_link_target=>'https://www.facebook.com/Application-Express-Hungary-110053971442983/'
,p_list_item_icon=>'fa-facebook'
,p_list_text_01=>'My Facebook Social Site (under development).'
,p_list_item_current_type=>'TARGET_PAGE'
,p_created_on=>wwv_flow_imp.dz('20230723113922Z')
,p_updated_on=>wwv_flow_imp.dz('20230723113922Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
