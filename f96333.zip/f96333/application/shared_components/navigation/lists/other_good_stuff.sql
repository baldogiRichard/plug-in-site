prompt --application/shared_components/navigation/lists/other_good_stuff
begin
--   Manifest
--     LIST: Other Good Stuff
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4877980663999974000)
,p_name=>'Other Good Stuff'
,p_list_status=>'PUBLIC'
,p_version_scn=>15598820791753
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4877980452647973999)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'JSON Crack - JSON Viewer'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-sitemap'
,p_list_text_01=>'This plug-in helps to visualize JSON data in a canvas.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4877979996094973999)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Copy Excel to IG'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-file'
,p_list_text_01=>'This Dynamic Action (DA) plug-in supports Copy - Paste, Import and Appending actions from an Excel file to an editable Interactive Grid (IG) report.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(432815300270644212)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'News Feed'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-feed'
,p_list_text_01=>'This template component is a demonstration of how this new apex feature can be utilized. A REST Data Source is being used to fetch data in the region and a Smart Filter is applied for the Category (or Tag) column in order to search between the rows.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9323074430691917215)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Game 2048'
,p_list_item_link_target=>'f?p=&APP_ID.:2048:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gamepad'
,p_list_text_01=>'This is a small fun game built for every Oracle APEX fan and enjoyer. It''s not just a game. It''s the easiest template component ever created and your reward when you''ve upgraded to Oracle APEX 23.1!'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26717795618117498592)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Scroll ProgressBar'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-long-arrow-down'
,p_list_text_01=>'The Scroll ProgressBar allows users to track their progress while scrolling through some content in a given page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(42040663263176953773)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Enhance Interactive Grid with Treegrid'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tree-org'
,p_list_text_01=>'This Dynamic Action (DA) plug-in renders a treegrid component to an Interactive Grid (IG) report.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(62097645857613576217)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Hierarchy Chart'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dataset'
,p_list_text_01=>'This plug-in helps to visualize data in a hierarchical view with flexible capabilities of displaying custom node content and rendering large and complex hierarchies with partial load behaviour.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
