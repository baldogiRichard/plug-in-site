prompt --application/shared_components/logic/application_processes/getimage
begin
--   Manifest
--     APPLICATION PROCESS: GETIMAGE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(24094608922473023454)
,p_process_sequence=>2
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GETIMAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    for c1 in (select *',
'                 from apex_comments_users',
'                where empno = :FILE_ID) loop',
'        --',
'        sys.htp.init;',
'        sys.owa_util.mime_header( c1.profile_picture_mimetype, FALSE );',
'        sys.htp.p(''Content-length: '' || sys.dbms_lob.getlength( c1.profile_picture));',
'        sys.htp.p(''Content-Disposition: attachment; filename="'' || c1.profile_picture_filename || ''"'' );',
'        sys.htp.p(''Cache-Control: max-age=3600'');  -- tell the browser to cache for one hour, adjust as necessary',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.download_file( c1.profile_picture );',
'     ',
'        apex_application.stop_apex_engine;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20230603210221Z')
,p_updated_on=>wwv_flow_imp.dz('20230604114558Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
