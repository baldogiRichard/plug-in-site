prompt --application/shared_components/logic/application_processes/download_app
begin
--   Manifest
--     APPLICATION PROCESS: DOWNLOAD_APP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(7507079453069110956)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_APP'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  --file variables',
'  l_blob  blob;',
'  l_files apex_t_export_files;',
'',
'  --app variables',
'  l_app_id number := v(''APP_ID'');',
'',
'  --other variables',
'  l_dest_offset PLS_INTEGER := 1;',
'  l_src_offset PLS_INTEGER := 1;',
'  l_lang_context PLS_INTEGER := dbms_lob.default_lang_ctx;',
'  l_warning PLS_INTEGER := dbms_lob.warn_inconvertible_char;',
'  l_clob_content clob;',
'',
'begin',
'',
'  --get application',
'  l_files := apex_export.get_application(p_application_id => l_app_id);',
'',
'  l_clob_content := l_files(1).contents;',
'',
'  --create lob',
'  sys.dbms_lob.createtemporary(lob_loc => l_blob, cache => TRUE);',
'',
'  sys.dbms_lob.converttoblob(dest_lob => l_blob, ',
'                             src_clob => l_clob_content, ',
'                             amount => sys.dbms_lob.lobmaxsize, ',
'                             dest_offset => l_dest_offset, ',
'                             src_offset => l_src_offset, ',
'                             blob_csid => DBMS_LOB.default_csid, ',
'                             lang_context => l_lang_context, ',
'                             warning => l_warning);',
'',
'  --download the app',
'  sys.htp.init;',
'  sys.owa_util.mime_header(''application/sql'', FALSE);',
'  sys.htp.p(''Content-Length: '' || sys.dbms_lob.getlength(l_blob));',
'  sys.htp.p(''Content-Disposition: filename="'' || ''Richard_Baldogi_Plug_ins_APP.sql'' || ''"'');',
'  sys.owa_util.http_header_close;',
'',
'  sys.wpg_docload.download_file(l_blob);',
'  apex_application.stop_apex_engine;',
'exception',
'  when apex_application.e_stop_apex_engine then',
'    null;',
'  when others then',
'    null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
