prompt --application/shared_components/files/style_floatingui_style_css
begin
--   Manifest
--     APP STATIC FILES: 96333
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E617065782D746F6F6C746970207B0D0A20207A2D696E6465783A20313B0D0A2020646973706C61793A206E6F6E653B0D0A2020706F736974696F6E3A206162736F6C7574653B0D0A2020746F703A20303B0D0A20206C6566743A20303B0D0A20207061';
wwv_flow_imp.g_varchar2_table(2) := '6464696E673A203570783B0D0A202070616464696E672D746F703A20313070783B0D0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(4878043499345983901)
,p_file_name=>'style/floatingui/style.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
,p_created_on=>wwv_flow_imp.dz('20230816141755Z')
,p_updated_on=>wwv_flow_imp.dz('20230816141755Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
