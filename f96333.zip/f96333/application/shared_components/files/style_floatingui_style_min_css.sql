prompt --application/shared_components/files/style_floatingui_style_min_css
begin
--   Manifest
--     APP STATIC FILES: 96333
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E617065782D746F6F6C7469707B7A2D696E6465783A313B646973706C61793A6E6F6E653B706F736974696F6E3A6162736F6C7574653B746F703A303B6C6566743A303B70616464696E673A3130707820357078203570787D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(4645842736496006802)
,p_file_name=>'style/floatingui/style.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
