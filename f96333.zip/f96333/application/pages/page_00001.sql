prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'APEX Plug-ins by Richard Baldogi'
,p_alias=>'HOME'
,p_step_title=>'APEX Plug-ins by Richard Baldogi'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_created_on=>wwv_flow_imp.dz('20230108230203Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250123222923Z')
,p_last_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6698086713522077624)
,p_plug_name=>'Neu'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_list_id=>wwv_flow_imp.id(44129704019326020537)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(44130342701054020595)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16202191943651720295)
,p_button_sequence=>10
,p_button_name=>'GUIDE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(44130366222019020605)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guide'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-glasses'
,p_created_on=>wwv_flow_imp.dz('20250123222848Z')
,p_updated_on=>wwv_flow_imp.dz('20250123222848Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16202191854724720294)
,p_name=>'Page Guidance'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16202191943651720295)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250123222848Z')
,p_updated_on=>wwv_flow_imp.dz('20250123222848Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16202191716638720293)
,p_event_id=>wwv_flow_imp.id(16202191854724720294)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.CONTEXTUALHELP.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (options) {',
'',
'    options.showProgress = true;',
'    options.animate = true;',
'    options.showButtons = ["next", "previous", "close"];',
'',
'    options.steps = [',
'        { element: "#t_Body_nav", popover: { title: "Navigation Menu", description: "The Navigation Menu helps you browse between the APEX Pages.", side: "right", align: "start" }},',
'        { element: ".t-Body-contentInner", popover: { title: "Cards Menu", description: "The Cards region also lists all the available Pages.", side: "top", align: "center" }},',
'        { element: ".t-Header-logo", popover: { title: "Navigation Bar Logo", description: "If you click on the title it will navigate to the Home Page.", side: "bottom", align: "end" }},',
'        { element: "#t_TreeNav_2", popover: { title: "Github Page", description: "Also check out my GitHub page for some hidden gems.", side: "right", align: "start" }},',
'        { element: "#t_TreeNav_4", popover: { title: "Game 2048", description: "Or if you''re looking for some fun check this out!", side: "right", align: "start" }}',
'    ];',
'    ',
'    return options;',
'}',
''))
,p_created_on=>wwv_flow_imp.dz('20250123222848Z')
,p_updated_on=>wwv_flow_imp.dz('20250123222848Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16202191603322720292)
,p_name=>'Introduction'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_created_on=>wwv_flow_imp.dz('20250123222923Z')
,p_updated_on=>wwv_flow_imp.dz('20250123222923Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16202191519998720291)
,p_event_id=>wwv_flow_imp.id(16202191603322720292)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.CONTEXTUALHELP.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (options) {',
'',
'    options.showProgress = false;',
'    options.animate = true;',
'    options.showButtons = ["close"];',
'',
'    options.steps = [',
'        { element: ".fa-glasses", popover: { title: "Guided Tour", description: "Click on this Icon if you need some guidance.", side: "left", align: "center" }}',
'    ];',
'    ',
'    return options;',
'}',
''))
,p_created_on=>wwv_flow_imp.dz('20250123222923Z')
,p_updated_on=>wwv_flow_imp.dz('20250123222923Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
