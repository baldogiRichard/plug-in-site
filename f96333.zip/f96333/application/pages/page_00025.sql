prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>25
,p_name=>'Scroll ProgressBar'
,p_alias=>'SCROLL-PROGRESSBAR'
,p_step_title=>'Scroll ProgressBar'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.github-icon-setting {',
'    background-image: ''#APP_FILES#icons/github-logo.png'';',
'}',
'',
'.scroll-bar-bottom {',
'    bottom: 0px;',
'}',
'',
'.scroll-bar-top {',
'    top: 0px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(295305678355267462679)
,p_plug_name=>'Scroll ProgressBar'
,p_icon_css_classes=>'fa-braille'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This item plug-in creates a ProgressBar which tracks the scrolling of a designated element in the Page.',
'<br>',
'<b>Scroll tracking can be calculated from different positions:</b>',
'<ul>',
'    <li>Vertical Scrolling: Top to Bottom, Bottom to Top</li>',
'    <li>Horizontal Scrolling: Left to Right, Right to left</li>',
'</ul>',
'<b>The following JS calls can be used for the plugin:</b>',
'<ul>',
'        <li>apex.item(''ITEMNAME'').getValue() : Gets the current status of the ScrollingBar which is number between 0 and 1.</li>',
'        <li>apex.item(''ITEMNAME'').setValue(someValue) : Sets the current status of the ScrollingBar which can be number between 0 and 1.</li>',
'        <li>apex.item(''ITEMNAME'').show() : Shows the Scrolling Bar.</li>',
'        <li>apex.item(''ITEMNAME'').hide() : Hides the Scrolling Bar.</li>',
'</ul>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(349067645304579492643)
,p_plug_name=>'Plug-in Container'
,p_plug_display_sequence=>40
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133432507544141585167)
,p_plug_name=>'Multiple Scroll Bars - Horizontal'
,p_parent_plug_id=>wwv_flow_imp.id(349067645304579492643)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133432507426999585166)
,p_plug_name=>'Multiple Horizontal lorem container'
,p_parent_plug_id=>wwv_flow_imp.id(133432507544141585167)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--removeHeader js-removeLandmark:t-Region--hiddenOverflow:margin-bottom-none:margin-left-none:margin-right-sm'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="lorem-ipsum-container-multiple-horizontal" style="overflow:scroll;height:inherit;white-space:nowrap">',
'    <p>',
'    Quis hendrerit facilisi massa lectus nisl vestibulum fermentum lacus montes nibh. Nec habitant viverra pharetra in fames fusce sociis ac turpis sollicitudin mattis. Faucibus sed enim sagittis quam nullam vel natoque maecenas semper, aptent cras p'
||'haretra. Fringilla fringilla tempus elementum pulvinar ultrices parturient aliquam ullamcorper congue. Cum dignissim hendrerit sit. Mollis mus quisque rutrum. Auctor mi nisl libero felis. Porttitor fusce suscipit ultrices. Nulla vivamus suspendisse p'
||'hasellus. Netus, torquent sem per pretium aliquet nec? Tortor nisi maecenas suscipit donec nulla fermentum porta quisque leo, platea porttitor. Magna luctus pulvinar mi porttitor sit ante maecenas!',
'    </p>',
'    <p>',
'    Tellus bibendum, etiam vehicula viverra parturient aliquet nulla dictum. Nibh urna curabitur suspendisse. Curabitur ante elit praesent nibh enim. Mattis id nullam senectus eu, praesent donec massa. Rhoncus parturient vulputate phasellus faucibus '
||'a mi nisl? Hendrerit convallis et posuere suspendisse luctus quam magnis ante taciti montes torquent posuere. Taciti vel cubilia ridiculus varius hendrerit! Ligula hac neque amet cursus ullamcorper nostra fusce duis etiam dignissim enim phasellus. So'
||'llicitudin vehicula cursus ante ligula sollicitudin? Praesent vivamus litora.',
'    </p>',
'    <p>',
'    Varius fames elit donec venenatis hendrerit feugiat eros mi. Nulla ut ultrices pharetra laoreet vel erat fermentum nullam. Lobortis per conubia ultricies cum sagittis tempus fringilla ac vehicula sociis, urna fringilla. Malesuada cum ultrices tor'
||'quent dignissim metus class amet erat. Ultrices leo nec bibendum senectus, augue nunc consequat. Ad accumsan convallis neque bibendum lectus cum habitasse porttitor orci litora praesent? Aliquet amet tortor parturient egestas gravida eu. Sociis venen'
||'atis himenaeos tincidunt penatibus senectus nostra sociis adipiscing ullamcorper quisque turpis tincidunt. Fames tellus cubilia.',
'    </p>',
'    <p>',
'    Platea risus scelerisque feugiat? Aliquet ligula lobortis et dictum viverra mauris sapien vehicula tellus. Taciti himenaeos proin rutrum vulputate quisque. Netus sagittis ornare auctor mus consequat. Lorem primis lobortis massa primis libero lacu'
||'s aptent vitae viverra quisque. Vehicula vivamus feugiat phasellus himenaeos nec sodales felis hac vitae molestie dis tempor. Senectus quam lacus phasellus orci. In nisl vulputate sociis ac. Sapien ultricies mauris nulla integer tincidunt est gravida'
||' interdum facilisi! Dis pharetra cum molestie suscipit porta sit. Pulvinar eu ornare integer laoreet tincidunt eleifend amet in tempor. Maecenas cursus gravida sagittis dignissim et phasellus etiam porta gravida.',
'    </p>',
'    <p>',
'    Suscipit per suscipit magna mollis sit. Consequat bibendum nibh nulla natoque aliquam. Suscipit habitasse duis consequat ligula. Velit quam velit quis massa enim tempus sociosqu varius nam habitant nullam enim. Arcu libero sed senectus. Libero so'
||'ciosqu, ultrices eu iaculis? Fusce platea facilisis inceptos ullamcorper nisl nostra orci aliquam vitae litora auctor suspendisse. Justo consectetur eget amet sed.',
'    </p>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133432507902563585171)
,p_plug_name=>'Multiple Scroll Bars - Vertical'
,p_parent_plug_id=>wwv_flow_imp.id(349067645304579492643)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133432507870898585170)
,p_plug_name=>'Multiple Vertical lorem container'
,p_parent_plug_id=>wwv_flow_imp.id(133432507902563585171)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--removeHeader js-removeLandmark:t-Region--hiddenOverflow:margin-bottom-none:margin-left-sm:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>40
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="lorem-ipsum-container-multiple-vertical" style="overflow:scroll;height:inherit;">',
'    <p>',
'    Quis hendrerit facilisi massa lectus nisl vestibulum fermentum lacus montes nibh. Nec habitant viverra pharetra in fames fusce sociis ac turpis sollicitudin mattis. Faucibus sed enim sagittis quam nullam vel natoque maecenas semper, aptent cras p'
||'haretra. Fringilla fringilla tempus elementum pulvinar ultrices parturient aliquam ullamcorper congue. Cum dignissim hendrerit sit. Mollis mus quisque rutrum. Auctor mi nisl libero felis. Porttitor fusce suscipit ultrices. Nulla vivamus suspendisse p'
||'hasellus. Netus, torquent sem per pretium aliquet nec? Tortor nisi maecenas suscipit donec nulla fermentum porta quisque leo, platea porttitor. Magna luctus pulvinar mi porttitor sit ante maecenas!',
'    </p>',
'    <p>',
'    Tellus bibendum, etiam vehicula viverra parturient aliquet nulla dictum. Nibh urna curabitur suspendisse. Curabitur ante elit praesent nibh enim. Mattis id nullam senectus eu, praesent donec massa. Rhoncus parturient vulputate phasellus faucibus '
||'a mi nisl? Hendrerit convallis et posuere suspendisse luctus quam magnis ante taciti montes torquent posuere. Taciti vel cubilia ridiculus varius hendrerit! Ligula hac neque amet cursus ullamcorper nostra fusce duis etiam dignissim enim phasellus. So'
||'llicitudin vehicula cursus ante ligula sollicitudin? Praesent vivamus litora.',
'    </p>',
'    <p>',
'    Varius fames elit donec venenatis hendrerit feugiat eros mi. Nulla ut ultrices pharetra laoreet vel erat fermentum nullam. Lobortis per conubia ultricies cum sagittis tempus fringilla ac vehicula sociis, urna fringilla. Malesuada cum ultrices tor'
||'quent dignissim metus class amet erat. Ultrices leo nec bibendum senectus, augue nunc consequat. Ad accumsan convallis neque bibendum lectus cum habitasse porttitor orci litora praesent? Aliquet amet tortor parturient egestas gravida eu. Sociis venen'
||'atis himenaeos tincidunt penatibus senectus nostra sociis adipiscing ullamcorper quisque turpis tincidunt. Fames tellus cubilia.',
'    </p>',
'    <p>',
'    Platea risus scelerisque feugiat? Aliquet ligula lobortis et dictum viverra mauris sapien vehicula tellus. Taciti himenaeos proin rutrum vulputate quisque. Netus sagittis ornare auctor mus consequat. Lorem primis lobortis massa primis libero lacu'
||'s aptent vitae viverra quisque. Vehicula vivamus feugiat phasellus himenaeos nec sodales felis hac vitae molestie dis tempor. Senectus quam lacus phasellus orci. In nisl vulputate sociis ac. Sapien ultricies mauris nulla integer tincidunt est gravida'
||' interdum facilisi! Dis pharetra cum molestie suscipit porta sit. Pulvinar eu ornare integer laoreet tincidunt eleifend amet in tempor. Maecenas cursus gravida sagittis dignissim et phasellus etiam porta gravida.',
'    </p>',
'    <p>',
'    Suscipit per suscipit magna mollis sit. Consequat bibendum nibh nulla natoque aliquam. Suscipit habitasse duis consequat ligula. Velit quam velit quis massa enim tempus sociosqu varius nam habitant nullam enim. Arcu libero sed senectus. Libero so'
||'ciosqu, ultrices eu iaculis? Fusce platea facilisis inceptos ullamcorper nisl nostra orci aliquam vitae litora auctor suspendisse. Justo consectetur eget amet sed.',
'    </p>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133432508383465585176)
,p_plug_name=>'Left to Right - Vertical Bar - Scrolling calculation starts from the bottom'
,p_parent_plug_id=>wwv_flow_imp.id(349067645304579492643)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133432507993540585172)
,p_plug_name=>'Bottom to Top lorem container'
,p_parent_plug_id=>wwv_flow_imp.id(133432508383465585176)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--removeHeader js-removeLandmark:t-Region--hiddenOverflow:margin-bottom-none:margin-left-none:margin-right-sm'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="lorem-ipsum-container-bottom-to-top" style="overflow:scroll;height:inherit;">',
'    <p>',
'    Quis hendrerit facilisi massa lectus nisl vestibulum fermentum lacus montes nibh. Nec habitant viverra pharetra in fames fusce sociis ac turpis sollicitudin mattis. Faucibus sed enim sagittis quam nullam vel natoque maecenas semper, aptent cras p'
||'haretra. Fringilla fringilla tempus elementum pulvinar ultrices parturient aliquam ullamcorper congue. Cum dignissim hendrerit sit. Mollis mus quisque rutrum. Auctor mi nisl libero felis. Porttitor fusce suscipit ultrices. Nulla vivamus suspendisse p'
||'hasellus. Netus, torquent sem per pretium aliquet nec? Tortor nisi maecenas suscipit donec nulla fermentum porta quisque leo, platea porttitor. Magna luctus pulvinar mi porttitor sit ante maecenas!',
'    </p>',
'    <p>',
'    Tellus bibendum, etiam vehicula viverra parturient aliquet nulla dictum. Nibh urna curabitur suspendisse. Curabitur ante elit praesent nibh enim. Mattis id nullam senectus eu, praesent donec massa. Rhoncus parturient vulputate phasellus faucibus '
||'a mi nisl? Hendrerit convallis et posuere suspendisse luctus quam magnis ante taciti montes torquent posuere. Taciti vel cubilia ridiculus varius hendrerit! Ligula hac neque amet cursus ullamcorper nostra fusce duis etiam dignissim enim phasellus. So'
||'llicitudin vehicula cursus ante ligula sollicitudin? Praesent vivamus litora.',
'    </p>',
'    <p>',
'    Varius fames elit donec venenatis hendrerit feugiat eros mi. Nulla ut ultrices pharetra laoreet vel erat fermentum nullam. Lobortis per conubia ultricies cum sagittis tempus fringilla ac vehicula sociis, urna fringilla. Malesuada cum ultrices tor'
||'quent dignissim metus class amet erat. Ultrices leo nec bibendum senectus, augue nunc consequat. Ad accumsan convallis neque bibendum lectus cum habitasse porttitor orci litora praesent? Aliquet amet tortor parturient egestas gravida eu. Sociis venen'
||'atis himenaeos tincidunt penatibus senectus nostra sociis adipiscing ullamcorper quisque turpis tincidunt. Fames tellus cubilia.',
'    </p>',
'    <p>',
'    Platea risus scelerisque feugiat? Aliquet ligula lobortis et dictum viverra mauris sapien vehicula tellus. Taciti himenaeos proin rutrum vulputate quisque. Netus sagittis ornare auctor mus consequat. Lorem primis lobortis massa primis libero lacu'
||'s aptent vitae viverra quisque. Vehicula vivamus feugiat phasellus himenaeos nec sodales felis hac vitae molestie dis tempor. Senectus quam lacus phasellus orci. In nisl vulputate sociis ac. Sapien ultricies mauris nulla integer tincidunt est gravida'
||' interdum facilisi! Dis pharetra cum molestie suscipit porta sit. Pulvinar eu ornare integer laoreet tincidunt eleifend amet in tempor. Maecenas cursus gravida sagittis dignissim et phasellus etiam porta gravida.',
'    </p>',
'    <p>',
'    Suscipit per suscipit magna mollis sit. Consequat bibendum nibh nulla natoque aliquam. Suscipit habitasse duis consequat ligula. Velit quam velit quis massa enim tempus sociosqu varius nam habitant nullam enim. Arcu libero sed senectus. Libero so'
||'ciosqu, ultrices eu iaculis? Fusce platea facilisis inceptos ullamcorper nisl nostra orci aliquam vitae litora auctor suspendisse. Justo consectetur eget amet sed.',
'    </p>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133432508566597585177)
,p_plug_name=>'Left to Right - Vertical Bar'
,p_parent_plug_id=>wwv_flow_imp.id(349067645304579492643)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133432508184667585174)
,p_plug_name=>'Top to Bottom lorem container'
,p_parent_plug_id=>wwv_flow_imp.id(133432508566597585177)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--removeHeader js-removeLandmark:t-Region--hiddenOverflow:margin-bottom-none:margin-left-sm'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="lorem-ipsum-container-top-to-bottom" style="overflow:scroll;height:inherit;">',
'    <p>',
'    Quis hendrerit facilisi massa lectus nisl vestibulum fermentum lacus montes nibh. Nec habitant viverra pharetra in fames fusce sociis ac turpis sollicitudin mattis. Faucibus sed enim sagittis quam nullam vel natoque maecenas semper, aptent cras p'
||'haretra. Fringilla fringilla tempus elementum pulvinar ultrices parturient aliquam ullamcorper congue. Cum dignissim hendrerit sit. Mollis mus quisque rutrum. Auctor mi nisl libero felis. Porttitor fusce suscipit ultrices. Nulla vivamus suspendisse p'
||'hasellus. Netus, torquent sem per pretium aliquet nec? Tortor nisi maecenas suscipit donec nulla fermentum porta quisque leo, platea porttitor. Magna luctus pulvinar mi porttitor sit ante maecenas!',
'    </p>',
'    <p>',
'    Tellus bibendum, etiam vehicula viverra parturient aliquet nulla dictum. Nibh urna curabitur suspendisse. Curabitur ante elit praesent nibh enim. Mattis id nullam senectus eu, praesent donec massa. Rhoncus parturient vulputate phasellus faucibus '
||'a mi nisl? Hendrerit convallis et posuere suspendisse luctus quam magnis ante taciti montes torquent posuere. Taciti vel cubilia ridiculus varius hendrerit! Ligula hac neque amet cursus ullamcorper nostra fusce duis etiam dignissim enim phasellus. So'
||'llicitudin vehicula cursus ante ligula sollicitudin? Praesent vivamus litora.',
'    </p>',
'    <p>',
'    Varius fames elit donec venenatis hendrerit feugiat eros mi. Nulla ut ultrices pharetra laoreet vel erat fermentum nullam. Lobortis per conubia ultricies cum sagittis tempus fringilla ac vehicula sociis, urna fringilla. Malesuada cum ultrices tor'
||'quent dignissim metus class amet erat. Ultrices leo nec bibendum senectus, augue nunc consequat. Ad accumsan convallis neque bibendum lectus cum habitasse porttitor orci litora praesent? Aliquet amet tortor parturient egestas gravida eu. Sociis venen'
||'atis himenaeos tincidunt penatibus senectus nostra sociis adipiscing ullamcorper quisque turpis tincidunt. Fames tellus cubilia.',
'    </p>',
'    <p>',
'    Platea risus scelerisque feugiat? Aliquet ligula lobortis et dictum viverra mauris sapien vehicula tellus. Taciti himenaeos proin rutrum vulputate quisque. Netus sagittis ornare auctor mus consequat. Lorem primis lobortis massa primis libero lacu'
||'s aptent vitae viverra quisque. Vehicula vivamus feugiat phasellus himenaeos nec sodales felis hac vitae molestie dis tempor. Senectus quam lacus phasellus orci. In nisl vulputate sociis ac. Sapien ultricies mauris nulla integer tincidunt est gravida'
||' interdum facilisi! Dis pharetra cum molestie suscipit porta sit. Pulvinar eu ornare integer laoreet tincidunt eleifend amet in tempor. Maecenas cursus gravida sagittis dignissim et phasellus etiam porta gravida.',
'    </p>',
'    <p>',
'    Suscipit per suscipit magna mollis sit. Consequat bibendum nibh nulla natoque aliquam. Suscipit habitasse duis consequat ligula. Velit quam velit quis massa enim tempus sociosqu varius nam habitant nullam enim. Arcu libero sed senectus. Libero so'
||'ciosqu, ultrices eu iaculis? Fusce platea facilisis inceptos ullamcorper nisl nostra orci aliquam vitae litora auctor suspendisse. Justo consectetur eget amet sed.',
'    </p>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(207130330409086006771)
,p_plug_name=>'Right to Left - Horizontal Bar'
,p_parent_plug_id=>wwv_flow_imp.id(349067645304579492643)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(207130330158276006769)
,p_plug_name=>'Right to Left lorem container'
,p_parent_plug_id=>wwv_flow_imp.id(207130330409086006771)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--removeHeader js-removeLandmark:t-Region--hiddenOverflow:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="lorem-ipsum-container-right-to-left" style="overflow:scroll;height:inherit;">',
'    <p>',
'    Quis hendrerit facilisi massa lectus nisl vestibulum fermentum lacus montes nibh. Nec habitant viverra pharetra in fames fusce sociis ac turpis sollicitudin mattis. Faucibus sed enim sagittis quam nullam vel natoque maecenas semper, aptent cras p'
||'haretra. Fringilla fringilla tempus elementum pulvinar ultrices parturient aliquam ullamcorper congue. Cum dignissim hendrerit sit. Mollis mus quisque rutrum. Auctor mi nisl libero felis. Porttitor fusce suscipit ultrices. Nulla vivamus suspendisse p'
||'hasellus. Netus, torquent sem per pretium aliquet nec? Tortor nisi maecenas suscipit donec nulla fermentum porta quisque leo, platea porttitor. Magna luctus pulvinar mi porttitor sit ante maecenas!',
'    </p>',
'    <p>',
'    Tellus bibendum, etiam vehicula viverra parturient aliquet nulla dictum. Nibh urna curabitur suspendisse. Curabitur ante elit praesent nibh enim. Mattis id nullam senectus eu, praesent donec massa. Rhoncus parturient vulputate phasellus faucibus '
||'a mi nisl? Hendrerit convallis et posuere suspendisse luctus quam magnis ante taciti montes torquent posuere. Taciti vel cubilia ridiculus varius hendrerit! Ligula hac neque amet cursus ullamcorper nostra fusce duis etiam dignissim enim phasellus. So'
||'llicitudin vehicula cursus ante ligula sollicitudin? Praesent vivamus litora.',
'    </p>',
'    <p>',
'    Varius fames elit donec venenatis hendrerit feugiat eros mi. Nulla ut ultrices pharetra laoreet vel erat fermentum nullam. Lobortis per conubia ultricies cum sagittis tempus fringilla ac vehicula sociis, urna fringilla. Malesuada cum ultrices tor'
||'quent dignissim metus class amet erat. Ultrices leo nec bibendum senectus, augue nunc consequat. Ad accumsan convallis neque bibendum lectus cum habitasse porttitor orci litora praesent? Aliquet amet tortor parturient egestas gravida eu. Sociis venen'
||'atis himenaeos tincidunt penatibus senectus nostra sociis adipiscing ullamcorper quisque turpis tincidunt. Fames tellus cubilia.',
'    </p>',
'    <p>',
'    Platea risus scelerisque feugiat? Aliquet ligula lobortis et dictum viverra mauris sapien vehicula tellus. Taciti himenaeos proin rutrum vulputate quisque. Netus sagittis ornare auctor mus consequat. Lorem primis lobortis massa primis libero lacu'
||'s aptent vitae viverra quisque. Vehicula vivamus feugiat phasellus himenaeos nec sodales felis hac vitae molestie dis tempor. Senectus quam lacus phasellus orci. In nisl vulputate sociis ac. Sapien ultricies mauris nulla integer tincidunt est gravida'
||' interdum facilisi! Dis pharetra cum molestie suscipit porta sit. Pulvinar eu ornare integer laoreet tincidunt eleifend amet in tempor. Maecenas cursus gravida sagittis dignissim et phasellus etiam porta gravida.',
'    </p>',
'    <p>',
'    Suscipit per suscipit magna mollis sit. Consequat bibendum nibh nulla natoque aliquam. Suscipit habitasse duis consequat ligula. Velit quam velit quis massa enim tempus sociosqu varius nam habitant nullam enim. Arcu libero sed senectus. Libero so'
||'ciosqu, ultrices eu iaculis? Fusce platea facilisis inceptos ullamcorper nisl nostra orci aliquam vitae litora auctor suspendisse. Justo consectetur eget amet sed.',
'    </p>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(207130330555152006773)
,p_plug_name=>'Left to Right - Horizontal Bar'
,p_parent_plug_id=>wwv_flow_imp.id(349067645304579492643)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(207130330681818006774)
,p_plug_name=>'Left to Right lorem container'
,p_parent_plug_id=>wwv_flow_imp.id(207130330555152006773)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h320:t-Region--removeHeader js-removeLandmark:t-Region--hiddenOverflow:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="lorem-ipsum-container-left-to-right" style="overflow:scroll;height:inherit;">',
'    <p>',
'    Quis hendrerit facilisi massa lectus nisl vestibulum fermentum lacus montes nibh. Nec habitant viverra pharetra in fames fusce sociis ac turpis sollicitudin mattis. Faucibus sed enim sagittis quam nullam vel natoque maecenas semper, aptent cras p'
||'haretra. Fringilla fringilla tempus elementum pulvinar ultrices parturient aliquam ullamcorper congue. Cum dignissim hendrerit sit. Mollis mus quisque rutrum. Auctor mi nisl libero felis. Porttitor fusce suscipit ultrices. Nulla vivamus suspendisse p'
||'hasellus. Netus, torquent sem per pretium aliquet nec? Tortor nisi maecenas suscipit donec nulla fermentum porta quisque leo, platea porttitor. Magna luctus pulvinar mi porttitor sit ante maecenas!',
'    </p>',
'    <p>',
'    Tellus bibendum, etiam vehicula viverra parturient aliquet nulla dictum. Nibh urna curabitur suspendisse. Curabitur ante elit praesent nibh enim. Mattis id nullam senectus eu, praesent donec massa. Rhoncus parturient vulputate phasellus faucibus '
||'a mi nisl? Hendrerit convallis et posuere suspendisse luctus quam magnis ante taciti montes torquent posuere. Taciti vel cubilia ridiculus varius hendrerit! Ligula hac neque amet cursus ullamcorper nostra fusce duis etiam dignissim enim phasellus. So'
||'llicitudin vehicula cursus ante ligula sollicitudin? Praesent vivamus litora.',
'    </p>',
'    <p>',
'    Varius fames elit donec venenatis hendrerit feugiat eros mi. Nulla ut ultrices pharetra laoreet vel erat fermentum nullam. Lobortis per conubia ultricies cum sagittis tempus fringilla ac vehicula sociis, urna fringilla. Malesuada cum ultrices tor'
||'quent dignissim metus class amet erat. Ultrices leo nec bibendum senectus, augue nunc consequat. Ad accumsan convallis neque bibendum lectus cum habitasse porttitor orci litora praesent? Aliquet amet tortor parturient egestas gravida eu. Sociis venen'
||'atis himenaeos tincidunt penatibus senectus nostra sociis adipiscing ullamcorper quisque turpis tincidunt. Fames tellus cubilia.',
'    </p>',
'    <p>',
'    Platea risus scelerisque feugiat? Aliquet ligula lobortis et dictum viverra mauris sapien vehicula tellus. Taciti himenaeos proin rutrum vulputate quisque. Netus sagittis ornare auctor mus consequat. Lorem primis lobortis massa primis libero lacu'
||'s aptent vitae viverra quisque. Vehicula vivamus feugiat phasellus himenaeos nec sodales felis hac vitae molestie dis tempor. Senectus quam lacus phasellus orci. In nisl vulputate sociis ac. Sapien ultricies mauris nulla integer tincidunt est gravida'
||' interdum facilisi! Dis pharetra cum molestie suscipit porta sit. Pulvinar eu ornare integer laoreet tincidunt eleifend amet in tempor. Maecenas cursus gravida sagittis dignissim et phasellus etiam porta gravida.',
'    </p>',
'    <p>',
'    Suscipit per suscipit magna mollis sit. Consequat bibendum nibh nulla natoque aliquam. Suscipit habitasse duis consequat ligula. Velit quam velit quis massa enim tempus sociosqu varius nam habitant nullam enim. Arcu libero sed senectus. Libero so'
||'ciosqu, ultrices eu iaculis? Fusce platea facilisis inceptos ullamcorper nisl nostra orci aliquam vitae litora auctor suspendisse. Justo consectetur eget amet sed.',
'    </p>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(26714604014298440657)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(295305678355267462679)
,p_button_name=>'GITHUB'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(44130367022408020606)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Github'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'https://github.com/baldogiRichard/apex-scroll-progress-bar'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-github'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133432511864547585180)
,p_name=>'P25_SCROLL_TTB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(133432508566597585177)
,p_display_as=>'PLUGIN_COM.SCROLLPROGRESSBAR.PLUGIN'
,p_cHeight=>10
,p_attribute_01=>'TB'
,p_attribute_02=>'TB'
,p_attribute_03=>'#f0cc71'
,p_attribute_04=>'.lorem-ipsum-container-top-to-bottom'
,p_attribute_05=>'L'
,p_attribute_06=>'15'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133432513226687585180)
,p_name=>'P25_SCROLL_BTT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(133432508383465585176)
,p_display_as=>'PLUGIN_COM.SCROLLPROGRESSBAR.PLUGIN'
,p_cHeight=>10
,p_attribute_01=>'BT'
,p_attribute_02=>'BT'
,p_attribute_03=>'#5f7d4f'
,p_attribute_04=>'.lorem-ipsum-container-bottom-to-top'
,p_attribute_05=>'R'
,p_attribute_06=>'15'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133432514412602585176)
,p_name=>'P25_SCROLL_MULTIPLE_VERTICAL_2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(133432507902563585171)
,p_display_as=>'PLUGIN_COM.SCROLLPROGRESSBAR.PLUGIN'
,p_cHeight=>10
,p_tag_css_classes=>'scroll-bar-bottom'
,p_attribute_01=>'TB'
,p_attribute_02=>'TB'
,p_attribute_04=>'.lorem-ipsum-container-multiple-vertical'
,p_attribute_05=>'L'
,p_attribute_06=>'10'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133432514493220585177)
,p_name=>'P25_SCROLL_MULTIPLE_VERTICAL_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(133432507902563585171)
,p_display_as=>'PLUGIN_COM.SCROLLPROGRESSBAR.PLUGIN'
,p_attribute_01=>'LR'
,p_attribute_02=>'TB'
,p_attribute_04=>'.lorem-ipsum-container-multiple-vertical'
,p_attribute_06=>'10'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133432515793308585174)
,p_name=>'P25_SCROLL_MULTIPLE_HORIZONTAL_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(133432507544141585167)
,p_display_as=>'PLUGIN_COM.SCROLLPROGRESSBAR.PLUGIN'
,p_cHeight=>10
,p_tag_css_classes=>'scroll-bar-bottom'
,p_attribute_01=>'BT'
,p_attribute_02=>'LR'
,p_attribute_03=>'#5f7d4f'
,p_attribute_04=>'.lorem-ipsum-container-multiple-horizontal'
,p_attribute_05=>'R'
,p_attribute_06=>'10'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133432515926185585175)
,p_name=>'P25_SCROLL_MULTIPLE_HORIZONTAL_1'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(133432507544141585167)
,p_display_as=>'PLUGIN_COM.SCROLLPROGRESSBAR.PLUGIN'
,p_attribute_01=>'RL'
,p_attribute_02=>'LR'
,p_attribute_03=>'#5f7d4f'
,p_attribute_04=>'.lorem-ipsum-container-multiple-horizontal'
,p_attribute_06=>'10'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207130343454388006787)
,p_name=>'P25_SCROLL_RTL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(207130330409086006771)
,p_display_as=>'PLUGIN_COM.SCROLLPROGRESSBAR.PLUGIN'
,p_attribute_01=>'RL'
,p_attribute_02=>'TB'
,p_attribute_03=>'#5f7d4f'
,p_attribute_04=>'.lorem-ipsum-container-right-to-left'
,p_attribute_06=>'5'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207130343994623006789)
,p_name=>'P25_SCROLL_LTR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(207130330555152006773)
,p_display_as=>'PLUGIN_COM.SCROLLPROGRESSBAR.PLUGIN'
,p_attribute_01=>'LR'
,p_attribute_02=>'TB'
,p_attribute_03=>'#f0cc71'
,p_attribute_04=>'.lorem-ipsum-container-left-to-right'
,p_attribute_06=>'5'
);
wwv_flow_imp.component_end;
end;
/
