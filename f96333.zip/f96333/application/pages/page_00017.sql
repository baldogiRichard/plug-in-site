prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'Radialbars Charts Basic'
,p_alias=>'RADIALBARS-CIRCLE-CHARTS'
,p_step_title=>'Radialbars Charts Basic'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(143847550329636962627)
,p_plug_name=>'Radialbars Charts Basic'
,p_icon_css_classes=>'fa-polar-chart'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a Radialbar / Circle Chart?',
'<br>',
'<br>',
'Radial Bar Charts are valuable in showing comparisons between categories by using circularly shaped bars. Also known as the circular bar chart, it is simply a typical bar chart plot represented on a polar coordinate system.',
'<br>',
'<br>',
'Source: <a href="https://apexcharts.com/javascript-chart-demos/radialbar-charts/">https://apexcharts.com/javascript-chart-demos/radialbar-charts/</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(149305594436298186622)
,p_plug_name=>'Radialbar Charts'
,p_icon_css_classes=>'fa-circle-5-8'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3575083940557944937)
,p_plug_name=>'Radialbar Charts Multiple'
,p_parent_plug_id=>wwv_flow_imp.id(149305594436298186622)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.CATEGORY,',
'       t.VALUE',
'from APEXCHARTS_RADIALCIRCLE t'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'',
'    config.plotOptions = {',
'        radialBar: {',
'            dataLabels: {',
'                    total: {',
'                    show: true,',
'                    label: ''Total'',',
'                    formatter: function (w) {',
'                        var array = w.config.series;',
'                        var count = 0;',
'                        for(var i=0, n=array.length; i < n; i++) {',
'                            count += array[i]; ',
'                        }',
'                        return count;',
'                    }',
'                }',
'            }',
'        }',
'    }',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'radialBar',
  'attribute_02', 'radial_chart_2',
  'attribute_03', 'Radialbar Charts Multiple',
  'attribute_04', '500',
  'attribute_05', '400',
  'attribute_06', 'CATEGORY',
  'attribute_08', 'VALUE',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575083765398944936)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>10
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575083696441944935)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3575083574025944934)
,p_plug_name=>'Radialbar Charts Stroked'
,p_parent_plug_id=>wwv_flow_imp.id(149305594436298186622)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>6
,p_plug_display_column=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.CATEGORY,',
'       t.VALUE',
'from APEXCHARTS_RADIALCIRCLE t',
'where t.value = 61'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'',
'    config.plotOptions = {',
'        radialBar: {',
'            startAngle: -135,',
'            endAngle: 135,',
'            dataLabels: {',
'                    name: {',
'                    fontSize: ''16px'',',
'                    color: undefined,',
'                    offsetY: 120',
'                },',
'                    value: {',
'                    offsetY: 76,',
'                    fontSize: ''22px'',',
'                    color: undefined,',
'                    formatter: function (val) {return val + "%";}',
'                }',
'            }',
'        }',
'    };',
'',
'    config.stroke = {dashArray: 4};',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'radialBar',
  'attribute_02', 'radial_chart_3',
  'attribute_03', 'Radialbar Charts Stroked',
  'attribute_04', '500',
  'attribute_05', '400',
  'attribute_06', 'CATEGORY',
  'attribute_08', 'VALUE',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575083528398944933)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>10
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575083369218944932)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(149305594546283186623)
,p_plug_name=>'Radialbar Charts Basic'
,p_parent_plug_id=>wwv_flow_imp.id(149305594436298186622)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.CATEGORY,',
'       t.VALUE',
'from APEXCHARTS_RADIALCIRCLE t',
'where t.value = 67'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'radialBar',
  'attribute_02', 'radial_chart_1',
  'attribute_03', 'Radialbar Charts Basic',
  'attribute_04', '500',
  'attribute_05', '400',
  'attribute_06', 'CATEGORY',
  'attribute_08', 'VALUE',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11848222544312254530)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(41172743597484117843)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
