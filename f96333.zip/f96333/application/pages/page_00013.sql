prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'Boxplot Charts'
,p_alias=>'BOXPLOT-CHARTS'
,p_step_title=>'Boxplot Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82377941022417453249)
,p_plug_name=>'Boxplot Charts'
,p_icon_css_classes=>'fa-braille'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a Boxplot Chart?',
'<br>',
'<br>',
'A Box and Whisker Plot (or Box Plot) is a convenient way of visually displaying the data distribution through their quartiles.',
unistr('The lines extending parallel from the boxes are known as the \201Cwhiskers\201D, which are used to indicate variability outside the upper and lower quartiles. Outliers are sometimes plotted as individual dots that are in-line with whiskers. Box Plots can be ')
||'drawn either vertically or horizontally.',
'Although Box Plots may seem primitive in comparison to a Histogram or Density Plot, they have the advantage of taking up less space, which is useful when comparing distributions between many groups or datasets.',
'<br>',
'<br>',
'Source: <a href="https://datavizcatalogue.com/methods/box_plot.html">https://datavizcatalogue.com/methods/box_plot.html</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87835985129078677244)
,p_plug_name=>'Boxplot Charts'
,p_icon_css_classes=>'fa-box-plot-chart'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5068529746004885234)
,p_plug_name=>'Boxplot Charts Horizontal'
,p_parent_plug_id=>wwv_flow_imp.id(87835985129078677244)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CATEGORY,',
'       MINIMUM,',
'       Q1,',
'       MEDIAN,',
'       Q3,',
'       MAXIMUM',
'from APEXCHARTS_BOXPLOT_HORIZONTAL'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'',
'    config.yaxis = {tooltip: {enabled: true}};',
'        ',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'boxPlot-horizontal',
  'attribute_02', 'boxplot_chart_2',
  'attribute_03', 'Boxplot Charts Horizontal',
  'attribute_04', '700',
  'attribute_05', '300',
  'attribute_07', 'CATEGORY',
  'attribute_09', 'MINIMUM,Q1,MEDIAN,Q3,MAXIMUM',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N',
  'attribute_18', 'x')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068529589424885233)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068529464860885232)
,p_name=>'MINIMUM'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>20
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068529420949885231)
,p_name=>'Q1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068529349167885230)
,p_name=>'MEDIAN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068529220082885229)
,p_name=>'Q3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068529059681885228)
,p_name=>'MAXIMUM'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87835985239063677245)
,p_plug_name=>'Boxplot Charts Basic'
,p_parent_plug_id=>wwv_flow_imp.id(87835985129078677244)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CATEGORY,',
'       MINIMUM,',
'       Q1,',
'       MEDIAN,',
'       Q3,',
'       MAXIMUM',
'from APEXCHARTS_BOXPLOT_HORIZONTAL'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'',
'    config.yaxis = {tooltip: {enabled: true}};',
'        ',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'boxPlot-vertical',
  'attribute_02', 'boxplot_chart_1',
  'attribute_03', 'Boxplot Charts Basic',
  'attribute_04', '700',
  'attribute_05', '300',
  'attribute_07', 'CATEGORY',
  'attribute_09', 'MINIMUM,Q1,MEDIAN,Q3,MAXIMUM',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N',
  'attribute_18', 'x')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068530242657885239)
,p_name=>'MINIMUM'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068530118469885238)
,p_name=>'Q1'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>130
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068530018981885237)
,p_name=>'MEDIAN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>140
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068529925387885236)
,p_name=>'Q3'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>150
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068529769629885235)
,p_name=>'MAXIMUM'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>160
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10056004129802359328)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
