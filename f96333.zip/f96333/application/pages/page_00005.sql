prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Plug-ins'
,p_alias=>'PLUG-INS'
,p_step_title=>'Plug-ins'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'06'
,p_created_on=>wwv_flow_imp.dz('20230108230203Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221120211352Z')
,p_last_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(135622273992138363)
,p_plug_name=>'Neu'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--3cols:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_list_id=>wwv_flow_imp.id(6836180686686254784)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(44130342701054020595)
);
wwv_flow_imp.component_end;
end;
/
