prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'Treemap Charts'
,p_alias=>'TREEMAP-CHARTS'
,p_step_title=>'Treemap Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_created_on=>wwv_flow_imp.dz('20230108230204Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221120211700Z')
,p_last_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(211206576484668986072)
,p_plug_name=>'Treemap Charts'
,p_icon_css_classes=>'fa-heat-map'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a Treemap Chart?',
'<br>',
'<br>',
'Treemapping is a data visualization technique that displays hierarchical data using rectangles of decreasing sizes, often called nesting, to create treemap charts. As the name suggests, treemap charts depict data in a tree-like format, with branches '
||'and sub-branches that are able to be read at a glance. Treemaps are great at taking a large amount of raw data and depicting it in a visually appealing, compact, and easy-to-read manner, enabling the user to discern patterns and make comparisons rapi'
||'dly.',
'<br>',
'<br>',
'Source: <a href="https://www.tibco.com/reference-center/what-is-a-treemap-chart">https://www.tibco.com/reference-center/what-is-a-treemap-chart</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(216664620591330210067)
,p_plug_name=>'Treemap Charts'
,p_icon_css_classes=>'fa-tree-org'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1870013093959207750)
,p_plug_name=>'Treemap Charts Multiple'
,p_parent_plug_id=>wwv_flow_imp.id(216664620591330210067)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CATEGORY,',
'       nvl(desktop,mobile) as VALUE,',
'       case when desktop is null',
'             then ''Mobile''',
'            else ''Desktop''',
'       end as DEVICE_TYPE',
'  from APEXCHARTS_TREEMAP_MULTIPLE'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'treemap',
  'attribute_02', 'treemap_chart_2',
  'attribute_03', 'Treemap Charts Multiple',
  'attribute_04', '700',
  'attribute_05', '500',
  'attribute_07', 'CATEGORY',
  'attribute_08', 'VALUE',
  'attribute_13', 'DEVICE_TYPE',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870012627103207745)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870012317990207742)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870012196754207741)
,p_name=>'DEVICE_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(216664620701315210068)
,p_plug_name=>'Treemap Charts basic'
,p_parent_plug_id=>wwv_flow_imp.id(216664620591330210067)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       CITY,',
'       VALUE,',
'       ''Hungary'' as STATIC',
'  from APEXCHARTS_TREEMAP_BASIC'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'treemap',
  'attribute_02', 'treemap_chart_1',
  'attribute_03', 'Treemap Charts basic',
  'attribute_04', '700',
  'attribute_05', '500',
  'attribute_07', 'CITY',
  'attribute_08', 'VALUE',
  'attribute_13', 'STATIC',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870013408298207753)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>130
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870013302213207752)
,p_name=>'CITY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870013192455207751)
,p_name=>'STATIC'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(108531769752516141288)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
