prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'About me'
,p_alias=>'ABOUT-ME'
,p_step_title=>'About me'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*cards grid*/',
'.aeh-grid-main {',
'    align-items: center;',
'    display: flex;',
'    justify-content: center;',
'}',
'',
'.aeh-grid {',
'    float: left;',
'    margin-left: 20px;',
'    margin-right: 20px;',
'    margin-top: 10px;',
'}',
'',
'.aeh-circule {',
'    border-radius: 50%;',
'    border: none;',
'    height: 60px;',
'    width: 60px;',
'    color: #ffffff;',
'    box-shadow: 0 13px 26px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.16);',
'}',
'',
'.aeh-circule-b {',
'    border-radius: 50%;',
'    border: none;',
'    height: 48px;',
'    width: 48px;',
'    color: #ffffff;',
'    box-shadow: 0 13px 26px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.16);',
'}',
'',
'.aeh-color-a{',
'    background: #3F9EFC;',
'}',
'',
'.aeh-color-b{',
'    background: #C90A6D;',
'}',
'',
'.aeh-cardsub {',
'    border-top: 2px solid;',
'    border-color: #E4E8ED;',
'}',
'',
'.aeh-grid-icon {',
'    display: flex; ',
'    justify-content: center; ',
'    top: 25%;',
'}',
'',
'.aeh-profile {',
'    border-radius: 100%;',
'    width: 132px;',
'    height: 128px;',
'    background-color: #C90A6D',
'}',
'',
'/*prof pics modifier*/',
'.a-CardView-items--row .a-CardView {',
'    grid-template-rows: minmax(0,auto) 1fr;',
'}',
'',
'.a-CardView-media--first {',
'    margin: 1rem 1rem 1rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_created_on=>wwv_flow_imp.dz('20230108230203Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221120211836Z')
,p_last_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46494186705524589144)
,p_plug_name=>'Search Results'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_plug_template=>wwv_flow_imp.id(44130247058898020558)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Richard Baldogi'' as "FULLNAME",',
'       ''Welcome in my Application Express site!'' ||',
'       ''I hope you are doing great! Just call me Richard. I first met with Oracle APEX in 2018 when I started to work as a PL/SQL Developer in a Hungarian financial institution in Budapest.',
unistr('        First time I didn\2019t understand much about it and found it a little bit messy, but with time and practice I realised how fun that platform is to work with and my enthusiasm is still at it\2019s highest peak. '),
'        Since then I deepened my knowledge and always find some hidden gems which I can use in my everyday work. Im also teaching people APEX development on any level. I hope you are having fun in this site and find my plug-ins useful. ',
'        You can get in touch with me under these contacts:'' as "ABOUT",',
'       ''https://www.linkedin.com/in/rb-627543146/'' as "LINKEDIN_URL",',
'       ''https://twitter.com/O_APEX_Hungary'' as "TWITTER_URL",',
'       ''Oracle APEX Developer'' as "U_POSITION",',
'       ''baldogi.richard@gmail.com'' as "PUBLIC_EMAIL_ADDRESS",',
'       ''#APP_FILES#me/me.jpg'' as "ME"',
'from dual m'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9478148169360808019)
,p_region_id=>wwv_flow_imp.id(46494186705524589144)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'FULLNAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'U_POSITION'
,p_body_adv_formatting=>false
,p_body_column_name=>'ABOUT'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="aeh-grid-main aeh-cardsub">',
'    {if FB_URL/}',
'    <div class="aeh-grid aeh-circule-b">',
'        <a href=&FB_URL. target="_blank">',
'            <img src="#APP_FILES#icons/facebook_logo_icon_147291.png">',
'        </a>',
'    </div>',
'    {endif/}',
'    {if LINKEDIN_URL/}',
'    <div class="aeh-grid aeh-circule-b">',
'        <a href=&LINKEDIN_URL. target="_blank">',
'            <img src="#APP_FILES#icons/linkedin_icon-icons.com_65929.png">',
'        </a>',
'    </div>',
'    {endif/}',
'    {if TWITTER_URL/}',
'    <div class="aeh-grid aeh-circule-b">',
'        <a href=&TWITTER_URL. target="_blank">',
'            <img src="#APP_FILES#icons/1491579542-yumminkysocialmedia22_83078.png">',
'        </a>',
'    </div>',
'    {endif/}',
'    {if YOUTUBE_URL/}',
'    <div class="aeh-grid aeh-circule-b">',
'        <a href=&YOUTUBE_URL. target="_blank">',
'            <img src="#APP_FILES#icons/1491580651-yumminkysocialmedia28_83061.png">',
'        </a>',
'    </div>',
'    {endif/}',
'    {if BLOG_URL/}',
'    <div class="aeh-grid aeh-circule-b">',
'        <a href=&BLOG_URL. target="_blank">',
'            <img src="#APP_FILES#icons/iconfinder-blog-4661578_122455.png">',
'        </a>',
'    </div>',
'    {endif/}',
'    {if PUBLIC_EMAIL_ADDRESS/}',
'    <div class="aeh-grid aeh-circule-b" style="background-color:antiquewhite">',
'        <a href=mailto:&PUBLIC_EMAIL_ADDRESS.>',
'            <span class="fa fa-envelope fa-lg" style="margin:9px;color:white"></span>',
'        </a>',
'    </div>',
'    {endif/}',
'</div>'))
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'ME'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'SQUARE'
,p_media_sizing=>'COVER'
);
wwv_flow_imp.component_end;
end;
/
