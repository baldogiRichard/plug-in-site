prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>27
,p_name=>'Hierarchy Chart'
,p_alias=>'HIERARCHY-CHART'
,p_step_title=>'Hierarchy Chart'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198060317761606885811)
,p_plug_name=>'Hierarchy Chart'
,p_icon_css_classes=>'fa-dataset'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This plug-in helps to visualize data in a hierarchical view with flexible capabilities of displaying custom node content and rendering large and complex hierarchies with partial load behaviour.</p>',
'<p>This plug-in uses the <a href="https://github.com/bumbeishvili/org-chart" rel="nofollow">Bumbeishvili org-chart</a> library.</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(233937303453037611451)
,p_plug_name=>'Hierarchy Chart Plugin'
,p_region_name=>'orgchart'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       PARENTID,',
'       LEVEL,',
'       EMPLOYEENAME,',
'       replace(IMAGEURL,''APP_FILES'',v(''APP_FILES'')) AS IMAGEURL,',
'       OFFICE,',
'       POSITIONNAME,',
'       ''Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed et lectus lorem....'' as DESCRIPTION',
'from APEX_HIERARCHY_CHART',
'connect by prior ID = PARENTID',
'start with PARENTID is null'))
,p_plug_source_type=>'PLUGIN_COM.APEXHIERARCHYCHART.PLUGIN'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'id_column', 'ID',
  'last_node_level_to_be_expanded', '2',
  'node_button_template', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<div class="node-button-div" style="pointer-events: none; display: flex; width: 100%; height: 100%;">',
    '    <div style="border:1px solid #E4E2E9;border-radius:3px;padding:3px;font-size:9px;margin:auto auto;background-color:white">',
    '        <div style="display:flex;">',
    '            <span style="align-items:center;display:flex;">',
    '                <svg width="8" height="8" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">',
    '                    <path d="M19.497 7.98903L12 15.297L4.503 7.98903C4.36905 7.85819 4.18924 7.78495 4.002 7.78495C3.81476 7.78495 3.63495 7.85819 3.501 7.98903C3.43614 8.05257 3.38462 8.12842 3.34944 8.21213C3.31427 8.29584 3.29615 8.38573 3.29615 8'
||'.47653C3.29615 8.56733 3.31427 8.65721 3.34944 8.74092C3.38462 8.82463 3.43614 8.90048 3.501 8.96403L11.4765 16.74C11.6166 16.8765 11.8044 16.953 12 16.953C12.1956 16.953 12.3834 16.8765 12.5235 16.74L20.499 8.96553C20.5643 8.90193 20.6162 8.8259 20.'
||'6517 8.74191C20.6871 8.65792 20.7054 8.56769 20.7054 8.47653C20.7054 8.38537 20.6871 8.29513 20.6517 8.21114C20.6162 8.12715 20.5643 8.05112 20.499 7.98753C20.3651 7.85669 20.1852 7.78345 19.998 7.78345C19.8108 7.78345 19.6309 7.85669 19.497 7.98753V'
||'7.98903Z" fill="#716E7B" stroke="#716E7B">                        ',
    '                    </path>',
    '                </svg>',
    '            </span>',
    '            <span style="margin-left:1px;color:#716E7B">${_directSubordinatesPaging}',
    '            </span>',
    '        </div>',
    '    </div>',
    '</div>')),
  'node_height', '450',
  'node_level_column', 'LEVEL',
  'node_template', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<div class="t-Region-body">',
    '    <div class="a-CardView has-title has-subtitle has-body has-icon has-icon--start has-media has-media--first has-media--cover">',
    '        <div class="a-CardView-media a-CardView-media--first  a-CardView-media--cover ">',
    '            <img class="a-CardView-mediaImg" src="${IMAGEURL}" alt="image" loading="lazy">',
    '        </div>',
    '        <div class="a-CardView-header">',
    '            <div class="a-CardView-iconWrap a-CardView-iconWrap--start">',
    '                <span class="a-CardView-initials u-color " aria-hidden="true" title="" style="width:95px">${OFFICE}</span>',
    '            </div>',
    '            <div class="a-CardView-headerBody">',
    '                <h3 class="a-CardView-title ">${EMPLOYEENAME}</h3>',
    '                <h4 class="a-CardView-subTitle ">${POSITIONNAME}</h4>',
    '            </div>',
    '        </div>',
    '        <div class="a-CardView-body">',
    '            <div class="a-CardView-mainContent ">${DESCRIPTION}',
    '            </div>',
    '        </div>',
    '    </div>',
    '</div>')),
  'node_template_column', 'EMPLOYEENAME,IMAGEURL,OFFICE,POSITIONNAME,DESCRIPTION',
  'node_width', '300',
  'parent_id_column', 'PARENTID',
  'partial_data_load', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(233937303532667611452)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>10
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(233937303673128611453)
,p_name=>'EMPLOYEENAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(233937303747504611454)
,p_name=>'IMAGEURL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(233937303809791611455)
,p_name=>'OFFICE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(233937303906434611456)
,p_name=>'POSITIONNAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(233937304038830611457)
,p_name=>'PARENTID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(233937304145925611458)
,p_name=>'LEVEL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(233937304389472611460)
,p_name=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(62097293387037212402)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(198060317761606885811)
,p_button_name=>'GITHUB'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(44130367022408020606)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Github'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'https://github.com/baldogiRichard/apex-hierarchy-chart'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-github'
);
wwv_flow_imp.component_end;
end;
/
