prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77158938826503962969)
,p_plug_name=>'Dropdown Menu'
,p_region_name=>'dropdown_menu'
,p_region_template_options=>'#DEFAULT#:apex-tooltip-bottom:i-h640:t-Region-scrollBody'
,p_region_attributes=>'style="width:40%"'
,p_plug_template=>wwv_flow_imp.id(4878037266358980501)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_display_condition_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_plug_display_when_condition=>'1,5'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77158939251060962973)
,p_plug_name=>'Wrapper'
,p_parent_plug_id=>wwv_flow_imp.id(77158938826503962969)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77158939288236962974)
,p_plug_name=>'Social'
,p_parent_plug_id=>wwv_flow_imp.id(77158939251060962973)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79702038531292909750)
,p_plug_name=>'Social'
,p_parent_plug_id=>wwv_flow_imp.id(77158939288236962974)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>10
,p_location=>null
,p_list_id=>wwv_flow_imp.id(4877173243050972503)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(44130349955382020598)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79702038636891909751)
,p_plug_name=>'Wrapper 2'
,p_region_name=>'MediaListWrapper'
,p_parent_plug_id=>wwv_flow_imp.id(77158939251060962973)
,p_region_template_options=>'#DEFAULT#:i-h640:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77158938993129962971)
,p_plug_name=>'Charts'
,p_parent_plug_id=>wwv_flow_imp.id(79702038636891909751)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>20
,p_location=>null
,p_list_id=>wwv_flow_imp.id(6481187822013882042)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(44130349955382020598)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77158939118197962972)
,p_plug_name=>'Comments'
,p_parent_plug_id=>wwv_flow_imp.id(79702038636891909751)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>40
,p_location=>null
,p_list_id=>wwv_flow_imp.id(4878003474893976349)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(44130349955382020598)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79702038459893909749)
,p_plug_name=>'Other Good Stuff'
,p_parent_plug_id=>wwv_flow_imp.id(79702038636891909751)
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>50
,p_location=>null
,p_list_id=>wwv_flow_imp.id(4877980663999974000)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(44130349955382020598)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4876871072318954349)
,p_button_sequence=>10
,p_button_name=>'DROPDOWN_MENU'
,p_button_static_id=>'dropdown_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(44130366222019020605)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Dropdown Menu'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'1,5'
,p_button_condition_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_icon_css_classes=>'fa-tiles-3x3'
,p_button_cattributes=>'dropdown-menu="dropdown_menu"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79702039664869909755)
,p_name=>'P0_SEARCHMENU'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77158938826503962969)
,p_prompt=>'Search Menu'
,p_placeholder=>'Search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(44130364156742020604)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:margin-left-sm'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4876863739401950789)
,p_name=>'Search text'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P0_SEARCHMENU'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4876863354315950789)
,p_event_id=>wwv_flow_imp.id(4876863739401950789)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#MediaListWrapper'').find(''.t-MediaList-item'').each(function() {',
'        const listItemText = $(this).text().toLowerCase();',
'        const searchQuery = apex.item(''P0_SEARCHMENU'').getValue().toLowerCase();',
'        if (listItemText.includes(searchQuery)) {',
'          $(this).show(); // Show the list item if it matches the search',
'        } else {',
'          $(this).hide(); // Hide the list item if it doesn''t match the search',
'        }',
'      }); '))
);
wwv_flow_imp.component_end;
end;
/
