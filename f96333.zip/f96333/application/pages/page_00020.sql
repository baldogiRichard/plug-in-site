prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Heatmap Charts'
,p_alias=>'HEATMAP-CHARTS'
,p_step_title=>'Heatmap Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(192780867948351321302)
,p_plug_name=>'Heatmap Charts'
,p_icon_css_classes=>'fa-heat-map'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a Heatmap Chart?',
'<br>',
'<br>',
'A heat map (or heatmap) is a data visualization technique that shows magnitude of a phenomenon as color in two dimensions. The variation in color may be by hue or intensity, giving obvious visual cues to the reader about how the phenomenon is cluster'
||'ed or varies over space. There are two fundamentally different categories of heat maps: the cluster heat map and the spatial heat map. In a cluster heat map, magnitudes are laid out into a matrix of fixed cell size whose rows and columns are discrete'
||' phenomena and categories, and the sorting of rows and columns is intentional and somewhat arbitrary, with the goal of suggesting clusters or portraying them as discovered via statistical analysis. The size of the cell is arbitrary but large enough t'
||'o be clearly visible. By contrast, the position of a magnitude in a spatial heat map is forced by the location of the magnitude in that space, and there is no notion of cells; the phenomenon is considered to vary continuously.',
'<br>',
'<br>',
'Source: <a href="https://en.wikipedia.org/wiki/Heat_map">https://en.wikipedia.org/wiki/Heat_map</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198238912055012545297)
,p_plug_name=>'Heatmap Charts'
,p_icon_css_classes=>'fa-bubble-chart'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1870013978611207759)
,p_plug_name=>'Heatmap Charts with color range'
,p_parent_plug_id=>wwv_flow_imp.id(198238912055012545297)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.*',
'from( select upper(WEEK) as week,',
'       VALUE,',
'       METRIC,',
'       to_number(replace(week,''w'')) as no_of_week,',
'       to_number(replace(metric,''Metric'')) as no_of_metric',
'      from APEXCHARTS_HEATMAP_BASIC_COLORRANGE) t',
'order by no_of_metric, no_of_week'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'',
'    config.plotOptions = {',
'        heatmap: {',
'            shadeIntensity: 0.5,',
'            radius: 0,',
'            useFillColorAsStroke: true,',
'            colorScale: {',
'                ranges: [{',
'                    from: -30,',
'                    to: 5,',
'                    name: ''low'',',
'                    color: ''#00A100''',
'                },',
'                {',
'                    from: 6,',
'                    to: 20,',
'                    name: ''medium'',',
'                    color: ''#128FD9''',
'                },',
'                {',
'                    from: 21,',
'                    to: 45,',
'                    name: ''high'',',
'                    color: ''#FFB200''',
'                },',
'                {',
'                    from: 46,',
'                    to: 100,',
'                    name: ''extreme'',',
'                    color: ''#FF0000''',
'                }',
'                ]',
'            }',
'        }',
'    }',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'heatmap',
  'attribute_02', 'heatmap_chart_2',
  'attribute_03', 'Heatmap Charts with color range',
  'attribute_04', '800',
  'attribute_05', '550',
  'attribute_07', 'WEEK',
  'attribute_08', 'VALUE',
  'attribute_13', 'METRIC',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870013908758207758)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>10
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870013761812207757)
,p_name=>'WEEK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870013689543207756)
,p_name=>'METRIC'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870013560704207755)
,p_name=>'NO_OF_WEEK'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870013511727207754)
,p_name=>'NO_OF_METRIC'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198238912164997545298)
,p_plug_name=>'Heatmap Charts'
,p_parent_plug_id=>wwv_flow_imp.id(198238912055012545297)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.*',
'from( select upper(WEEK) as week,',
'       VALUE,',
'       METRIC,',
'       to_number(replace(week,''w'')) as no_of_week,',
'       to_number(replace(metric,''Metric'')) as no_of_metric',
'      from APEXCHARTS_HEATMAP_BASIC_COLORRANGE) t',
'order by no_of_metric, no_of_week'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'heatmap',
  'attribute_02', 'heatmap_chart_1',
  'attribute_03', 'Heatmap Charts Basic',
  'attribute_04', '800',
  'attribute_05', '550',
  'attribute_07', 'WEEK',
  'attribute_08', 'VALUE',
  'attribute_13', 'METRIC',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870015114557207770)
,p_name=>'WEEK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014974841207769)
,p_name=>'METRIC'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014250456207761)
,p_name=>'NO_OF_WEEK'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>160
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014068023207760)
,p_name=>'NO_OF_METRIC'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90106061216198476518)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
