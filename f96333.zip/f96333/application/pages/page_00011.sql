prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Timeline Charts'
,p_alias=>'TIMELINE-CHARTS'
,p_step_title=>'Timeline Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_created_on=>wwv_flow_imp.dz('20230108230204Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221120211505Z')
,p_last_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(52486159047543383821)
,p_plug_name=>'Timeline Charts'
,p_icon_css_classes=>'fa-braille'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a timeline chart?',
'<br>',
'<br>',
'Timeline charts are highly versatile visual charts that are used to illustrate a set of events chronologically. They''re an excellent tool for conceptualizing event sequences or processes to gain insights into the nuances of a project. That could incl'
||'ude summarizing historical events, or any other time frame where you need to measure minutes, hours, dates, or years.',
'<br>',
'<br>',
'Source: <a href="https://www.mindmanager.com/en/features/timeline-chart/">https://www.mindmanager.com/en/features/timeline-chart/</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57944203154204607816)
,p_plug_name=>'Timeline Charts'
,p_icon_css_classes=>'fa-table-clock'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5068533045018885267)
,p_plug_name=>'Timeline Chart Multiple Ranges'
,p_parent_plug_id=>wwv_flow_imp.id(57944203154204607816)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       CATEGORY,',
'       to_date(MINIMUM_DATE) as MINIMUM_DATE,',
'       to_date(MAXIMUM_DATE) as MAXIMUM_DATE,',
'       ''rangeBar'' as CHARTTYPE',
'  from APEXCHARTS_TIMELINE_MULTIPLERANGES'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config){',
'',
'    config.xaxis = {',
'        labels: {',
'            formatter: function (value) {',
'                return moment(value).format(''YYYY.MM.DD'');',
'            }, ',
'        }',
'    }',
'',
'    config.tooltip = {',
'       custom: function(opts) {',
'           if (typeof(opts) != "undefined") {',
'               ',
'                var dt1 = moment(opts.y1).format(''YYYY.MM.DD''); ',
'                var dt2 = moment(opts.y2).format(''YYYY.MM.DD''); ',
'',
'                return (''<div>'' + "<b>" + opts.w.globals.labels[opts.dataPointIndex] + ": " +',
'                        "</b><span>" + dt1 + '' - '' + dt2 + "</span></div>"',
'                );',
'           }',
'        }',
'    }',
'       ',
'    config.dataLabels = {enabled: false};',
'    ',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'combo',
  'attribute_02', 'timeline_chart_2',
  'attribute_03', 'Timeline Chart Multiple Ranges',
  'attribute_04', '700',
  'attribute_05', '500',
  'attribute_07', 'CATEGORY',
  'attribute_08', 'ID',
  'attribute_09', 'MINIMUM_DATE,MAXIMUM_DATE',
  'attribute_12', 'CHARTTYPE',
  'attribute_13', 'NAME',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532910840885266)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532826451885265)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532714227885264)
,p_name=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532559954885263)
,p_name=>'MINIMUM_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532530765885262)
,p_name=>'MAXIMUM_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532419086885261)
,p_name=>'CHARTTYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1870014944710207768)
,p_plug_name=>'Timeline Chart Group Rows'
,p_parent_plug_id=>wwv_flow_imp.id(57944203154204607816)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       CATEGORY,',
'       to_date(MINIMUM,''YYYY.MM.DD'') as MINIMUM_DATE,',
'       to_date(MAXIMUM,''YYYY.MM.DD'') as MAXIMUM_DATE,',
'       ''rangeBar'' as CHARTTYPE',
'  from APEXCHARTS_TIMELINE_MULTIPLESERIES'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config){',
'',
'    config.xaxis = {',
'        labels: {',
'            formatter: function (value) {',
'                return moment(value).format(''YYYY.MM.DD'');',
'            }, ',
'        }',
'    }',
'',
'    config.tooltip = {',
'       custom: function(opts) {',
'           if (typeof(opts) != "undefined") {',
'               ',
'                var dt1 = moment(opts.y1).format(''YYYY.MM.DD''); ',
'                var dt2 = moment(opts.y2).format(''YYYY.MM.DD''); ',
'',
'                return (''<div>'' + "<b>" + opts.w.globals.labels[opts.dataPointIndex] + ": " +',
'                        "</b><span>" + dt1 + '' - '' + dt2 + "</span></div>"',
'                );',
'           }',
'        }',
'    }',
'       ',
'    config.dataLabels = {enabled: false};',
'',
'    config.plotOptions = {',
'        bar: {',
'            horizontal: true,',
'            barHeight: ''50%'',',
'            rangeBarGroupRows: true',
'        }',
'    }',
'',
'    config.xaxis = {type: ''datetime''}',
'',
'    config.legend = {position: ''right''}',
'    ',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'combo',
  'attribute_02', 'timeline_chart_3',
  'attribute_03', 'Timeline Chart Group Rows',
  'attribute_04', '700',
  'attribute_05', '500',
  'attribute_07', 'CATEGORY',
  'attribute_08', 'ID',
  'attribute_09', 'MINIMUM_DATE,MAXIMUM_DATE',
  'attribute_12', 'CHARTTYPE',
  'attribute_13', 'NAME',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N',
  'attribute_18', 'x')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014820664207767)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014675497207766)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014569134207765)
,p_name=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014501289207764)
,p_name=>'MINIMUM_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014415703207763)
,p_name=>'MAXIMUM_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1870014344573207762)
,p_name=>'CHARTTYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57944203264189607817)
,p_plug_name=>'Timeline Chart Basic'
,p_parent_plug_id=>wwv_flow_imp.id(57944203154204607816)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       CATEGORY,',
'       to_date(MINIMUM_DATE) as MINIMUM_DATE,',
'       to_date(MAXIMUM_DATE) as MAXIMUM_DATE',
'  from APEXCHARTS_TIMELINE_MULTIPLERANGES',
'  where name = ''Joe'''))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config){',
'',
'    config.xaxis = {',
'        labels: {',
'            formatter: function (value) {',
'                return moment(value).format(''YYYY.MM.DD'');',
'            }, ',
'        }',
'    }',
'',
'    config.tooltip = {',
'       custom: function(opts) {',
'           if (typeof(opts) != "undefined") {',
'               ',
'                var dt1 = moment(opts.y1).format(''YYYY.MM.DD''); ',
'                var dt2 = moment(opts.y2).format(''YYYY.MM.DD''); ',
'',
'                return (''<div>'' + "<b>" + opts.w.globals.labels[opts.dataPointIndex] + ": " +',
'                        "</b><span>" + dt1 + '' - '' + dt2 + "</span></div>"',
'                );',
'           }',
'        }',
'    }',
'       ',
'    config.dataLabels = {enabled: false};',
'    ',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'rangeBar',
  'attribute_02', 'timeline_chart_1',
  'attribute_03', 'Timeline Chart Basic',
  'attribute_04', '700',
  'attribute_05', '350',
  'attribute_07', 'CATEGORY',
  'attribute_09', 'MINIMUM_DATE,MAXIMUM_DATE',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068533357381885271)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>50
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068533329303885270)
,p_name=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068533248304885269)
,p_name=>'MINIMUM_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068533070593885268)
,p_name=>'MAXIMUM_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(33269692101273629214)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
