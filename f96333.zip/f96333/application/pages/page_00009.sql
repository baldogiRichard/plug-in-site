prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Mixed Charts'
,p_alias=>'MIXED-CHARTS'
,p_step_title=>'Mixed Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_created_on=>wwv_flow_imp.dz('20230108230203Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221120211445Z')
,p_last_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25640745628496059662)
,p_plug_name=>'Mixed Charts'
,p_icon_css_classes=>'fa-braille'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a Mixed Chart?',
'<br>',
'<br>',
'The mixed chart is a visualization that combines the features of the bar chart and the line chart. The mixed chart displays the data using a number of bars and/or lines, each of which represent a particular category. A combination of bars and lines i'
||'n the same visualization can be useful when comparing values in different categories, since the combination gives a clear view of which category is higher or lower. An example of this can be seen when using the mixed chart to compare the projected sa'
||'les with the actual sales for different time periods.',
'<br>',
'<br>',
'Source: <a href="https://docs.tibco.com/pub/spotfire/7.0.1/doc/html/comb/comb_what_is_a_combination_chart_.htm">https://docs.tibco.com/pub/spotfire/7.0.1/doc/html/comb/comb_what_is_a_combination_chart_.htm</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31098789735157283657)
,p_plug_name=>'Mixed Charts'
,p_icon_css_classes=>'fa-combo-chart'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6513336569311598346)
,p_plug_name=>'Multiple Y Axis Chart'
,p_parent_plug_id=>wwv_flow_imp.id(31098789735157283657)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       QUARTER_YEAR,',
'       VALUE,',
'       CATEGORY,',
'       case when category = ''Product A'' ',
'              then ''column''',
'            when category = ''Product B''',
'              then ''column''',
'            when category = ''Product C''',
'              then ''line''',
'       end as CHARTTYPE',
'  from APEXCHART_COLUMNS_STACKED'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'',
'    config.fill = {opacity: [1,1,1]};',
'    ',
'    config.yaxis = [',
'                {',
'                axisTicks: {',
'                show: true,',
'                },',
'                axisBorder: {',
'                show: true,',
'                color: ''#008FFB''',
'                },',
'                labels: {',
'                style: {',
'                    colors: ''#008FFB'',',
'                }',
'                },',
'                title: {',
'                text: "Product B",',
'                style: {',
'                    color: ''#008FFB'',',
'                }',
'                },',
'                tooltip: {',
'                enabled: true',
'                }',
'            },',
'            {',
'                seriesName: ''Income'',',
'                opposite: true,',
'                axisTicks: {',
'                show: true,',
'                },',
'                axisBorder: {',
'                show: true,',
'                color: ''#00E396''',
'                },',
'                labels: {',
'                style: {',
'                    colors: ''#00E396'',',
'                }',
'                },',
'                title: {',
'                text: "Product C",',
'                style: {',
'                    color: ''#00E396'',',
'                }',
'                },',
'            },',
'            {',
'                seriesName: ''Revenue'',',
'                opposite: true,',
'                axisTicks: {',
'                show: true,',
'                },',
'                axisBorder: {',
'                show: true,',
'                color: ''#FEB019''',
'                },',
'                labels: {',
'                style: {',
'                    colors: ''#FEB019'',',
'                },',
'                },',
'                title: {',
'                text: "Product A",',
'                style: {',
'                    color: ''#FEB019'',',
'                }',
'                }',
'            },',
'    ];',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'combo',
  'attribute_02', 'mixed_chart_2',
  'attribute_03', 'Multiple Y Axis Chart',
  'attribute_04', '500',
  'attribute_05', '350',
  'attribute_07', 'QUARTER_YEAR',
  'attribute_08', 'VALUE',
  'attribute_12', 'CHARTTYPE',
  'attribute_13', 'CATEGORY',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513336462487598345)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>10
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513336404292598344)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>20
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513336347711598343)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513336224036598342)
,p_name=>'QUARTER_YEAR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513336119945598341)
,p_name=>'CHARTTYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31098789845142283658)
,p_plug_name=>'Line Column Area Chart'
,p_parent_plug_id=>wwv_flow_imp.id(31098789735157283657)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       QUARTER_YEAR,',
'       VALUE,',
'       CATEGORY,',
'       case when category = ''Product A'' ',
'              then ''column''',
'            when category = ''Product B''',
'              then ''area''',
'            when category = ''Product C''',
'              then ''line''',
'       end as CHARTTYPE',
'  from APEXCHART_COLUMNS_STACKED'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'    ',
'    config.fill =  {',
'        opacity: [1, 1, 0.5],',
'        gradient: {',
'            inverseColors: false,',
'            shade: ''light'',',
'            type: "vertical",',
'            opacityFrom: 0.85,',
'            opacityTo: 0.55,',
'            stops: [0, 100, 100, 100]',
'        }',
'    };',
'',
'    config.stroke = {curve: ''smooth''};',
'',
'    config.plotOptions = {',
'        bar: {columnWidth: ''50%''}',
'    };',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'combo',
  'attribute_02', 'mixed_chart_1',
  'attribute_03', 'Line Column Area Chart',
  'attribute_04', '500',
  'attribute_05', '350',
  'attribute_07', 'QUARTER_YEAR',
  'attribute_08', 'VALUE',
  'attribute_12', 'CHARTTYPE',
  'attribute_13', 'CATEGORY',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513336767510598348)
,p_name=>'QUARTER_YEAR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513336685771598347)
,p_name=>'CHARTTYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6424278682226305055)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(31098789968865283659)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>10
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(31098790219084283661)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
