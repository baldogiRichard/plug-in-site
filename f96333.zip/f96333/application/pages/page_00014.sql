prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Pie / Donut Charts'
,p_alias=>'PIE-DONUT-CHARTS'
,p_step_title=>'Pie / Donut Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_created_on=>wwv_flow_imp.dz('20230108230204Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221120211535Z')
,p_last_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(97606278008421959560)
,p_plug_name=>'Pie / Donut Charts'
,p_icon_css_classes=>'fa-braille'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a Pie / Donut Chart?',
'<br>',
'<br>',
unistr('A pie chart is a graphical representation technique that displays data in a circular-shaped graph. It is a composite static chart that works best with few variables. Pie charts are often used to represent sample data\2014with data points belonging to a c')
||unistr('ombination of different categories. Each of these categories is represented as a \201Cslice of the pie.\201D The size of each slice is directly proportional to the number of data points that belong to a particular category.'),
'<br>',
'<br>',
'A donut chart, in its simplest form, is a pie chart with its center cut out to look like a donut. At first glance, this may not seem to serve a much greater purpose than to create aesthetic variety. However, a donut chart helps avoid confusion around'
||' the area parameter that often trips people up in a pie chart.',
'<br>',
'<br>',
'Source: <a href="https://www.tibco.com/reference-center/what-is-a-pie-chart">https://www.tibco.com/reference-center/what-is-a-pie-chart</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(103064322115083183555)
,p_plug_name=>'Pie / Donut Charts'
,p_icon_css_classes=>'fa-pie-chart'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5068528589840885223)
,p_plug_name=>'Donut Charts Basic'
,p_parent_plug_id=>wwv_flow_imp.id(103064322115083183555)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       VALUE,',
'       CATEGORY',
'  from APEXCHARTS_PIEDONUT'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'donut',
  'attribute_02', 'donut_chart_1',
  'attribute_03', 'Donut Charts Basic',
  'attribute_04', '500',
  'attribute_05', '400',
  'attribute_06', 'CATEGORY',
  'attribute_08', 'VALUE',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068528530679885222)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575087321220944971)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575087157830944970)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3575087076731944969)
,p_plug_name=>'Donut Charts Semi'
,p_parent_plug_id=>wwv_flow_imp.id(103064322115083183555)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       VALUE,',
'       CATEGORY',
'  from APEXCHARTS_PIEDONUT'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'    ',
'    config.plotOptions = {',
'        pie: {',
'            startAngle: -90,',
'            endAngle: 90,',
'            offsetY: 10',
'        }',
'    },',
'',
'    config.grid = {padding: {bottom: -80}}',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'donut',
  'attribute_02', 'donut_chart_2',
  'attribute_03', 'Donut Charts Semi',
  'attribute_04', '500',
  'attribute_05', '400',
  'attribute_06', 'CATEGORY',
  'attribute_08', 'VALUE',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575087014733944968)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575086925695944967)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575086838355944966)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3575086676105944965)
,p_plug_name=>'Pie Charts Monochrome'
,p_parent_plug_id=>wwv_flow_imp.id(103064322115083183555)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       VALUE,',
'       CATEGORY',
'  from APEXCHARTS_PIEDONUT'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'    ',
'    config.theme = {monochrome: {enabled: true}}',
'    ',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'pie',
  'attribute_02', 'pie_chart_2',
  'attribute_03', 'Pie Charts Monochrome',
  'attribute_04', '500',
  'attribute_05', '400',
  'attribute_06', 'CATEGORY',
  'attribute_08', 'VALUE',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575086634525944964)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575086472902944963)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575086413555944962)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(103064322225068183556)
,p_plug_name=>'Pie Charts Basic'
,p_parent_plug_id=>wwv_flow_imp.id(103064322115083183555)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       VALUE,',
'       CATEGORY',
'  from APEXCHARTS_PIEDONUT'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'pie',
  'attribute_02', 'pie_chart_1',
  'attribute_03', 'Pie Charts Basic',
  'attribute_04', '500',
  'attribute_05', '400',
  'attribute_06', 'CATEGORY',
  'attribute_08', 'VALUE',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068528816900885225)
,p_name=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>false
,p_display_sequence=>110
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068528723730885224)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(25284341115806865639)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
