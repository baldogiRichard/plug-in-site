prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Comments'
,p_alias=>'COMMENTS'
,p_step_title=>'Comments'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.github-icon-setting {',
'    background-image: ''#APP_FILES#icons/github-logo.png'';',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_cache_mode=>'CACHE'
,p_cache_timeout_seconds=>600
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(144653860270030080)
,p_plug_name=>'APEX Comments'
,p_icon_css_classes=>'fa-braille'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'This plug-in helps to build a comment region to application express developers.',
'<br>',
'<ul>',
'    <li>This demo uses a modified script.js file due to table manipulation.</li>',
'    <li>In order to get the proper javascript file please visit the Github site of APEX Comments.</li>',
'    <li>When the application is being installed the content of the blob colum (PP_URL) in table APEX_COMMENTS_USERS will be lost.</li>',
'</ul>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53617313089041999884)
,p_plug_name=>'Plug-in Comments'
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24831236515837396185)
,p_plug_name=>'Application Process Code'
,p_parent_plug_id=>wwv_flow_imp.id(53617313089041999884)
,p_icon_css_classes=>'fa-code'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(44129734770206020552)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'<div>When an image is retrieved from a BLOB column then it is advised to define/use an Application Process which can display the profile picture(s) for/of the user.</div>',
'<br>',
'<div><a href="https://joelkallman.blogspot.com/2014/03/yet-another-post-how-to-link-to.html">Please note the following when calling an application process from an URL:</a></div>',
'<br>',
'<div>Be careful how this is used. If you don''t implement some form of browser caching, then a report which displays 500 images inline on a page will result in 500 requests to the APEX engine and database, per user per page view! Ouch! And then it''s a'
||' matter of time before a DBA starts hunting for the person slamming their database and reports that "APEX is killing our database". There is an excellent explanation of cache headers here.</div>',
'<br>',
'<!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><pre style="margin: 0; line-height: 125%"><span style="color: #0000ff">begin</span'
||'>',
'    <span style="color: #0000ff">for</span> c1 <span style="color: #0000ff">in</span> (<span style="color: #0000ff">select</span> *',
'                 <span style="color: #0000ff">from</span> apex_comments_users',
'                <span style="color: #0000ff">where</span> empno = :FILE_ID) loop',
'        <span style="color: #008000">--</span>',
'        sys.htp.init;',
'        sys.owa_util.mime_header( c1.profile_picture_mimetype, <span style="color: #0000ff">FALSE</span> );',
'        sys.htp.p(<span style="color: #a31515">&#39;Content-length: &#39;</span> || sys.dbms_lob.getlength( c1.profile_picture));',
'        sys.htp.p(<span style="color: #a31515">&#39;Content-Disposition: attachment; filename=&quot;&#39;</span> || c1.profile_picture_filename || <span style="color: #a31515">&#39;&quot;&#39;</span> );',
'        sys.htp.p(<span style="color: #a31515">&#39;Cache-Control: max-age=3600&#39;</span>);  <span style="color: #008000">-- tell the browser to cache for one hour, adjust as necessary</span>',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.download_file( c1.profile_picture );',
'     ',
'        apex_application.stop_apex_engine;',
'    <span style="color: #0000ff">end</span> loop;',
'<span style="color: #0000ff">end</span>;',
'</pre></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36269025947340373281)
,p_plug_name=>'Source Table Structure'
,p_parent_plug_id=>wwv_flow_imp.id(53617313089041999884)
,p_icon_css_classes=>'fa-database-plus'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(44129734770206020552)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'<div>A basic structure for a table where the comments will be stored.</div>',
'<br>',
'<!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><pre style="margin: 0; line-height: 125%">  <span style="color: #0000ff">CREATE</s'
||'pan> <span style="color: #0000ff">TABLE</span> <span style="color: #a31515">&quot;APEX_COMMENTS&quot;</span> ',
'   (	<span style="color: #a31515">&quot;ID_COLUMN&quot;</span> VARCHAR2(2000), ',
'	<span style="color: #a31515">&quot;PARENT_ID&quot;</span> VARCHAR2(2000), ',
'	<span style="color: #a31515">&quot;CONTENT_STR&quot;</span> <span style="color: #0000ff">CLOB</span>, ',
'	<span style="color: #a31515">&quot;CREATED&quot;</span> DATE, ',
'	<span style="color: #a31515">&quot;MODIFIED&quot;</span> DATE, ',
'	<span style="color: #a31515">&quot;CREATED_BY&quot;</span> VARCHAR2(2000), ',
'	<span style="color: #a31515">&quot;PROF_PIC_URL&quot;</span> VARCHAR2(2000), ',
'	<span style="color: #a31515">&quot;FILTER_COL&quot;</span> NUMBER, ',
'	<span style="color: #a31515">&quot;USER_ID&quot;</span> NUMBER',
'   ) ;',
'</pre></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36269026015697373282)
,p_plug_name=>'Plug-in Query'
,p_parent_plug_id=>wwv_flow_imp.id(53617313089041999884)
,p_icon_css_classes=>'fa-database-arrow-down'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(44129734770206020552)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'<div>This query example will return the comments from the table where it''s stored.</div>',
'<br>',
'<!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><pre style="margin: 0; line-height: 125%"><span style="color: #0000ff">select</spa'
||'n>   ID_COLUMN      <span style="color: #0000ff">as</span> comment_id',
'       , PARENT_ID      <span style="color: #0000ff">as</span> reply_id',
'       , CONTENT_STR    <span style="color: #0000ff">as</span> comment_text',
'       , CREATED        <span style="color: #0000ff">as</span> created_date',
'       , MODIFIED       <span style="color: #0000ff">as</span> modified_date',
'       , CREATED_BY     <span style="color: #0000ff">as</span> username',
'       , <span style="color: #0000ff">case</span> <span style="color: #0000ff">when</span> prof_pic_url <span style="color: #0000ff">is</span> <span style="color: #0000ff">null</span>',
'                <span style="color: #0000ff">then</span> <span style="color: #0000ff">null</span>',
'              <span style="color: #0000ff">else</span> ',
'                <span style="color: #a31515">&#39;f?p=&amp;APP_ID.:&amp;APP_PAGE_ID.:&amp;APP_SESSION.:APPLICATION_PROCESS=GETIMAGE:::FILE_ID:&#39;</span> || PROF_PIC_URL',
'         <span style="color: #0000ff">end</span> <span style="color: #0000ff">as</span> prof_pic_url_display',
'       , <span style="color: #0000ff">case</span> <span style="color: #0000ff">when</span> CREATED &lt; sysdate - 2',
'              <span style="color: #0000ff">then</span> 1',
'              <span style="color: #0000ff">else</span> 0',
'         <span style="color: #0000ff">end</span> <span style="color: #0000ff">as</span> new_comment',
'       , PROF_PIC_URL <span style="color: #0000ff">as</span> prof_pic_url_save',
'<span style="color: #0000ff">from</span> apex_comments',
'</pre></div>',
'',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36269026060421373283)
,p_plug_name=>'Pinging List Query'
,p_parent_plug_id=>wwv_flow_imp.id(53617313089041999884)
,p_icon_css_classes=>'fa-database-arrow-down'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(44129734770206020552)
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'<div>Users can be listed and tagged in the textarea section by defining a query in the Pinging List attribute.</div>',
'<br>',
'<!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><pre style="margin: 0; line-height: 125%"><span style="color: #0000ff">select</spa'
||'n>   empno                                  <span style="color: #0000ff">as</span> ID ',
'       , ename                                  <span style="color: #0000ff">as</span> USERNAME',
'       , ename || <span style="color: #a31515">&#39; &#39;</span> || job                    <span style="color: #0000ff">as</span> NAME ',
'       , ename || <span style="color: #a31515">&#39;.&#39;</span> || job || <span style="color: #a31515">&#39;@company.com&#39;</span>  <span style="color: #0000ff">as</span> EMAIL',
'       , <span style="color: #a31515">&#39;f?p=&amp;APP_ID.:&amp;APP_PAGE_ID.:&amp;APP_SESSION.:APPLICATION_PROCESS=GETIMAGE:::FILE_ID:&#39;</span> || empno <span style="color: #0000ff">as</span> PROFILE_PICTURE_URL',
'<span style="color: #0000ff">from</span> apex_comments_users;',
'</pre></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36269026183609373284)
,p_plug_name=>'JavaScript Initialization Code'
,p_parent_plug_id=>wwv_flow_imp.id(53617313089041999884)
,p_icon_css_classes=>'fa-file-code-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(44129734770206020552)
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br>',
'<div>A basic customisation for the Comments Region. More option can be found at <a href="https://viima.github.io/jquery-comments/#link-4">Viima Jquery Comments Configuration</a>.</div>',
'<br>',
'<!-- HTML generated using hilite.me --><div style="background: #ffffff; overflow:auto;width:auto;border:solid gray;border-width:.1em .1em .1em .8em;padding:.2em .6em;"><pre style="margin: 0; line-height: 125%"><span style="color: #0000ff">function</s'
||'pan>(config){',
'    ',
'    config.profilePictureURL = <span style="color: #a31515">&#39;f?p=&amp;APP_ID.:&amp;APP_PAGE_ID.:&amp;APP_SESSION.:APPLICATION_PROCESS=GETIMAGE:::FILE_ID:&#39;</span> + apex.item(<span style="color: #a31515">&#39;P3_PPURL_ID&#39;</span>).getValue('
||');',
'    config.enableHashtags = <span style="color: #0000ff">true</span>;',
'    config.roundProfilePictures = <span style="color: #0000ff">true</span>;',
'    config.timeFormatter = <span style="color: #0000ff">function</span>(time) {',
'    <span style="color: #0000ff">return</span> moment(time).format(<span style="color: #a31515">&#39;MMMM Do YYYY, h:mm:ss a&#39;</span>);',
'    };',
'',
'    <span style="color: #0000ff">return</span> config;',
'}',
'</pre></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41399840461220709016)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(53617313089041999884)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   ID_COLUMN      as comment_id',
'       , PARENT_ID      as reply_id',
'       , CONTENT_STR    as comment_text',
'       , CREATED        as created_date',
'       , MODIFIED       as modified_date',
'       , CREATED_BY     as username',
'       , case when prof_pic_url is null',
'                then null',
'              else ',
'                ''f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.:APPLICATION_PROCESS=GETIMAGE:::FILE_ID:'' || PROF_PIC_URL',
'         end as prof_pic_url_display',
'       , case when CREATED < sysdate - 2',
'              then 1',
'              else 0',
'         end as new_comment',
'       , PROF_PIC_URL as prof_pic_url_save',
'from APEX_COMMENTS'))
,p_plug_source_type=>'PLUGIN_COM.COMMENTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config){',
'    ',
'    config.profilePictureURL = ''f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.:APPLICATION_PROCESS=GETIMAGE:::FILE_ID:'' + apex.item(''P2_PPURL_ID'').getValue();',
'    config.enableHashtags = true;',
'    config.roundProfilePictures = true;',
'    config.timeFormatter = function(time) {',
'    return moment(time).format(''MMMM Do YYYY, h:mm:ss a'');',
'    };',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'COMMENT_ID',
  'attribute_02', 'REPLY_ID',
  'attribute_03', 'CREATED_DATE',
  'attribute_04', 'MODIFIED_DATE',
  'attribute_05', 'COMMENT_TEXT',
  'attribute_07', 'USERNAME',
  'attribute_08', 'PROF_PIC_URL_DISPLAY',
  'attribute_11', 'NEW_COMMENT',
  'attribute_14', 'ENABLE',
  'attribute_15', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select   empno                                  as ID ',
    '       , ename                                  as USERNAME',
    '       , ename || '' '' || job                    as NAME ',
    '       , ename || ''.'' || job || ''@company.com''  as EMAIL',
    '       , ''f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.:APPLICATION_PROCESS=GETIMAGE:::FILE_ID:'' || empno as PROFILE_PICTURE_URL',
    'from apex_comments_users;')),
  'attribute_18', 'ENABLE',
  'attribute_19', 'ENABLE',
  'attribute_20', 'ENABLE',
  'attribute_21', 'P2_USERNAME',
  'attribute_22', 'P2_PPURL_ID',
  'attribute_23', 'PROF_PIC_URL_SAVE')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24831236240807396182)
,p_name=>'PROF_PIC_URL_DISPLAY'
,p_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24831236089267396181)
,p_name=>'PROF_PIC_URL_SAVE'
,p_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(41399840631583709017)
,p_name=>'COMMENT_ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(41399840671456709018)
,p_name=>'REPLY_ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(53618347866090053769)
,p_name=>'COMMENT_TEXT'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(53618348016364053770)
,p_name=>'CREATED_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(53618348131626053771)
,p_name=>'MODIFIED_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(53618348169345053772)
,p_name=>'USERNAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(53618348435509053774)
,p_name=>'NEW_COMMENT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6698087067297077627)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(144653860270030080)
,p_button_name=>'GITHUB'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(44130367022408020606)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Github'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'https://github.com/baldogiRichard/apex-comments'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-github'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24831236468684396184)
,p_name=>'P2_PPURL_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(144653860270030080)
,p_item_default=>'1245'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24831236320964396183)
,p_name=>'P2_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(144653860270030080)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ename || '' '' || job from apex_comments_users',
'where empno = :P2_PPURL_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
