prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Bubble Charts'
,p_alias=>'BUBBLE-CHARTS'
,p_step_title=>'Bubble Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(159290386678528855989)
,p_plug_name=>'Bubble Charts'
,p_icon_css_classes=>'fa-polar-chart'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a Bubble Chart?',
'<br>',
'<br>',
'A bubble chart is a data visualization that displays multiple circles (bubbles) in a two-dimensional plot. It is a generalization of the scatter plot, replacing the dots with bubbles. Most commonly, a bubble chart displays the values of three numeric'
||' variables, where each observation''s data is shown by a circle ("bubble"), while the horizontal and vertical positions of the bubble show the values of two other variables.',
'<br>',
'<br>',
'Source: <a href="https://www.displayr.com/what-is-a-bubble-chart/">https://www.displayr.com/what-is-a-bubble-chart/</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(164748430785190079984)
,p_plug_name=>'Bubble Charts'
,p_icon_css_classes=>'fa-bubble-chart'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(164748430895175079985)
,p_plug_name=>'Bubble Charts Basic'
,p_parent_plug_id=>wwv_flow_imp.id(164748430785190079984)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_date(DT,''MM.DD.YYYY'') as DT,',
'       VALUE,',
'       PRODUCT,',
'       round(B_SIZE,0) as B_SIZE',
'from APEXCHARTS_BUBBLE'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config){',
'',
'    config.xaxis = {',
'        labels: {',
'            formatter: function (value) {',
'                return moment(value).format(''YYYY.MM.DD'');',
'            }, ',
'        }',
'    }',
'       ',
'    config.dataLabels = {enabled: false};',
'',
'    config.yaxis = {min:5, max: 70};',
'    ',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'bubble',
  'attribute_02', 'bubble_chart_1',
  'attribute_03', 'Bubble Charts Basic',
  'attribute_04', '800',
  'attribute_05', '550',
  'attribute_07', 'PRODUCT',
  'attribute_08', 'DT',
  'attribute_09', 'VALUE,B_SIZE',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N',
  'attribute_18', 'x')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575083073097944929)
,p_name=>'PRODUCT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575082887897944927)
,p_name=>'DT'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3575082826561944926)
,p_name=>'B_SIZE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56615579946376011205)
,p_name=>'VALUE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
