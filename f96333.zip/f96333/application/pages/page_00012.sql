prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Candlestick Charts'
,p_alias=>'CANDLESTICK-CHARTS'
,p_step_title=>'Candlestick Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(67253405272242208668)
,p_plug_name=>'Candlestick Charts'
,p_icon_css_classes=>'fa-braille'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What is a Candlestick Chart?',
'<br>',
'<br>',
'A candlestick chart is a financial chart that typically shows price movements of currency, securities, or derivatives. It looks like a candlestick with a vertical rectangle and a wick at the top and bottom. The top and bottom of the candlestick show '
||'open and closed prices. The top of the wick shows the high price, and the bottom of the wick shows the low price.',
'<br>',
'<br>',
'Source: <a href="https://www.tibco.com/reference-center/what-is-a-candlestick-chart">https://www.tibco.com/reference-center/what-is-a-candlestick-chart</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(72711449378903432663)
,p_plug_name=>'Candlestick Charts'
,p_icon_css_classes=>'fa-stock-chart'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(72711449488888432664)
,p_plug_name=>'Candlestick Chart Basic'
,p_parent_plug_id=>wwv_flow_imp.id(72711449378903432663)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CATEGORY,',
'       OPEN,',
'       HIGH,',
'       LOW,',
'       CLOSE',
'  from APEXCHARTS_CANDLESTICK_BASIC',
'  order by category'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'',
'    config.yaxis = {tooltip: {enabled: true}};',
'    ',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'candlestick',
  'attribute_02', 'candlestick_chart_1',
  'attribute_03', 'Candlestick Chart Basic',
  'attribute_04', '700',
  'attribute_05', '400',
  'attribute_07', 'CATEGORY',
  'attribute_09', 'OPEN,HIGH,LOW,CLOSE',
  'attribute_14', 'DOWNLOAD:SELECTION:ZOOM:PAN:RESET',
  'attribute_15', 'N',
  'attribute_18', 'x')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532336518885260)
,p_name=>'OPEN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532191611885259)
,p_name=>'HIGH'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068532092237885258)
,p_name=>'LOW'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068531964567885257)
,p_name=>'CLOSE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(5068531620372885253)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
