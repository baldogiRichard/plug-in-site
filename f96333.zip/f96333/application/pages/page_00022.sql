prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>22
,p_name=>'JSON Crack - Viewer'
,p_alias=>'JSON-CRACK-VIEWER'
,p_step_title=>'JSON Crack - Viewer'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.t-Body-main'').removeClass(''t-Body-main'');',
'$(''#t_Body_content'').removeClass(''t-Body-content'');',
'$(''#main'').removeClass(''t-Body-mainContent'');',
'$(''.t-Body-contentInner'').removeClass(''t-Body-contentInner'');',
'$(''#t_PageBody'').width("100%");'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-contentInner {padding: 0;}',
'.t-Region {margin:0px;border: 0;}',
'#t_Footer {display: none;}',
'#t_Body_title {padding: 0;display: none;}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_created_on=>wwv_flow_imp.dz('20230108230748Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230108231231Z')
,p_created_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
,p_last_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10642651776933118360)
,p_plug_name=>'JSON Viewer'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(44130294336400020575)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.APEXJSONVIEWER.PLUGIN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'dark',
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    'declare',
    '    t varchar2(32767);',
    'begin',
    '',
    '    select *',
    '    into t',
    '    from APEXJSON_VIEWER;',
    '',
    '    return t;',
    '    ',
    'end;')))).to_clob
,p_created_on=>wwv_flow_imp.dz('20230108230907Z')
,p_updated_on=>wwv_flow_imp.dz('20230108231231Z')
,p_created_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
,p_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp.component_end;
end;
/
