prompt --application/pages/page_02048
begin
--   Manifest
--     PAGE: 02048
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>2048
,p_name=>'Game 2048'
,p_alias=>'GAME-2048'
,p_step_title=>'Game 2048'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#main'').removeClass(''t-Body-mainContent'');',
'$(''.t-Body-contentInner'').removeClass(''t-Body-contentInner'');',
'$(''#t_PageBody'').width("100%");'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-contentInner {padding: 0;}',
'.t-Region {margin:0px;border: 0;}',
'#t_Footer {display: none;}',
'#t_Body_title {padding: 0;display: none;}',
'.t-Report-colHead {background-color: transparent;}',
'',
'.t-PageBody {',
'    background: none;',
'}',
'',
'html {',
'    background: url(#APP_FILES#game2048bg.jpg) no-repeat center center fixed;',
'}',
'',
'.rw-pillar--neutral.rw-mode-body--dark, bodybody:not([class*=rw-pillar--]).rw-mode-body--dark {',
'    background-image: none;',
'}',
'',
'#P2048_PLAYERNAME',
'{',
'    border: none !important;',
'    background: transparent !important;',
'    outline: none !important;',
'    color: white;',
'}',
'',
'.t-Report-cell {',
'    color: white;',
'}',
'',
'.t-Report-colHead {',
'    color: white;',
'}',
'',
'.t-Icon {',
'    color: white;',
'}',
'',
'.pagination {',
'    color: white;',
'}'))
,p_step_template=>wwv_flow_imp.id(44129721260824020546)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230827135734Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_last_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65224283813710760546)
,p_plug_name=>'Submit Score'
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_08'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(65224285844611760567)
,p_name=>'Top 10 score'
,p_parent_plug_id=>wwv_flow_imp.id(65224283813710760546)
,p_display_sequence=>50
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--noBorders'
,p_grid_column_span=>8
,p_display_column=>3
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ROW_NUMBER() OVER (ORDER BY score DESC, created_date DESC) AS place,',
'       name,',
'       score',
'FROM APEX_GAME2048',
'ORDER BY place',
'FETCH FIRST 10 ROWS ONLY;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(44130331882317020590)
,p_query_num_rows=>5
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9321620300807857532)
,p_query_column_id=>1
,p_column_alias=>'PLACE'
,p_column_display_sequence=>10
,p_column_heading=>'Top 10'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9321620646253857532)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9321621072353857533)
,p_query_column_id=>3
,p_column_alias=>'SCORE'
,p_column_display_sequence=>30
,p_column_heading=>'Score'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(243666479211910002095)
,p_plug_name=>'Game 2048'
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_08'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="container">',
'    <h1>',
'        <span>2</span>',
'        <span>0</span>',
'        <span>4</span>',
'        <span>8</span>',
'    </h1>',
'    <p class="inspired">Inspired by the original <a href="https://gabrielecirulli.github.io/2048/" target="_blank">2048</a>. </p>',
'</div>',
'<div class="directions">',
'    <p>',
'        <strong>HOW TO PLAY:</strong> Use your arrow keys to move the tiles. When two tiles slide into each other, they merge into one!',
'    </p>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(409255113853680633182)
,p_plug_name=>'Game 2048'
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_08'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160522497362622528308)
,p_plug_name=>'Game 2048'
,p_parent_plug_id=>wwv_flow_imp.id(409255113853680633182)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 4 as gamesize from dual -- 4 x 4'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_COM.GAME2048.TEMPLATECOMPONENT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'SIZE', 'GAMESIZE')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(65224283700988760545)
,p_name=>'GAMESIZE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GAMESIZE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9321618837349857530)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(65224283813710760546)
,p_button_name=>'SUBMIT_SCORE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--hoverIconSpin:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(44130366222019020605)
,p_button_image_alt=>'Submit Score'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gamepad'
,p_grid_new_row=>'N'
,p_grid_column_span=>1
,p_grid_column=>12
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65224286960189760554)
,p_name=>'P2048_PLAYERNAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(65224283813710760546)
,p_prompt=>'Name'
,p_placeholder=>'Place your name here and submit your score at game over ->'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(44130364412314020604)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65224287416657760559)
,p_name=>'P2048_SCORE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(65224283813710760546)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9321622024276857534)
,p_name=>'Submit Score'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9321618837349857530)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$(''#end'').hasClass(''active'');'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9321622531037857534)
,p_event_id=>wwv_flow_imp.id(9321622024276857534)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2048_SCORE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(''#score'').text()'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9321623053082857534)
,p_event_id=>wwv_flow_imp.id(9321622024276857534)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SUBMIT_SCORE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9321621661187857533)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Submit Score Proc'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    insert into apex_game2048 (name, score, created_date)',
'    values (:P2048_PLAYERNAME, :P2048_SCORE, sysdate);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SUBMIT_SCORE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Your score is submitted! Thank you for playing!'
,p_internal_uid=>56547508042531462631
,p_created_on=>wwv_flow_imp.dz('20230827134622Z')
,p_updated_on=>wwv_flow_imp.dz('20230827134622Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
