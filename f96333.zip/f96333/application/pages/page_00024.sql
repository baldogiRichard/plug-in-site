prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'News Feed'
,p_alias=>'NEWS-FEED'
,p_step_title=>'News Feed'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230816125519Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_last_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(131207345044977664963)
,p_plug_name=>'News Feed'
,p_icon_css_classes=>'fa-feed'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>'This template component is a demonstration of how this new apex feature can be utilized. A REST Data Source is being used to fetch data in the region and a Smart Filter is applied for the Category (or Tag) column in order to search between the rows.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230804135753Z')
,p_updated_on=>wwv_flow_imp.dz('20230804135846Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(296795979686748296050)
,p_plug_name=>'News Feed'
,p_icon_css_classes=>'fa-polar-chart'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1:t-Region--removeHeader js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230804144455Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48063363195690191176)
,p_plug_name=>'News Feed'
,p_parent_plug_id=>wwv_flow_imp.id(296795979686748296050)
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_plug_template=>wwv_flow_imp.id(44130241359276020556)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(422979941776324017)
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ISPERMALINK,',
'       HREF,',
'       REL,',
'       DOMAIN,',
'       HEIGHT,',
'       MEDIUM,',
'       URL,',
'       WIDTH,',
'       TITLE,',
'       LINK,',
'       GUID,',
'       DESCRIPTION,',
'       CREATOR,',
'       TO_CHAR(TO_TIMESTAMP_TZ(PUBDATE, ''Dy, DD Mon YYYY HH24:MI:SS TZD'', ''NLS_DATE_LANGUAGE=ENGLISH''), ''YYYY.MM.DD'') as PUBDATE,',
'       COALESCE(CATEGORY,''Unknown'') as CATEGORY,',
'       CREDIT,',
'       DESCRIPTION2,',
'       TRUNC(DBMS_RANDOM.VALUE(1,20)) as COMMENTS',
'  from #APEX$SOURCE_DATA#'))
,p_source_post_processing=>'SQL'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>true
,p_plug_source_type=>'TMPL_COM.NEWSFEED.TEMPLATECOMPONENT'
,p_plug_query_num_rows=>10
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'AUTHOR', 'CREATOR',
  'CATEGORIES', 'CATEGORY',
  'COMMENTS', 'COMMENTS',
  'DATE', 'PUBDATE',
  'DESCRIPTION', 'DESCRIPTION',
  'IMAGE_URL', 'URL',
  'NO_IMAGE_AVAILABLE_URL', '#APP_FILES#images/no_image_available.png',
  'TITLE', 'TITLE')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230816125519Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(437715187732552447)
,p_name=>'COMMENTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENTS'
,p_data_type=>'NUMBER'
,p_display_sequence=>180
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804142749Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063363267685191177)
,p_name=>'ISPERMALINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ISPERMALINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063363417150191178)
,p_name=>'HREF'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HREF'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063363461931191179)
,p_name=>'REL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063363629834191180)
,p_name=>'DOMAIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DOMAIN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063363682894191181)
,p_name=>'HEIGHT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HEIGHT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063363802999191182)
,p_name=>'MEDIUM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MEDIUM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063363915268191183)
,p_name=>'URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'URL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063363998871191184)
,p_name=>'WIDTH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'WIDTH'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364144047191185)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364166602191186)
,p_name=>'LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364284454191187)
,p_name=>'GUID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GUID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364359465191188)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364522931191189)
,p_name=>'CREATOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364614990191190)
,p_name=>'PUBDATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PUBDATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364724080191191)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364798492191192)
,p_name=>'CREDIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREDIT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(48063364919269191193)
,p_name=>'DESCRIPTION2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION2'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48063365588542191200)
,p_plug_name=>'Category Filter'
,p_parent_plug_id=>wwv_flow_imp.id(48063363195690191176)
,p_region_template_options=>'#DEFAULT#:margin-bottom-lg:margin-left-lg:margin-right-lg'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(48063363195690191176)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'compact_numbers_threshold', '10000',
  'more_filters_suggestion_chip', 'N',
  'show_total_row_count', 'N')).to_clob
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230804144432Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(424116893363538555)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(131207345044977664963)
,p_button_name=>'GITHUB'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(44130367022408020606)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Github'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'https://github.com/baldogiRichard/apex-news-feed'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-github'
,p_created_on=>wwv_flow_imp.dz('20230804135753Z')
,p_updated_on=>wwv_flow_imp.dz('20230804135816Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48063376512448191217)
,p_name=>'P24_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(48063365588542191200)
,p_prompt=>'Search'
,p_placeholder=>'Search category...'
,p_source=>'CATEGORY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(48063365084564191195)
,p_region_id=>wwv_flow_imp.id(48063363195690191176)
,p_position_id=>wwv_flow_imp.id(92964437049449432672)
,p_display_sequence=>10
,p_label=>'Read More'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&LINK.'
,p_action_css_classes=>'t-Button--success fa fa-arrow-circle-o-right'
,p_is_hot=>true
,p_show_as_disabled=>false
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230804143952Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(48063365214287191196)
,p_region_id=>wwv_flow_imp.id(48063363195690191176)
,p_position_id=>wwv_flow_imp.id(92962776556300252741)
,p_display_sequence=>20
,p_label=>'Share'
,p_show_as_disabled=>false
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230804143952Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(48063365324797191197)
,p_component_action_id=>wwv_flow_imp.id(48063365214287191196)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Facebook'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'https://www.facebook.com/sharer/sharer.php?u=&LINK.'
,p_icon_css_classes=>'fa-facebook'
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(48063365351877191198)
,p_component_action_id=>wwv_flow_imp.id(48063365214287191196)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Twitter'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'https://twitter.com/intent/tweet?text=&LINK.'
,p_icon_css_classes=>'fa-twitter'
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(48063365456671191199)
,p_component_action_id=>wwv_flow_imp.id(48063365214287191196)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Linkedin'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'https://www.linkedin.com/shareArticle?mini=true&url=&LINK.'
,p_icon_css_classes=>'fa-linkedin'
,p_created_on=>wwv_flow_imp.dz('20230804135337Z')
,p_updated_on=>wwv_flow_imp.dz('20230804135337Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
