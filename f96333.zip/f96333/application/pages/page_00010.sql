prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Range Area Charts'
,p_alias=>'RANGE-AREA-CHARTS'
,p_step_title=>'Range Area Charts'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_created_on=>wwv_flow_imp.dz('20230108230204Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221120211455Z')
,p_last_updated_by=>'BALDOGI.RICHARD@REMEDIOS.HU'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38591882921146196499)
,p_plug_name=>'Range Area Charts'
,p_icon_css_classes=>'fa-braille'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(44130268049406020565)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'What Are Range Area Charts?',
'<br>',
'<br>',
'Range Area Chart is a type of area chart where rather than starting on the axis, the area is represented by the space between two values. These charts are useful for displaying ranges of values, such as between minimum and maximum prices over a times'
||'pan, or projected values for the future when the projection is represented by a range instead of a specific value.'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44049927027807420494)
,p_plug_name=>'Range Area Charts'
,p_icon_css_classes=>'fa-range-chart-area'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--noPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(44130272243351020567)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6513335504857598335)
,p_plug_name=>'Range Area Chart Combined with Line Chart'
,p_parent_plug_id=>wwv_flow_imp.id(44049927027807420494)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.month,',
'       t.mon_no,',
'       t.category,',
'       min(t.value) as MIN,',
'       max(t.value) as MAX,',
'       t.charttype',
'from',
'(select month,',
'       replace(replace(category,'' Range'',''''),'' Median'','''') as category,',
'       case when category like ''%Range%''',
'             then value',
'       end as MIN,',
'       case when category like ''%Median%''',
'             then value',
'       end as MAX,',
'       value,',
'       ''rangeArea'' as CHARTTYPE,',
'       case when month = ''Jan''',
'              then 1',
'            when month = ''Feb''',
'              then 2',
'            when month = ''Mar''',
'              then 3',
'            when month = ''Apr''',
'              then 4',
'            when month = ''May''',
'              then 5',
'            when month = ''Jun''',
'              then 6',
'            when month = ''Jul''',
'              then 7',
'            when month = ''Aug''',
'              then 8',
'            when month = ''Sep''',
'              then 9',
'            when month = ''Okt''',
'              then 10',
'            when month = ''Nov''',
'              then 11',
'            when month = ''Dec''',
'              then 12',
'        end as mon_no',
'from APEXCHARTS_RANGEAREA) t',
'group by t.category,',
'         t.mon_no,',
'         t.month,',
'         t.charttype',
'union all',
'select t.month,',
'       t.mon_no,',
'       t.category,',
'       min(t.value) as MIN,',
'       max(t.value) / 2 as MAX,',
'       t.charttype',
'from',
'(select month,',
'        category,',
'        value,',
'       ''line'' as CHARTTYPE,',
'       case when month = ''Jan''',
'              then 1',
'            when month = ''Feb''',
'              then 2',
'            when month = ''Mar''',
'              then 3',
'            when month = ''Apr''',
'              then 4',
'            when month = ''May''',
'              then 5',
'            when month = ''Jun''',
'              then 6',
'            when month = ''Jul''',
'              then 7',
'            when month = ''Aug''',
'              then 8',
'            when month = ''Sep''',
'              then 9',
'            when month = ''Okt''',
'              then 10',
'            when month = ''Nov''',
'              then 11',
'            when month = ''Dec''',
'              then 12',
'        end as mon_no',
'from APEXCHARTS_RANGEAREA',
'where category in (''Team A Median'',''Team B Median'')) t',
'group by t.category,',
'         t.mon_no,',
'         t.month,',
'         t.charttype',
'order by charttype,',
'         mon_no'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'',
'    config.dataLabels = {enabled: false};',
'',
'    config.fill = {opacity: [1, 1, 0.24, 0.24]};',
'    ',
'    config.forecastDataPoints = {count: 2};',
'',
'    config.stroke = {curve: ''straight'',width: [2,2,0,0]};',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'combo',
  'attribute_02', 'range_area_chart_3',
  'attribute_03', 'Range Area Chart Combined with Line Chart',
  'attribute_04', '700',
  'attribute_05', '350',
  'attribute_07', 'MONTH',
  'attribute_08', 'MAX',
  'attribute_09', 'MIN,MAX',
  'attribute_12', 'CHARTTYPE',
  'attribute_13', 'CATEGORY',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335358670598334)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335337651598333)
,p_name=>'MONTH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335202833598332)
,p_name=>'CHARTTYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335073738598331)
,p_name=>'MIN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335031425598330)
,p_name=>'MAX'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513334926265598329)
,p_name=>'MON_NO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6513334804407598328)
,p_plug_name=>'Range Area Chart Combined'
,p_parent_plug_id=>wwv_flow_imp.id(44049927027807420494)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.month,',
'       t.mon_no,',
'       t.category,',
'       min(t.value) as MIN,',
'       max(t.value) as MAX,',
'       t.charttype',
'from',
'(select month,',
'       replace(replace(category,'' Range'',''''),'' Median'','''') as category,',
'       case when category like ''%Range%''',
'             then value',
'       end as MIN,',
'       case when category like ''%Median%''',
'             then value',
'       end as MAX,',
'       value,',
'       ''rangeArea'' as CHARTTYPE,',
'       case when month = ''Jan''',
'              then 1',
'            when month = ''Feb''',
'              then 2',
'            when month = ''Mar''',
'              then 3',
'            when month = ''Apr''',
'              then 4',
'            when month = ''May''',
'              then 5',
'            when month = ''Jun''',
'              then 6',
'            when month = ''Jul''',
'              then 7',
'            when month = ''Aug''',
'              then 8',
'            when month = ''Sep''',
'              then 9',
'            when month = ''Okt''',
'              then 10',
'            when month = ''Nov''',
'              then 11',
'            when month = ''Dec''',
'              then 12',
'        end as mon_no',
'from APEXCHARTS_RANGEAREA) t',
'group by t.category,',
'         t.mon_no,',
'         t.month,',
'         t.charttype',
'order by mon_no'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'',
'    config.colors = [''#d4526e'', ''#33b2df''];',
'    config.dataLabels = {enabled: false};',
'',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'combo',
  'attribute_02', 'range_area_chart_2',
  'attribute_03', 'Range Area Chart Combined',
  'attribute_04', '700',
  'attribute_05', '350',
  'attribute_07', 'MONTH',
  'attribute_09', 'MIN,MAX',
  'attribute_12', 'CHARTTYPE',
  'attribute_13', 'CATEGORY',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513334671307598327)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513334564632598326)
,p_name=>'MONTH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513334501851598325)
,p_name=>'CHARTTYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513334446334598324)
,p_name=>'MIN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513334277343598323)
,p_name=>'MAX'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513334243132598322)
,p_name=>'MON_NO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44049927137792420495)
,p_plug_name=>'Range Area Chart Basic'
,p_parent_plug_id=>wwv_flow_imp.id(44049927027807420494)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44129739938508020555)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.month,',
'       t.mon_no,',
'       t.category,',
'       min(t.value) as MIN,',
'       max(t.value) as MAX',
'from',
'(select month,',
'       replace(replace(category,'' Range'',''''),'' Median'','''') as category,',
'       case when category like ''%Range%''',
'             then value',
'       end as MIN,',
'       case when category like ''%Median%''',
'             then value',
'       end as MAX,',
'       value,',
'       case when month = ''Jan''',
'              then 1',
'            when month = ''Feb''',
'              then 2',
'            when month = ''Mar''',
'              then 3',
'            when month = ''Apr''',
'              then 4',
'            when month = ''May''',
'              then 5',
'            when month = ''Jun''',
'              then 6',
'            when month = ''Jul''',
'              then 7',
'            when month = ''Aug''',
'              then 8',
'            when month = ''Sep''',
'              then 9',
'            when month = ''Okt''',
'              then 10',
'            when month = ''Nov''',
'              then 11',
'            when month = ''Dec''',
'              then 12',
'        end as mon_no',
'from APEXCHARTS_RANGEAREA) t',
'where t.category = ''Team A''',
'group by t.category,',
'         t.mon_no,',
'         t.month',
'order by mon_no'))
,p_plug_source_type=>'PLUGIN_COM.APEXCHARTS.PLUGIN'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'',
'    config.dataLabels = {enabled: false};',
'',
'    return config;',
'',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'rangeArea',
  'attribute_02', 'range_area_chart_1',
  'attribute_03', 'Range Area Chart Basic',
  'attribute_04', '700',
  'attribute_05', '350',
  'attribute_07', 'MONTH',
  'attribute_09', 'MIN,MAX',
  'attribute_15', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335999422598340)
,p_name=>'MONTH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335786712598338)
,p_name=>'MIN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335727419598337)
,p_name=>'MAX'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6513335636063598336)
,p_name=>'MON_NO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19375415974876441892)
,p_name=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_use_as_row_header=>false
);
wwv_flow_imp.component_end;
end;
/
