prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 96333
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(142353058823077164)
,p_welcome_message=>unistr('Dieses Anwendungsinstallationsprogramm f\00FChrt Sie durch den Prozess zum Erstellen von Datenbankobjekten und Seed-Daten.')
,p_configuration_message=>unistr('Sie k\00F6nnen die folgenden Attribute der Anwendung konfigurieren.')
,p_build_options_message=>unistr('Sie k\00F6nnen die folgenden Erstelloptionen einbeziehen.')
,p_validation_message=>unistr('Die folgenden Validierungen werden durchgef\00FChrt, um sicherzustellen, dass das System mit dieser Anwendung kompatibel ist.')
,p_install_message=>unistr('Best\00E4tigen Sie, dass Sie die unterst\00FCtzenden Objekte dieser Anwendung installieren m\00F6chten.')
,p_upgrade_message=>unistr('Das Anwendungsinstallationsprogramm hat ermittelt, dass die unterst\00FCtzenden Objekte dieser Anwendung zuvor installiert wurden. Dieser Assistent unterst\00FCtzt Sie beim Upgrade dieser unterst\00FCtzenden Objekte.')
,p_upgrade_confirm_message=>unistr('Best\00E4tigen Sie, dass Sie die unterst\00FCtzenden Objekte dieser Anwendung installieren m\00F6chten.')
,p_upgrade_success_message=>unistr('Ihre unterst\00FCtzenden Objekte wurden installiert.')
,p_upgrade_failure_message=>'Installation der Datenbankobjekte und Seed-Daten nicht erfolgreich.'
,p_deinstall_success_message=>'Deinstallation abgeschlossen.'
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table APEXCHARTS_AREA_NEGATIV;',
'drop table APEXCHARTS_AREA_STACKED;',
'drop table APEXCHARTS_BAR_BASIC;',
'drop table APEXCHARTS_BAR_STACKED;',
'drop table APEXCHARTS_BOXPLOT_HORIZONTAL;',
'drop table APEXCHARTS_BOXPLOT_SCATTER;',
'drop table APEXCHARTS_BUBBLE;',
'drop table APEXCHARTS_CANDLESTICK_BASIC;',
'drop table APEXCHARTS_HEATMAP_BASIC_COLORRANGE;',
'drop table APEXCHARTS_LINE;',
'drop table APEXCHARTS_PIEDONUT;',
'drop table APEXCHARTS_POLARAREA;',
'drop table APEXCHARTS_RADAR;',
'drop table APEXCHARTS_RADIALCIRCLE;',
'drop table APEXCHARTS_RANGEAREA;',
'drop table APEXCHARTS_SCATTER;',
'drop table APEXCHARTS_TIMELINE_MULTIPLERANGES;',
'drop table APEXCHARTS_TIMELINE_MULTIPLESERIES;',
'drop table APEXCHARTS_TREEMAP_BASIC;',
'drop table APEXCHARTS_TREEMAP_MULTIPLE;',
'drop table APEXCHART_COLUMNS_BASIC;',
'drop table APEXCHART_COLUMNS_STACKED;',
'drop table APEX_COMMENTS;',
'drop table EMP;',
'drop table APEXJSON_VIEWER;'))
,p_last_updated_on=>wwv_flow_imp.dz('20250111215605Z')
,p_last_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
