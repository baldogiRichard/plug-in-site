prompt --workspace/remote_servers/earthquake_usgs_gov_earthquakes_feed
begin
--   Manifest
--     REMOTE SERVER: earthquake-usgs-gov-earthquakes-feed
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(9955596590742510807)
,p_name=>'earthquake-usgs-gov-earthquakes-feed'
,p_static_id=>'earthquake_usgs_gov_earthquakes_feed'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('earthquake_usgs_gov_earthquakes_feed'),'https://earthquake.usgs.gov/earthquakes/feed/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('earthquake_usgs_gov_earthquakes_feed'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('earthquake_usgs_gov_earthquakes_feed'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('earthquake_usgs_gov_earthquakes_feed'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('earthquake_usgs_gov_earthquakes_feed'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('earthquake_usgs_gov_earthquakes_feed'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('earthquake_usgs_gov_earthquakes_feed'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('earthquake_usgs_gov_earthquakes_feed'),'')
);
wwv_flow_imp.component_end;
end;
/
