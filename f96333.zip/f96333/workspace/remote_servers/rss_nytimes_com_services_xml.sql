prompt --workspace/remote_servers/rss_nytimes_com_services_xml
begin
--   Manifest
--     REMOTE SERVER: rss-nytimes-com-services-xml
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>31247972357692975900
,p_default_application_id=>124962
,p_default_id_offset=>47225886381343605098
,p_default_owner=>'WKSP_RMZRT'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(1136125958943097114)
,p_name=>'rss-nytimes-com-services-xml'
,p_static_id=>'rss_nytimes_com_services_xml'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('rss_nytimes_com_services_xml'),'https://rss.nytimes.com/services/xml/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('rss_nytimes_com_services_xml'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('rss_nytimes_com_services_xml'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('rss_nytimes_com_services_xml'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('rss_nytimes_com_services_xml'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('rss_nytimes_com_services_xml'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('rss_nytimes_com_services_xml'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('rss_nytimes_com_services_xml'),'')
,p_created_on=>wwv_flow_imp.dz('20230731194334Z')
,p_updated_on=>wwv_flow_imp.dz('20230731194334Z')
,p_created_by=>'BALDOGI.RICHARD'
,p_updated_by=>'BALDOGI.RICHARD'
);
wwv_flow_imp.component_end;
end;
/
